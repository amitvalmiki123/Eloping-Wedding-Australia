<?php
/**
 * Template Name: About Us
 */
get_header();

$about_sections = array(
    'hero',
    'story',
    'values',
    'team',
    'partners',
    'testimonial',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'about', $about_sections ); ?>
</main>
<?php
get_footer();