<?php
/**
 * Template Name: Same Sex Elopements
 */
get_header();

// Sections wahi hain jo master design mein hain
$ss_sections = array(
    'hero', 'intro', 'experiences', 'highlights', 'band', 'plan', 'testimonial', 'mini', 'cta'
);
?>
<main id=\"main\" class=\"site-main\">
    <?php eloping_render_sections( 'queenstown', $ss_sections ); ?>
</main>
<?php get_footer(); ?>