/**
 * Main Theme JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {

  /* ------------------------------------------------------------------
     1. IntersectionObserver for Fade-in Elements
     ------------------------------------------------------------------ */
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  },{threshold:.12});
  
  document.querySelectorAll('.fade-in').forEach(el=>io.observe(el));

  /* ------------------------------------------------------------------
     2. Mobile Drawer Menu
     ------------------------------------------------------------------ */
  const drawer   = document.getElementById('mobileDrawer');
  const overlay  = document.getElementById('drawerOverlay');
  const closeBtn = document.getElementById('drawerClose');
  const menuBtn  = document.querySelector('.menu-btn');

  function openDrawer(){
    if(drawer) drawer.classList.add('open');
    if(menuBtn) menuBtn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  function closeDrawer(){
    if(drawer) drawer.classList.remove('open');
    if(menuBtn) menuBtn.classList.remove('open');
    document.body.style.overflow = '';
  }

  if(menuBtn) menuBtn.addEventListener('click', openDrawer);
  if(overlay) overlay.addEventListener('click', closeDrawer);
  if(closeBtn) closeBtn.addEventListener('click', closeDrawer);

  // Accordion sub-menus inside drawer
  document.querySelectorAll('.drawer-link[data-sub]').forEach(btn => {
    btn.addEventListener('click', function(){
      const subId = this.getAttribute('data-sub');
      const sub   = document.getElementById(subId);
      if(!sub) return;
      
      const isOpen = sub.classList.contains('open');
      document.querySelectorAll('.drawer-sub').forEach(s => s.classList.remove('open'));
      document.querySelectorAll('.drawer-link[data-sub]').forEach(b => b.classList.remove('active'));
      
      if(!isOpen){ 
        sub.classList.add('open'); 
        this.classList.add('active'); 
      }
    });
  });

  document.addEventListener('keydown', e => { 
    if(e.key === 'Escape') closeDrawer(); 
  });

  /* ------------------------------------------------------------------
     3. Footer Accordion (Mobile Only)
     ------------------------------------------------------------------ */
  function initFooterAccordion(){
    if(window.innerWidth > 480) return;
    
    document.querySelectorAll('.footer-acc-trigger').forEach(function(trigger){
      if(trigger.dataset.bound) return; // avoid double-binding
      trigger.dataset.bound = '1';
      
      trigger.addEventListener('click', function(){
        var body = this.nextElementSibling;
        while(body && !body.classList.contains('footer-acc-body')){
          body = body.nextElementSibling;
        }
        if(!body) return;
        
        var isOpen = body.classList.contains('open');
        
        // Close all
        document.querySelectorAll('.footer-acc-body.open').forEach(function(b){ b.classList.remove('open'); });
        document.querySelectorAll('.footer-acc-trigger.open').forEach(function(t){ t.classList.remove('open'); t.setAttribute('aria-expanded','false'); });
        
        if(!isOpen){
          body.classList.add('open');
          this.classList.add('open');
          this.setAttribute('aria-expanded','true');
        }
      });
    });
  }
  
  initFooterAccordion();
  window.addEventListener('resize', initFooterAccordion);

  /* ------------------------------------------------------------------
     4. Stats Counter Animation
     ------------------------------------------------------------------ */
  const counters = document.querySelectorAll('.stats .n[data-target]');
  if(counters.length) {
    const easeOut = t => 1 - Math.pow(1 - t, 3);

    function animateCounter(el){
      const target   = parseFloat(el.dataset.target);
      const suffix   = el.dataset.suffix || '';
      const decimal  = parseInt(el.dataset.decimal || 0);
      const duration = 1800;
      const start    = performance.now();

      function tick(now){
        const elapsed  = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const eased    = easeOut(progress);
        const current  = eased * target;
        el.textContent = current.toFixed(decimal) + suffix;
        if(progress < 1) requestAnimationFrame(tick);
        else el.textContent = target.toFixed(decimal) + suffix;
      }
      requestAnimationFrame(tick);
    }

    const statObserver = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if(e.isIntersecting){
          animateCounter(e.target);
          statObserver.unobserve(e.target);
        }
      });
    }, {threshold: 0.4});

    counters.forEach(el => statObserver.observe(el));
  }

  /* ------------------------------------------------------------------
     5. Hero Next Section Smooth Scroll (Dynamic Auto-detect)
     ------------------------------------------------------------------ */
  const scrollButtons = document.querySelectorAll('.js-scroll-next');
  
  scrollButtons.forEach(button => {
      button.addEventListener('click', function(e) {
          e.preventDefault(); 
          
          // Button ke parent hero section ko dhundo (chahe uski class 'hero' ho ya 'page-hero')
          const heroSection = this.closest('section.hero, section.page-hero');
          
          // Hero ke theek baad aane wale element par smooth scroll karo
          if (heroSection && heroSection.nextElementSibling) {
              heroSection.nextElementSibling.scrollIntoView({ 
                  behavior: 'smooth', 
                  block: 'start' 
              });
          }
      });
  });

});