/**
 * Live Customizer Preview (Rule 19) [cite: 162]
 */
(function( $ ) {

    const colorVars = {
        'color_forest': '--forest',
        'color_rose': '--rose',
        'color_blush': '--blush',
        'color_cream': '--cream',
        'color_ink': '--ink',
        'color_paper': '--paper'
    };

    // Loop through each color and apply it to :root live via setProperty [cite: 166]
    $.each( colorVars, function( setting, cssVar ) {
        wp.customize( setting, function( value ) {
            value.bind( function( newval ) {
                document.documentElement.style.setProperty( cssVar, newval );
            } );
        } );
    } );

})( jQuery );