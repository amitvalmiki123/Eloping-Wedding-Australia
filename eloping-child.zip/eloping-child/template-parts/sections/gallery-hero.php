<?php
$eyebrow = get_field('gal_hero_eyebrow') ?: get_eloping_default('gallery', 'hero', 'eyebrow');
$title   = get_field('gal_hero_title') ?: get_eloping_default('gallery', 'hero', 'title');
$lede    = get_field('gal_hero_lede') ?: get_eloping_default('gallery', 'hero', 'lede');
?>
<section class="page-hero minimal">
  <div class="inner" style="text-align:center;">
    <?php if($eyebrow): ?><div class="eyebrow" style="display:inline-flex; justify-content:center;"><span class="dot"></span> <?php echo esc_html($eyebrow); ?></div><?php endif; ?>
    <?php if($title): ?><h1 style="color:var(--forest); max-width:22ch; margin-left:auto; margin-right:auto;"><?php echo wp_kses_post($title); ?></h1><?php endif; ?>
    <?php if($lede): ?><p class="lede" style="color:var(--ink);"><?php echo wp_kses_post($lede); ?></p><?php endif; ?>
  </div>
</section>