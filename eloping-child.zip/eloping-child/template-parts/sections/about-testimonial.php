<?php
/**
 * Template part for About Testimonial
 */
$quote = get_field('about_test_quote') ?: get_eloping_default('about', 'testimonial', 'quote');
$cite  = get_field('about_test_cite') ?: get_eloping_default('about', 'testimonial', 'cite');
if ( empty($quote) ) return;
?>
<section class="ab-testimonial">
  <div class="wrap">
    <div class="stars">★ ★ ★ ★ ★</div>
    <blockquote><?php echo wp_kses_post($quote); ?></blockquote>
    <?php if($cite): ?><cite><?php echo esc_html($cite); ?></cite><?php endif; ?>
  </div>
</section>