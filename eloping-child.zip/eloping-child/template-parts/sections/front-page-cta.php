<?php
/**
 * Template part for displaying the CTA Band with ACF Bridge.
 */

$bg_img     = get_field('home_cta_bg_img') ?: get_eloping_default( 'front_page', 'cta', 'bg_img' );
$title      = get_field('home_cta_title') ?: get_eloping_default( 'front_page', 'cta', 'title' );
$text       = get_field('home_cta_text') ?: get_eloping_default( 'front_page', 'cta', 'text' );
$btn_1_text = get_field('home_cta_btn_1_text') ?: get_eloping_default( 'front_page', 'cta', 'btn_1_text' );
$btn_1_url  = get_field('home_cta_btn_1_url') ?: get_eloping_default( 'front_page', 'cta', 'btn_1_url' );
$btn_2_text = get_field('home_cta_btn_2_text') ?: get_eloping_default( 'front_page', 'cta', 'btn_2_text' );
$btn_2_url  = get_field('home_cta_btn_2_url') ?: get_eloping_default( 'front_page', 'cta', 'btn_2_url' );
?>
<section class="cta-band">
  <?php if ( $bg_img ) : ?>
    <img src="<?php echo esc_url( $bg_img ); ?>" alt="Call to Action Background" loading="lazy" />
  <?php endif; ?>
  
  <div class="wrap">
    <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
    <?php endif; ?>

    <?php if ( $text ) : ?>
        <p><?php echo wp_kses_post( $text ); ?></p>
    <?php endif; ?>

    <div class="actions">
      <?php if ( $btn_1_text && $btn_1_url ) : ?>
        <a class="btn btn-primary" href="<?php echo esc_url( $btn_1_url ); ?>"><?php echo esc_html( $btn_1_text ); ?> <i class="arrow"></i></a>
      <?php endif; ?>
      
      <?php if ( $btn_2_text && $btn_2_url ) : ?>
        <a class="btn btn-ghost" href="<?php echo esc_url( $btn_2_url ); ?>"><?php echo esc_html( $btn_2_text ); ?></a>
      <?php endif; ?>
    </div>
  </div>
</section>