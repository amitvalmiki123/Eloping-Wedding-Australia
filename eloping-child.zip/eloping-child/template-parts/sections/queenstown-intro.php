<?php
/**
 * Template part for Queenstown Intro
 */
$label     = get_field('queenstown_intro_label') ?: get_eloping_default('queenstown', 'intro', 'label');
$title     = get_field('queenstown_intro_title') ?: get_eloping_default('queenstown', 'intro', 'title');
$text_1    = get_field('queenstown_intro_text_1') ?: get_eloping_default('queenstown', 'intro', 'text_1');
$text_2    = get_field('queenstown_intro_text_2') ?: get_eloping_default('queenstown', 'intro', 'text_2');
$signature = get_field('queenstown_intro_signature') ?: get_eloping_default('queenstown', 'intro', 'signature');
$img_main  = get_field('queenstown_intro_img_main') ?: get_eloping_default('queenstown', 'intro', 'img_main');
$img_over  = get_field('queenstown_intro_img_over') ?: get_eloping_default('queenstown', 'intro', 'img_over');
?>
<section class="qs-intro fade-in">
  <div>
    <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
    <?php endif; ?>
    <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
    <?php endif; ?>
    <?php if ( $text_1 ) : ?>
        <p><?php echo wp_kses_post( $text_1 ); ?></p>
    <?php endif; ?>
    <?php if ( $text_2 ) : ?>
        <p><?php echo wp_kses_post( $text_2 ); ?></p>
    <?php endif; ?>
    <?php if ( $signature ) : ?>
        <div class="sig"><?php echo esc_html( $signature ); ?></div>
    <?php endif; ?>
  </div>
  <div class="image">
    <?php if ( $img_main ) : ?>
        <img src="<?php echo esc_url( $img_main ); ?>" alt="Queenstown Story Main" loading="lazy" />
    <?php endif; ?>
    <?php if ( $img_over ) : ?>
        <div class="image-2"><img src="<?php echo esc_url( $img_over ); ?>" alt="Queenstown Story Detail" loading="lazy" /></div>
    <?php endif; ?>
  </div>
</section>