<?php
// Filters
$default_flt = get_eloping_default('gallery', 'grid', 'filters');
$filters = array();
for ( $i = 1; $i <= 6; $i++ ) {
    $slug  = get_field('gal_flt_'.$i.'_slug');
    $label = get_field('gal_flt_'.$i.'_label');
    if ($slug && $label) $filters[] = array('slug' => $slug, 'label' => $label);
}
if (empty($filters)) $filters = $default_flt;

// Images (Up to 24)
$default_img = get_eloping_default('gallery', 'grid', 'items');
$images = array();
for ( $i = 1; $i <= 24; $i++ ) {
    $img   = get_field('gal_img_'.$i.'_file');
    $cat   = get_field('gal_img_'.$i.'_cat');
    $tag   = get_field('gal_img_'.$i.'_tag');
    $title = get_field('gal_img_'.$i.'_title');
    if ($img) $images[] = array('img' => $img, 'cat' => $cat, 'tag' => $tag, 'title' => $title);
}
if (empty($images)) $images = $default_img;
?>
<?php if(!empty($filters)): ?>
<div class="filter-bar">
  <div class="filter-inner">
    <button class="active" data-filter="all">All</button>
    <?php foreach($filters as $f): ?><button data-filter="<?php echo esc_attr($f['slug']); ?>"><?php echo esc_html($f['label']); ?></button><?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<section class="gal">
  <div class="gal-inner" id="galGrid">
    <?php if(!empty($images)): foreach($images as $im): ?>
    <div class="gal-item" data-cat="<?php echo esc_attr($im['cat']); ?>" data-src="<?php echo esc_url($im['img']); ?>">
      <img src="<?php echo esc_url($im['img']); ?>" alt="Gallery Image" loading="lazy" />
      <div class="cap">
        <small><?php echo esc_html($im['tag']); ?></small>
        <h4><?php echo wp_kses_post($im['title']); ?></h4>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</section>

<div class="lightbox" id="lightbox" role="dialog" aria-modal="true">
  <button class="lightbox-close" id="lbClose" aria-label="Close"></button>
  <button class="lightbox-nav prev" id="lbPrev" aria-label="Previous"></button>
  <img id="lbImg" src="" alt="Lightbox view"/>
  <button class="lightbox-nav next" id="lbNext" aria-label="Next"></button>
</div>