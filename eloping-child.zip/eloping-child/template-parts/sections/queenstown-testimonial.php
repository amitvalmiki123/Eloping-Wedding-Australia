<?php
/**
 * Template part for Queenstown Testimonial
 */
$quote = get_field('queenstown_test_quote') ?: get_eloping_default('queenstown', 'testimonial', 'quote');
$cite  = get_field('queenstown_test_cite') ?: get_eloping_default('queenstown', 'testimonial', 'cite');
if ( empty($quote) ) return;
?>
<section class="qs-testimonial">
  <div class="wrap">
    <div class="stars">★ ★ ★ ★ ★</div>
    <blockquote><?php echo wp_kses_post($quote); ?></blockquote>
    <?php if($cite): ?><cite><?php echo esc_html($cite); ?></cite><?php endif; ?>
  </div>
</section>