<?php
/**
 * Template part for displaying the Packages (Pricing) section with ACF Bridge.
 */

$label = get_field('home_pkg_label') ?: get_eloping_default( 'front_page', 'packages', 'label' );
$title = get_field('home_pkg_title') ?: get_eloping_default( 'front_page', 'packages', 'title' );
$text  = get_field('home_pkg_text') ?: get_eloping_default( 'front_page', 'packages', 'text' );

// Build packages loop dynamically
$default_pkgs = get_eloping_default( 'front_page', 'packages', 'pkgs' );
$pkgs = array();

for ( $i = 1; $i <= 3; $i++ ) {
    $tag   = get_field('home_pkg_' . $i . '_tag');
    $p_title = get_field('home_pkg_' . $i . '_title');
    $p_lbl = get_field('home_pkg_' . $i . '_price_label');
    $p_val = get_field('home_pkg_' . $i . '_price_val');
    $b_txt = get_field('home_pkg_' . $i . '_btn_text');
    $b_url = get_field('home_pkg_' . $i . '_btn_url');

    $feats = array();
    for ( $f = 1; $f <= 5; $f++ ) {
        $feat_val = get_field('home_pkg_' . $i . '_feat_' . $f);
        if ( $feat_val ) {
            $feats[] = $feat_val;
        }
    }
    if ( empty($feats) && isset($default_pkgs[$i]['feats']) ) {
        $feats = $default_pkgs[$i]['feats'];
    }

    $pkgs[$i] = array(
        'tag'         => $tag ?: (isset($default_pkgs[$i]['tag']) ? $default_pkgs[$i]['tag'] : ''),
        'title'       => $p_title ?: (isset($default_pkgs[$i]['title']) ? $default_pkgs[$i]['title'] : ''),
        'price_label' => $p_lbl ?: (isset($default_pkgs[$i]['price_label']) ? $default_pkgs[$i]['price_label'] : ''),
        'price_val'   => $p_val ?: (isset($default_pkgs[$i]['price_val']) ? $default_pkgs[$i]['price_val'] : ''),
        'btn_text'    => $b_txt ?: (isset($default_pkgs[$i]['btn_text']) ? $default_pkgs[$i]['btn_text'] : ''),
        'btn_url'     => $b_url ?: (isset($default_pkgs[$i]['btn_url']) ? $default_pkgs[$i]['btn_url'] : ''),
        'feats'       => $feats
    );
}
?>
<section class="packages" id="packages">
  <div class="head fade-in">
    <?php if ( $label ) : ?>
        <div class="section-label" style="justify-content:center"><?php echo esc_html( $label ); ?></div>
    <?php endif; ?>

    <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
    <?php endif; ?>

    <?php if ( $text ) : ?>
        <p><?php echo wp_kses_post( $text ); ?></p>
    <?php endif; ?>
  </div>

  <?php if ( ! empty( $pkgs ) ) : ?>
  <div class="pkg-grid">
    <?php 
    foreach ( $pkgs as $index => $pkg ) : 
        $pkg_class = ( $index == 2 ) ? 'pkg featured fade-in' : 'pkg fade-in';
    ?>
    <div class="<?php echo esc_attr( $pkg_class ); ?>">
      <?php if ( ! empty( $pkg['tag'] ) ) : ?>
        <span class="tag"><?php echo esc_html( $pkg['tag'] ); ?></span>
      <?php endif; ?>
      
      <?php if ( ! empty( $pkg['title'] ) ) : ?>
        <h3><?php echo esc_html( $pkg['title'] ); ?></h3>
      <?php endif; ?>
      
      <div class="price">
        <?php echo esc_html( ! empty( $pkg['price_label'] ) ? $pkg['price_label'] : '' ); ?> 
        <?php if ( ! empty( $pkg['price_val'] ) ) : ?>
            <strong><?php echo esc_html( $pkg['price_val'] ); ?></strong>
        <?php endif; ?>
      </div>
      
      <?php if ( ! empty( $pkg['feats'] ) ) : ?>
      <ul>
        <?php foreach ( $pkg['feats'] as $feat ) : ?>
            <li><?php echo wp_kses_post( $feat ); ?></li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
      
      <?php if ( ! empty( $pkg['btn_text'] ) && ! empty( $pkg['btn_url'] ) ) : ?>
        <?php $btn_class = ( $index == 2 ) ? 'btn btn-primary' : 'btn btn-dark'; ?>
        <a class="<?php echo esc_attr( $btn_class ); ?>" href="<?php echo esc_url( $pkg['btn_url'] ); ?>"><?php echo esc_html( $pkg['btn_text'] ); ?> <i class="arrow"></i></a>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>