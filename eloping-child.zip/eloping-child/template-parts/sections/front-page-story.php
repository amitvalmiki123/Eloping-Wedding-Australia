<?php
/**
 * Template part for displaying the Story section with ACF Bridge.
 */

$label       = get_field('home_story_label') ?: get_eloping_default( 'front_page', 'story', 'label' );
$title       = get_field('home_story_title') ?: get_eloping_default( 'front_page', 'story', 'title' );
$text_1      = get_field('home_story_text_1') ?: get_eloping_default( 'front_page', 'story', 'text_1' );
$text_2      = get_field('home_story_text_2') ?: get_eloping_default( 'front_page', 'story', 'text_2' );
$signature   = get_field('home_story_signature') ?: get_eloping_default( 'front_page', 'story', 'signature' );
$img_main    = get_field('home_story_img_main') ?: get_eloping_default( 'front_page', 'story', 'img_main' );
$badge       = get_field('home_story_badge') ?: get_eloping_default( 'front_page', 'story', 'badge' );
$img_overlay = get_field('home_story_img_overlay') ?: get_eloping_default( 'front_page', 'story', 'img_overlay' );
?>
<section id="story" class="story fade-in">
  <div>
    <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
    <?php endif; ?>

    <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
    <?php endif; ?>

    <?php if ( $text_1 ) : ?>
        <p><?php echo wp_kses_post( $text_1 ); ?></p>
    <?php endif; ?>

    <?php if ( $text_2 ) : ?>
        <p><?php echo wp_kses_post( $text_2 ); ?></p>
    <?php endif; ?>

    <?php if ( $signature ) : ?>
        <div class="sig"><?php echo esc_html( $signature ); ?></div>
    <?php endif; ?>
  </div>

  <div class="image">
    <?php if ( $img_main ) : ?>
        <img src="<?php echo esc_url( $img_main ); ?>" alt="Story Main Image" loading="lazy" />
    <?php endif; ?>
    
    <?php if ( $badge ) : ?>
        <div class="badge"><?php echo esc_html( $badge ); ?></div>
    <?php endif; ?>
    
    <?php if ( $img_overlay ) : ?>
        <div class="image-2">
            <img src="<?php echo esc_url( $img_overlay ); ?>" alt="Story Detail Image" loading="lazy" />
        </div>
    <?php endif; ?>
  </div>
</section>