<?php
/**
 * Template part for Premium Hero (Universal)
 */

$prefix = 'dest'; 

// 1. ACF Data Fetching
$bg_image    = get_field($prefix . '_hero_bg_img') ?: get_eloping_default($prefix, 'hero', 'bg_img');
$eyebrow     = get_field($prefix . '_hero_eyebrow') ?: get_eloping_default($prefix, 'hero', 'eyebrow');
$title       = get_field($prefix . '_hero_title') ?: get_eloping_default($prefix, 'hero', 'title');

// 2. Customizer se Global Settings Uthana
$global_enquire_url = get_theme_mod( 'eloping_enquire_url', home_url('/contact/') );
$global_phone       = get_theme_mod( 'eloping_phone_number', '021411289' );
$clean_phone        = sanitize_text_field( str_replace(' ', '', $global_phone) ); 

// 3. BUTTONS
$btn_1_text  = get_field($prefix . '_hero_btn_1_text') ?: 'Enquire Now';
$btn_1_url   = get_field($prefix . '_hero_btn_1_url') ?: $global_enquire_url;

$btn_2_text  = get_field($prefix . '_hero_btn_2_text') ?: 'Call Us';
$btn_2_url   = get_field($prefix . '_hero_btn_2_url') ?: 'tel:' . $clean_phone;

// 4. Meta, Lede & Scroll
$meta_strong = get_field($prefix . '_hero_meta_strong');
$meta_desc   = get_field($prefix . '_hero_lede'); 
// Scroll Text khali hone par default 'Scroll' pakad lega taaki hamesha visible rahe
$scroll_text = get_field($prefix . '_hero_scroll_text') ?: 'Scroll'; 
?>
<section class="hero">
  <?php if ( $bg_image ) : ?>
  <div class="bg">
    <img src="<?php echo esc_url( $bg_image ); ?>" alt="<?php echo esc_attr( wp_strip_all_tags( $title ) ); ?>" loading="eager" fetchpriority="high" />
  </div>
  <?php endif; ?>

  <div class="inner">
    <div>
      <?php if ( $eyebrow ) : ?>
        <div class="eyebrow"><span class="dot"></span> <?php echo esc_html( $eyebrow ); ?></div>
      <?php endif; ?>
      
      <?php if ( $title ) : ?>
        <h1><?php echo wp_kses_post( $title ); ?></h1>
      <?php endif; ?>
      
      <div class="actions">
        <?php if ( $btn_1_text && $btn_1_url ) : ?>
            <a href="<?php echo esc_url( $btn_1_url ); ?>" class="btn btn-primary"><?php echo esc_html( $btn_1_text ); ?> <i class="arrow"></i></a>
        <?php endif; ?>
        <?php if ( $btn_2_text && $btn_2_url ) : ?>
            <a href="<?php echo esc_url( $btn_2_url ); ?>" class="btn btn-ghost"><?php echo esc_html( $btn_2_text ); ?></a>
        <?php endif; ?>
      </div>
    </div>
    
    <?php /* Right Side Text: Agar dono fields khali hain, toh box aur uski left line dono gayab ho jayengi */ ?>
    <?php if ( $meta_strong || $meta_desc ) : ?>
    <div class="meta">
      <?php if ( $meta_strong ) : ?>
        <strong><?php echo esc_html( $meta_strong ); ?></strong>
      <?php endif; ?>
      <?php if ( $meta_desc ) : ?>
        <?php echo esc_html( $meta_desc ); ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
  
  <?php  ?>
  <a class="scroll js-scroll-next" style="text-decoration: none; cursor: pointer;">
    <span class="line"></span> <?php echo esc_html( $scroll_text ); ?>
  </a>
</section>