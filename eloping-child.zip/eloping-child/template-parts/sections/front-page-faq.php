<?php
/**
 * Template part for displaying the FAQ section on the front page.
 * Shared site-wide: rendered after the Testimonial section on the front page and
 * injected by eloping_render_sections() on other pages. Content comes from ACF (home_faq_*)
 * with fallbacks in defaults.php under front_page > faq.
 */
// Content is always read from the Home page's FAQ tab, so it can be edited once and shared site-wide.
$faq_src = (int) get_option( 'page_on_front' );
if ( ! $faq_src ) { $faq_src = get_queried_object_id(); }
$label = get_field( 'home_faq_label', $faq_src ) ?: get_eloping_default( 'front_page', 'faq', 'label' );
$title = get_field( 'home_faq_title', $faq_src ) ?: get_eloping_default( 'front_page', 'faq', 'title' );
$intro = get_field( 'home_faq_intro', $faq_src ) ?: get_eloping_default( 'front_page', 'faq', 'intro' );
$note  = get_field( 'home_faq_note',  $faq_src ) ?: get_eloping_default( 'front_page', 'faq', 'note' );
$outro = get_field( 'home_faq_outro', $faq_src ) ?: get_eloping_default( 'front_page', 'faq', 'outro' );

$default_items = get_eloping_default( 'front_page', 'faq', 'items' );
$items = array();
for ( $i = 1; $i <= 10; $i++ ) {
    $q = get_field( 'home_faq_' . $i . '_q', $faq_src ) ?: ( isset( $default_items[ $i ]['q'] ) ? $default_items[ $i ]['q'] : '' );
    $a = get_field( 'home_faq_' . $i . '_a', $faq_src ) ?: ( isset( $default_items[ $i ]['a'] ) ? $default_items[ $i ]['a'] : '' );
    if ( $q && $a ) {
        $items[] = array( 'q' => $q, 'a' => $a );
    }
}

if ( empty( $items ) && empty( $title ) ) {
    return;
}
?>
<section id="faq" class="faq faq-home">
  <div class="faq-inner">

    <div class="head fade-in">
      <?php if ( $label ) : ?><div class="section-label"><?php echo esc_html( $label ); ?></div><?php endif; ?>
      <?php if ( $title ) : ?><h2><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
      <?php if ( $intro ) : ?><div class="faq-intro"><?php echo wpautop( wp_kses_post( $intro ) ); ?></div><?php endif; ?>
    </div>

    <?php if ( ! empty( $items ) ) : ?>
    <div class="faq-list">
      <?php foreach ( $items as $item ) : ?>
      <div class="faq-item fade-in">
        <button class="faq-q" type="button"><?php echo esc_html( $item['q'] ); ?><span class="faq-icon"></span></button>
        <div class="faq-a"><?php echo wpautop( wp_kses_post( $item['a'] ) ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ( $note ) : ?>
    <div class="faq-note fade-in"><?php echo wpautop( wp_kses_post( $note ) ); ?></div>
    <?php endif; ?>

    <?php if ( $outro ) : ?>
    <div class="faq-outro fade-in"><?php echo wpautop( wp_kses_post( $outro ) ); ?></div>
    <?php endif; ?>

  </div>
</section>
