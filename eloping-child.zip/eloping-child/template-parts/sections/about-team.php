<?php
/**
 * Template part for About Team
 */
$img    = get_field('about_team_img') ?: get_eloping_default('about', 'team', 'img');
$label  = get_field('about_team_label') ?: get_eloping_default('about', 'team', 'label');
$title  = get_field('about_team_title') ?: get_eloping_default('about', 'team', 'title');
$text_1 = get_field('about_team_text_1') ?: get_eloping_default('about', 'team', 'text_1');
$text_2 = get_field('about_team_text_2') ?: get_eloping_default('about', 'team', 'text_2');

$default_stats = get_eloping_default('about', 'team', 'stats');
$stats = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $s_num   = get_field('about_team_stat_'.$i.'_num');
    $s_label = get_field('about_team_stat_'.$i.'_label');
    $stats[$i] = array(
        'num'   => $s_num ?: (isset($default_stats[$i]['num']) ? $default_stats[$i]['num'] : ''),
        'label' => $s_label ?: (isset($default_stats[$i]['label']) ? $default_stats[$i]['label'] : ''),
    );
}
?>
<section class="ab-team">
  <div class="visual fade-in">
    <?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="Our Team" loading="lazy"/><?php endif; ?>
  </div>
  <div class="copy fade-in">
    <?php if($label): ?><div class="section-label"><?php echo esc_html($label); ?></div><?php endif; ?>
    <?php if($title): ?><h2><?php echo wp_kses_post($title); ?></h2><?php endif; ?>
    <?php if($text_1): ?><p><?php echo wp_kses_post($text_1); ?></p><?php endif; ?>
    <?php if($text_2): ?><p><?php echo wp_kses_post($text_2); ?></p><?php endif; ?>
    
    <?php if ( ! empty($stats) ) : ?>
    <div class="stat-row">
      <?php foreach ( $stats as $stat ) : ?>
      <div class="stat-item">
        <div class="num"><?php echo esc_html($stat['num']); ?></div>
        <span><?php echo esc_html($stat['label']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>