<?php
/**
 * Template part for displaying the Journal section (Dynamic Posts).
 */

$label    = get_field('home_journal_label') ?: get_eloping_default( 'front_page', 'journal', 'label' );
$title    = get_field('home_journal_title') ?: get_eloping_default( 'front_page', 'journal', 'title' );
$btn_text = get_field('home_journal_btn_text') ?: get_eloping_default( 'front_page', 'journal', 'btn_text' );
$btn_url  = get_field('home_journal_btn_url') ?: get_eloping_default( 'front_page', 'journal', 'btn_url' );

// Query latest 3 posts
$journal_query = new WP_Query( array(
    'post_type'      => 'post',
    'posts_per_page' => 3,
    'post_status'    => 'publish'
) );
?>
<section class="journal">
  <div class="head fade-in">
    <div>
      <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
      <?php endif; ?>
      <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>
    </div>
    <?php if ( $btn_text && $btn_url ) : ?>
        <a class="btn btn-dark" href="<?php echo esc_url( $btn_url ); ?>"><?php echo esc_html( $btn_text ); ?> <i class="arrow"></i></a>
    <?php endif; ?>
  </div>

  <?php if ( $journal_query->have_posts() ) : ?>
  <div class="grid">
    <?php while ( $journal_query->have_posts() ) : $journal_query->the_post(); 
        // Get primary category
        $categories = get_the_category();
        $cat_name   = ! empty( $categories ) ? $categories[0]->name : 'Journal';
        
        // --- PRO SMART READ TIME LOGIC (Hours + Minutes) ---
        $manual_time = get_field('custom_read_time', get_the_ID());
        $total_mins  = 0;

        if ( $manual_time ) {
            $total_mins = (int) $manual_time;
        } else {
            $word_count = str_word_count( strip_tags( get_post_field( 'post_content', get_the_ID() ) ) );
            $total_mins = max( 1, ceil( $word_count / 200 ) );
        }

        if ( $total_mins >= 60 ) {
            $hours = floor( $total_mins / 60 );
            $mins  = $total_mins % 60;
            $read_time = $hours . ' hr' . ( $hours > 1 ? 's' : '' ); 
            if ( $mins > 0 ) {
                $read_time .= ' ' . $mins . ' min';
            }
            $read_time .= ' read';
        } else {
            $read_time = $total_mins . ' min read';
        }
    ?>
    <a class="post fade-in" href="<?php the_permalink(); ?>">
      <div class="img">
        <?php if ( has_post_thumbnail() ) : ?>
            <img src="<?php the_post_thumbnail_url( 'large' ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy"/>
        <?php else : ?>
            <img src="<?php echo esc_url( THEME_URI . '/assets/images/exp1.jpg' ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy"/>
        <?php endif; ?>
      </div>
      <small><?php echo esc_html( $cat_name . ' · ' . $read_time ); ?></small>
      <h3><?php the_title(); ?></h3>
      <p><?php echo wp_trim_words( get_the_excerpt(), 18, '...' ); ?></p>
    </a>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>
  <?php else : ?>
    <p>No journal entries found. Add some posts in the WordPress admin.</p>
  <?php endif; ?>
</section>