<?php
/**
 * Template part for About Hero
 */
$prefix = 'about'; 

$bg_img      = get_field($prefix . '_hero_bg_img') ?: get_eloping_default($prefix, 'hero', 'bg_img');
$eyebrow     = get_field($prefix . '_hero_eyebrow') ?: get_eloping_default($prefix, 'hero', 'eyebrow');
$title       = get_field($prefix . '_hero_title') ?: get_eloping_default($prefix, 'hero', 'title');

$meta_strong = get_field($prefix . '_hero_meta_strong');
$meta_desc   = get_field($prefix . '_hero_lede'); 

// 2. Customizer Global Settings
$global_enquire_url = get_theme_mod( 'eloping_enquire_url' ) ?: home_url('/contact-us/');
$global_story_url   = get_theme_mod( 'eloping_story_url' ) ?: home_url('/#story');

// 3. Button Logic (Priority Chain: Admin ACF > Customizer Global > Hardcoded Default)
$btn_1_text  = get_field($prefix . '_hero_btn_1_text') ?: 'Begin Your Story';
$btn_1_url   = get_field($prefix . '_hero_btn_1_url') ?: $global_enquire_url;

$btn_2_text  = get_field($prefix . '_hero_btn_2_text') ?: 'Our Journey';
$btn_2_url   = get_field($prefix . '_hero_btn_2_url') ?: $global_story_url;

?>
<section class="page-hero split-hero" style="position: relative;">
  <?php if ( $bg_img ) : ?>
  <div class="bg">
    <img src="<?php echo esc_url( $bg_img ); ?>" alt="<?php echo esc_attr( wp_strip_all_tags( $title ) ); ?>" loading="eager" fetchpriority="high" />
  </div>
  <?php endif; ?>
  
  <div class="inner">
    
    <div class="left">
      <?php if ( $eyebrow ) : ?>
        <div class="eyebrow"><span class="dot"></span> <?php echo esc_html( $eyebrow ); ?></div>
      <?php endif; ?>
      
      <?php if ( $title ) : ?>
        <h1><?php echo wp_kses_post( $title ); ?></h1>
      <?php endif; ?>
      
      <div class="actions" style="margin-bottom: 28px;">
        <?php if ( $btn_1_text && $btn_1_url ) : ?>
            <a href="<?php echo esc_url( $btn_1_url ); ?>" class="btn btn-primary"><?php echo esc_html( $btn_1_text ); ?> <i class="arrow"></i></a>
        <?php endif; ?>
        <?php if ( $btn_2_text && $btn_2_url ) : ?>
            <a href="<?php echo esc_url( $btn_2_url ); ?>" class="btn btn-ghost"><?php echo esc_html( $btn_2_text ); ?></a>
        <?php endif; ?>
      </div>
      
      <div class="crumbs">
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a><span class="sep">›</span>
        <span>About Us</span>
      </div>
    </div>
    
    <?php if ( $meta_strong || $meta_desc ) : ?>
    <div class="meta">
      <?php if ( $meta_strong ) : ?>
        <strong><?php echo esc_html( $meta_strong ); ?></strong>
      <?php endif; ?>
      <?php if ( $meta_desc ) : ?>
        <?php echo wp_kses_post( $meta_desc ); ?>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

</section>