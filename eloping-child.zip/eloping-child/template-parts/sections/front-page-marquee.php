<?php
/**
 * Template part for displaying the Marquee section.
 */

$items = array();

// 1. Check if ACF Repeater has rows
if ( function_exists('have_rows') && have_rows('home_marquee_items_list') ) {
    while ( have_rows('home_marquee_items_list') ) {
        the_row();
        $items[] = get_sub_field('text');
    }
} else {
    // 2. Fallback to default items if repeater is empty
    $items = get_eloping_default( 'front_page', 'marquee', 'items' );
}

if ( empty( $items ) || ! is_array( $items ) ) {
    return; // Don't output anything if no items exist
}
?>
<div class="marquee" aria-hidden="true">
  <div class="marquee-track">
    <?php 
    // Duplicate the span twice for seamless CSS scrolling animation
    for ( $i = 0; $i < 2; $i++ ) : 
    ?>
    <span>
        <?php 
        // Output items separated by the <i class="mark"></i> element
        // Yahan end mein ek extra dot append kiya gaya hai seamless connection ke liye
        echo implode( ' <i class="mark"></i> ', array_map( 'esc_html', $items ) ) . ' <i class="mark"></i> '; 
        ?>
    </span>
    <?php endfor; ?>
  </div>
</div>