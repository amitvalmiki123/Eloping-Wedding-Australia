<?php
$head_label = get_field('pricing_inc_label') ?: get_eloping_default('pricing', 'included', 'head_label');
$head_title = get_field('pricing_inc_title') ?: get_eloping_default('pricing', 'included', 'head_title');

$default_items = get_eloping_default('pricing', 'included', 'items');
$items = array();
for ( $i = 1; $i <= 8; $i++ ) {
    $tit = get_field('pricing_inc_'.$i.'_title');
    $txt = get_field('pricing_inc_'.$i.'_text');
    $items[$i] = array(
        'title' => $tit ?: (isset($default_items[$i]['title']) ? $default_items[$i]['title'] : ''),
        'text'  => $txt ?: (isset($default_items[$i]['text']) ? $default_items[$i]['text'] : '')
    );
}
// SVGs
$svgs = array(
    1 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
    2 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
    3 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C10 6 8 8 6 10c-3 3-3 7 0 10 3 3 9 3 12 0 3-3 3-7 0-10-2-2-4-4-6-8z"/></svg>',
    4 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><circle cx="17" cy="7" r="4"/><path d="M21 21v-2a4 4 0 0 0-3-3.87"/></svg>',
    5 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><line x1="3.27" y1="6.96" x2="12" y2="12.01"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    6 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2z"/><polyline points="8 12 11 15 16 9"/></svg>',
    7 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z"/><path d="M8 8V5a4 4 0 0 1 8 0v3"/><line x1="12" y1="13" x2="12" y2="17"/></svg>',
    8 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>'
);
?>
<section class="included">
  <div class="head fade-in">
    <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
    <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
  </div>
  <?php if ( ! empty($items) ) : ?>
  <div class="inc-grid">
    <?php foreach ( $items as $index => $item ) : ?>
    <div class="inc-item fade-in">
      <div class="inc-icon"><?php echo $svgs[$index]; ?></div>
      <?php if(!empty($item['title'])): ?><h4><?php echo esc_html($item['title']); ?></h4><?php endif; ?>
      <?php if(!empty($item['text'])): ?><p><?php echo wp_kses_post($item['text']); ?></p><?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>