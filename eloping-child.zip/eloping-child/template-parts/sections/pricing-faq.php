<?php
$head_label = get_field('pricing_faq_label') ?: get_eloping_default('pricing', 'faq', 'head_label');
$head_title = get_field('pricing_faq_title') ?: get_eloping_default('pricing', 'faq', 'head_title');

$default_items = get_eloping_default('pricing', 'faq', 'items');
$items = array();
for ( $i = 1; $i <= 8; $i++ ) {
    $q = get_field('pricing_faq_'.$i.'_q');
    $a = get_field('pricing_faq_'.$i.'_a');
    $items[$i] = array(
        'q' => $q ?: (isset($default_items[$i]['q']) ? $default_items[$i]['q'] : ''),
        'a' => $a ?: (isset($default_items[$i]['a']) ? $default_items[$i]['a'] : '')
    );
}
?>
<section class="faq">
  <div class="faq-inner">
    <div class="head fade-in">
      <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
      <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
    </div>
    <?php if ( ! empty($items) ) : ?>
    <div class="faq-list">
      <?php foreach ( $items as $item ) : ?>
      <div class="faq-item fade-in">
        <button class="faq-q"><?php echo esc_html($item['q']); ?><span class="faq-icon"></span></button>
        <div class="faq-a"><p><?php echo wp_kses_post($item['a']); ?></p></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>