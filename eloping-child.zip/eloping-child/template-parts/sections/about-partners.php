<?php
/**
 * Template part for About Partners
 */
$head_label = get_field('about_part_head_label') ?: get_eloping_default('about', 'partners', 'head_label');
$head_title = get_field('about_part_head_title') ?: get_eloping_default('about', 'partners', 'head_title');
$head_text  = get_field('about_part_head_text') ?: get_eloping_default('about', 'partners', 'head_text');

$default_items = get_eloping_default('about', 'partners', 'items');
$items = array();
for ( $i = 1; $i <= 6; $i++ ) {
    $title = get_field('about_part_'.$i.'_title');
    $text  = get_field('about_part_'.$i.'_text');
    $items[$i] = array(
        'title' => $title ?: (isset($default_items[$i]['title']) ? $default_items[$i]['title'] : ''),
        'text'  => $text ?: (isset($default_items[$i]['text']) ? $default_items[$i]['text'] : '')
    );
}
?>
<section class="ab-partners">
  <div class="head fade-in">
    <div>
      <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
      <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
    </div>
    <?php if($head_text): ?><p><?php echo wp_kses_post($head_text); ?></p><?php endif; ?>
  </div>
  <?php if ( ! empty($items) ) : ?>
  <div class="part-grid">
    <?php foreach ( $items as $item ) : ?>
    <div class="part-item fade-in">
      <?php if(!empty($item['title'])): ?><h4><?php echo esc_html($item['title']); ?></h4><?php endif; ?>
      <?php if(!empty($item['text'])): ?><p><?php echo wp_kses_post($item['text']); ?></p><?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>