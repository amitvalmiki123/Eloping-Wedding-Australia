<?php
/**
 * Template part for displaying the Testimonial section.
 */

// Yahan get_field() add kiya gaya hai. 
// Note: Agar aapke ACF field ka naam kuch aur hai (e.g., 'home_testimonial_quote'), toh isko uske hisaab se update kar lena.
$quote = get_field('home_test_quote') ?: get_eloping_default( 'front_page', 'testimonial', 'quote' );
$cite  = get_field('home_test_cite') ?: get_eloping_default( 'front_page', 'testimonial', 'cite' );

if ( empty( $quote ) ) {
    return;
}
?>
<section class="testimonial">
  <div class="wrap">
    <div class="stars">★ ★ ★ ★ ★</div>
    <blockquote>
      <?php echo wp_kses_post( $quote ); ?>
    </blockquote>
    <?php if ( $cite ) : ?>
        <cite><?php echo esc_html( $cite ); ?></cite>
    <?php endif; ?>
  </div>
</section>