<?php


/**


 * Template part for Contact Form & Details (CF7 Integrated)


 */


// Details


$info_lbl = get_field('contact_info_label') ?: get_eloping_default('contact', 'form', 'info_label');


$info_tit = get_field('contact_info_title') ?: get_eloping_default('contact', 'form', 'info_title');


$info_dsc = get_field('contact_info_desc') ?: get_eloping_default('contact', 'form', 'info_desc');





$e_tit = get_field('contact_email_title') ?: get_eloping_default('contact', 'form', 'email_title');


$e_lnk = get_field('contact_email_link') ?: get_theme_mod('eloping_email_address', 'hello@elopingweddings.co.nz');


$e_sub = get_field('contact_email_sub') ?: get_eloping_default('contact', 'form', 'email_sub');





$p_tit = get_field('contact_phone_title') ?: get_eloping_default('contact', 'form', 'phone_title');


$p_lnk = get_field('contact_phone_link') ?: get_theme_mod('eloping_phone_number', '+64 21 000 000');


// Phone link ko clean karne ka logic (+ sign ko allow kar diya gaya hai)


$p_clean = preg_replace('/[^0-9+]/', '', $p_lnk);


$p_sub = get_field('contact_phone_sub') ?: get_eloping_default('contact', 'form', 'phone_sub');





$a_tit = get_field('contact_address_title') ?: get_eloping_default('contact', 'form', 'address_title');


$a_txt = get_field('contact_address_text') ?: get_eloping_default('contact', 'form', 'address_text');


$a_sub = get_field('contact_address_sub') ?: get_eloping_default('contact', 'form', 'address_sub');


$map   = get_field('contact_map_src') ?: get_eloping_default('contact', 'form', 'map_src');





// Form side


$f_tit     = get_field('contact_form_title') ?: get_eloping_default('contact', 'form', 'form_title');


$f_int     = get_field('contact_form_intro') ?: get_eloping_default('contact', 'form', 'form_intro');


$form_iframe = get_field('contact_form_iframe');





// SVGs


$svg_mail = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>';


$svg_phone = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>';


$svg_pin = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>';





// Aapki di hui exact specific location link


$map_direct_link = 'https://maps.app.goo.gl/MaPdmdskdrThpeDLA';


?>


<section class="contact-sec" style="background:var(--paper)">


  <div class="contact-info fade-in">


      <?php if($info_lbl): ?><div class="section-label"><?php echo esc_html($info_lbl); ?></div><?php endif; ?>


      <?php if($info_tit): ?><h2><?php echo wp_kses_post($info_tit); ?></h2><?php endif; ?>


      <?php if($info_dsc): ?><p class="desc"><?php echo wp_kses_post($info_dsc); ?></p><?php endif; ?>


    <div class="contact-details">


      <div class="det-item">


        <div class="det-icon"><?php echo $svg_mail; ?></div>


        <div class="det-content">


          <h4><?php echo esc_html($e_tit); ?></h4>


          <a href="mailto:<?php echo esc_attr(antispambot($e_lnk)); ?>"><?php echo esc_html(antispambot($e_lnk)); ?></a>


          <small><?php echo esc_html($e_sub); ?></small>


        </div>


      </div>


      <div class="det-item">


        <div class="det-icon"><?php echo $svg_phone; ?></div>


        <div class="det-content">


          <h4><?php echo esc_html($p_tit); ?></h4>


          <a href="tel:<?php echo esc_attr($p_clean); ?>"><?php echo esc_html($p_lnk); ?></a>


          <small><?php echo esc_html($p_sub); ?></small>


        </div>


      </div>


      <div class="det-item">


        <div class="det-icon"><?php echo $svg_pin; ?></div>


        <div class="det-content">


          <h4><?php echo esc_html($a_tit); ?></h4>


          <?php if ( $a_txt ) : ?>


            <p><a href="<?php echo esc_url($map_direct_link); ?>" target="_blank" rel="noopener noreferrer" style="color:inherit; text-decoration:none;"><?php echo wp_kses_post($a_txt); ?></a></p>


          <?php else : ?>


            <p><?php echo wp_kses_post($a_txt); ?></p>


          <?php endif; ?>


          <small><?php echo esc_html($a_sub); ?></small>


        </div>


      </div>


    </div>


    <?php if($map): ?>


    <div class="map-wrap">


      <iframe src="<?php echo esc_url($map); ?>" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


    </div>


    <?php endif; ?>


  </div>





  <div class="form-wrap fade-in">


    <?php if($f_tit): ?><h2><?php echo esc_html($f_tit); ?></h2><?php endif; ?>


    <?php if($f_int): ?><p class="intro"><?php echo wp_kses_post($f_int); ?></p><?php endif; ?>


    


    <?php if ( $form_iframe ) : ?>

    <div class="custom-studioninja-wrapper">
        <?php echo $form_iframe; ?>
    </div>

<?php else : ?>

    <p>Please add your Studio Ninja iframe embed code in the page editor.</p>

<?php endif; ?>


    


  </div>


</section>