<?php
/**
 * Template part for Queenstown Highlights
 */
$head_label = get_field('queenstown_hl_head_label') ?: get_eloping_default('queenstown', 'highlights', 'head_label');
$head_title = get_field('queenstown_hl_head_title') ?: get_eloping_default('queenstown', 'highlights', 'head_title');
$head_text  = get_field('queenstown_hl_head_text') ?: get_eloping_default('queenstown', 'highlights', 'head_text');

$default_items = get_eloping_default('queenstown', 'highlights', 'items');
$items = array();
for ( $i = 1; $i <= 6; $i++ ) {
    $num   = get_field('queenstown_hl_'.$i.'_num');
    $title = get_field('queenstown_hl_'.$i.'_title');
    $text  = get_field('queenstown_hl_'.$i.'_text');

    $items[$i] = array(
        'num'   => $num ?: (isset($default_items[$i]['num']) ? $default_items[$i]['num'] : ''),
        'title' => $title ?: (isset($default_items[$i]['title']) ? $default_items[$i]['title'] : ''),
        'text'  => $text ?: (isset($default_items[$i]['text']) ? $default_items[$i]['text'] : '')
    );
}
?>
<section class="qs-highlights">
  <div class="head fade-in">
    <div>
      <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
      <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
    </div>
    <?php if($head_text): ?><p><?php echo wp_kses_post($head_text); ?></p><?php endif; ?>
  </div>
  <?php if ( ! empty($items) ) : ?>
  <div class="hl-grid">
    <?php foreach ( $items as $item ) : ?>
    <div class="hl-item fade-in">
      <?php if(!empty($item['num'])): ?><div class="num"><?php echo esc_html($item['num']); ?></div><?php endif; ?>
      <?php if(!empty($item['title'])): ?><h3><?php echo esc_html($item['title']); ?></h3><?php endif; ?>
      <?php if(!empty($item['text'])): ?><p><?php echo wp_kses_post($item['text']); ?></p><?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>