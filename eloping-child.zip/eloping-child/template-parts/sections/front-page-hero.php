<?php
/**
 * Template part for displaying the Hero section on the Front Page.
 */

// Fetch data from ACF first, fallback to defaults.php
$bg_image    = get_field('home_hero_bg_image') ?: get_eloping_default( 'front_page', 'hero', 'bg_image' );
$eyebrow     = get_field('home_hero_eyebrow') ?: get_eloping_default( 'front_page', 'hero', 'eyebrow' );
$title       = get_field('home_hero_title') ?: get_eloping_default( 'front_page', 'hero', 'title' );
$btn_1_text  = get_field('home_hero_btn_1_text') ?: get_eloping_default( 'front_page', 'hero', 'btn_1_text' );
$btn_1_url   = get_field('home_hero_btn_1_url') ?: get_eloping_default( 'front_page', 'hero', 'btn_1_url' );
$btn_2_text  = get_field('home_hero_btn_2_text') ?: get_eloping_default( 'front_page', 'hero', 'btn_2_text' );
$btn_2_url   = get_field('home_hero_btn_2_url') ?: get_eloping_default( 'front_page', 'hero', 'btn_2_url' );
$meta_strong = get_field('home_hero_meta_strong') ?: get_eloping_default( 'front_page', 'hero', 'meta_strong' );
$meta_desc   = get_field('home_hero_meta_desc') ?: get_eloping_default( 'front_page', 'hero', 'meta_desc' );
$scroll_text = get_field('home_hero_scroll_text') ?: get_eloping_default( 'front_page', 'hero', 'scroll_text' );
?>
<section class="hero">
  <?php if ( $bg_image ) : ?>
  <div class="bg">
    <img src="<?php echo esc_url( $bg_image ); ?>" alt="Eloping Weddings Hero" loading="eager" fetchpriority="high" />
  </div>
  <?php endif; ?>

  <div class="inner">
    <div>
      <?php if ( $eyebrow ) : ?>
        <div class="eyebrow"><span class="dot"></span> <?php echo esc_html( $eyebrow ); ?></div>
      <?php endif; ?>
      
      <?php if ( $title ) : ?>
        <h1><?php echo wp_kses_post( $title ); ?></h1>
      <?php endif; ?>
      
      <div class="actions">
        <?php if ( $btn_1_text && $btn_1_url ) : ?>
            <a href="<?php echo esc_url( $btn_1_url ); ?>" class="btn btn-primary"><?php echo esc_html( $btn_1_text ); ?> <i class="arrow"></i></a>
        <?php endif; ?>
        <?php if ( $btn_2_text && $btn_2_url ) : ?>
            <a href="<?php echo esc_url( $btn_2_url ); ?>" class="btn btn-ghost"><?php echo esc_html( $btn_2_text ); ?></a>
        <?php endif; ?>
      </div>
    </div>
    
    <div class="meta">
      <?php if ( $meta_strong ) : ?>
        <strong><?php echo esc_html( $meta_strong ); ?></strong>
      <?php endif; ?>
      <?php if ( $meta_desc ) : ?>
        <?php echo esc_html( $meta_desc ); ?>
      <?php endif; ?>
    </div>
  </div>
  
  <?php if ( $scroll_text ) : ?>
    <div class="scroll"><span class="line"></span> <?php echo esc_html( $scroll_text ); ?></div>
  <?php endif; ?>
</section>