<?php
$default_pkgs = get_eloping_default('pricing', 'packages', 'pkgs');
$pkgs = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $tag   = get_field('pricing_pkg_'.$i.'_tag');
    $p_tit = get_field('pricing_pkg_'.$i.'_title');
    $p_lbl = get_field('pricing_pkg_'.$i.'_price_label');
    $p_val = get_field('pricing_pkg_'.$i.'_price_val');
    $p_cur = get_field('pricing_pkg_'.$i.'_currency'); // ADDED: Fetch currency field
    $blurb = get_field('pricing_pkg_'.$i.'_blurb');
    $b_txt = get_field('pricing_pkg_'.$i.'_btn_text');
    $b_url = get_field('pricing_pkg_'.$i.'_btn_url');

    $feats = array();
    for ( $f = 1; $f <= 10; $f++ ) {
        $feat_val = get_field('pricing_pkg_'.$i.'_feat_'.$f);
        if ( $feat_val ) $feats[] = $feat_val;
    }
    if ( empty($feats) && isset($default_pkgs[$i]['feats']) ) $feats = $default_pkgs[$i]['feats'];

    $pkgs[$i] = array(
        'tag'         => $tag ?: (isset($default_pkgs[$i]['tag']) ? $default_pkgs[$i]['tag'] : ''),
        'title'       => $p_tit ?: (isset($default_pkgs[$i]['title']) ? $default_pkgs[$i]['title'] : ''),
        'price_label' => $p_lbl ?: (isset($default_pkgs[$i]['price_label']) ? $default_pkgs[$i]['price_label'] : ''),
        'price_val'   => $p_val ?: (isset($default_pkgs[$i]['price_val']) ? $default_pkgs[$i]['price_val'] : ''),
        'currency'    => $p_cur ?: 'AUD', // ADDED: Fallback to AUD if empty
        'blurb'       => $blurb ?: (isset($default_pkgs[$i]['blurb']) ? $default_pkgs[$i]['blurb'] : ''),
        'btn_text'    => $b_txt ?: (isset($default_pkgs[$i]['btn_text']) ? $default_pkgs[$i]['btn_text'] : ''),
        'btn_url'     => $b_url ?: (isset($default_pkgs[$i]['btn_url']) ? $default_pkgs[$i]['btn_url'] : ''),
        'feats'       => $feats
    );
}
?>
<section class="pricing" id="packages">
  <?php if ( ! empty($pkgs) ) : ?>
  <div class="pkg-grid">
    <?php foreach ( $pkgs as $index => $pkg ) : 
        $class = ($index == 2) ? 'pkg featured fade-in' : 'pkg fade-in';
    ?>
    <div class="<?php echo esc_attr($class); ?>">
      <?php if(!empty($pkg['tag'])): ?><span class="tag"><?php echo esc_html($pkg['tag']); ?></span><?php endif; ?>
      <?php if(!empty($pkg['title'])): ?><h3><?php echo esc_html($pkg['title']); ?></h3><?php endif; ?>
      <div class="price">
        <!-- UPDATED: Echo dynamic currency instead of hardcoded AUD -->
        <?php echo esc_html($pkg['price_label']); ?> <strong><?php echo esc_html($pkg['price_val']); ?> <small><?php echo esc_html($pkg['currency']); ?></small></strong>
      </div>
      <?php if(!empty($pkg['blurb'])): ?><p class="blurb"><?php echo wp_kses_post($pkg['blurb']); ?></p><?php endif; ?>
      <?php if(!empty($pkg['feats'])): ?>
      <ul>
        <?php foreach($pkg['feats'] as $feat): ?><li><?php echo wp_kses_post($feat); ?></li><?php endforeach; ?>
      </ul>
      <?php endif; ?>
      <?php if(!empty($pkg['btn_text'])): ?>
        <a class="btn <?php echo ($index == 2) ? 'btn-primary' : 'btn-dark'; ?>" href="<?php echo esc_url($pkg['btn_url']); ?>"><?php echo esc_html($pkg['btn_text']); ?> <i class="arrow"></i></a>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>