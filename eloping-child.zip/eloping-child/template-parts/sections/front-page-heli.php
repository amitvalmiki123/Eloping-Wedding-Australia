<?php
/**
 * Template part for displaying the Heli Feature section with ACF Bridge.
 */

$img        = get_field('home_heli_img') ?: get_eloping_default( 'front_page', 'heli', 'img' );
$label      = get_field('home_heli_label') ?: get_eloping_default( 'front_page', 'heli', 'label' );
$title      = get_field('home_heli_title') ?: get_eloping_default( 'front_page', 'heli', 'title' );
$text       = get_field('home_heli_text') ?: get_eloping_default( 'front_page', 'heli', 'text' );
$btn_1_text = get_field('home_heli_btn_1_text') ?: get_eloping_default( 'front_page', 'heli', 'btn_1_text' );
$btn_1_url  = get_field('home_heli_btn_1_url') ?: get_eloping_default( 'front_page', 'heli', 'btn_1_url' );
$btn_2_text = get_field('home_heli_btn_2_text') ?: get_eloping_default( 'front_page', 'heli', 'btn_2_text' );
$btn_2_url  = get_field('home_heli_btn_2_url') ?: get_eloping_default( 'front_page', 'heli', 'btn_2_url' );
$tag_top    = get_field('home_heli_tag_top') ?: get_eloping_default( 'front_page', 'heli', 'tag_top' );
$tag_main   = get_field('home_heli_tag_main') ?: get_eloping_default( 'front_page', 'heli', 'tag_main' );

// Build rows dynamically
$default_list = get_eloping_default( 'front_page', 'heli', 'list' );
$list = array();
for ( $i = 1; $i <= 4; $i++ ) {
    $acf_num  = get_field('home_heli_list_' . $i . '_num');
    $acf_text = get_field('home_heli_list_' . $i . '_text');

    $list[$i] = array(
        'num'  => $acf_num ?: (isset($default_list[$i]['num']) ? $default_list[$i]['num'] : ''),
        'text' => $acf_text ?: (isset($default_list[$i]['text']) ? $default_list[$i]['text'] : ''),
    );
}
?>
<section class="heli">
  <div class="wrap">
    <div class="img">
      <?php if ( $img ) : ?>
        <img src="<?php echo esc_url( $img ); ?>" alt="Heli Elopements" loading="lazy" />
      <?php endif; ?>
    </div>
    
    <div class="content">
      <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
      <?php endif; ?>

      <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>

      <?php if ( $text ) : ?>
        <p><?php echo wp_kses_post( $text ); ?></p>
      <?php endif; ?>

      <?php if ( ! empty( $list ) ) : ?>
      <div class="heli-list">
        <?php foreach ( $list as $item ) : ?>
        <div class="row">
            <?php if ( ! empty( $item['num'] ) ) : ?>
                <strong><?php echo esc_html( $item['num'] ); ?></strong>
            <?php endif; ?>
            <?php if ( ! empty( $item['text'] ) ) : ?>
                <span><?php echo esc_html( $item['text'] ); ?></span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div class="actions">
        <?php if ( $btn_1_text && $btn_1_url ) : ?>
            <a class="btn btn-primary" href="<?php echo esc_url( $btn_1_url ); ?>"><?php echo esc_html( $btn_1_text ); ?> <i class="arrow"></i></a>
        <?php endif; ?>
        <?php if ( $btn_2_text && $btn_2_url ) : ?>
            <a class="btn btn-ghost" href="<?php echo esc_url( $btn_2_url ); ?>"><?php echo esc_html( $btn_2_text ); ?></a>
        <?php endif; ?>
      </div>

      <?php if ( $tag_top || $tag_main ) : ?>
      <div class="floating-tag">
        <?php echo esc_html( $tag_top ); ?>
        <?php if ( $tag_main ) : ?>
            <em><?php echo esc_html( $tag_main ); ?></em>nzd
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>