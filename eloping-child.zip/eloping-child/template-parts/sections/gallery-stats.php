<?php
$default_stats = get_eloping_default('gallery', 'stats', 'items');
$stats = array();
for ( $i = 1; $i <= 4; $i++ ) {
    $num = get_field('gal_st_'.$i.'_num');
    $suf = get_field('gal_st_'.$i.'_suf');
    $dec = get_field('gal_st_'.$i.'_dec');
    $lbl = get_field('gal_st_'.$i.'_lbl');
    $stats[$i] = array(
        'num' => $num ?: (isset($default_stats[$i]['num']) ? $default_stats[$i]['num'] : ''),
        'suffix' => $suf ?: (isset($default_stats[$i]['suffix']) ? $default_stats[$i]['suffix'] : ''),
        'decimal' => $dec ?: (isset($default_stats[$i]['decimal']) ? $default_stats[$i]['decimal'] : '0'),
        'label' => $lbl ?: (isset($default_stats[$i]['label']) ? $default_stats[$i]['label'] : '')
    );
}
?>
<section class="gal-stats">
  <div class="gal-stats-inner">
    <?php foreach($stats as $s): if(!empty($s['num'])): ?>
    <div class="stat fade-in">
        <div class="n" data-target="<?php echo esc_attr($s['num']); ?>" data-suffix="<?php echo esc_attr($s['suffix']); ?>" data-decimal="<?php echo esc_attr($s['decimal']); ?>">0<?php echo esc_html($s['suffix']); ?></div>
        <span class="l"><?php echo esc_html($s['label']); ?></span>
    </div>
    <?php endif; endforeach; ?>
  </div>
</section>