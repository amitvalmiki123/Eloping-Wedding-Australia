<?php
/**
 * Template part for displaying the Destinations section.
 */

// 1. Fetch Section Headers (ACF first, then fallback)
$head_title = get_field('home_dest_head_title') ?: get_eloping_default( 'front_page', 'destinations', 'head_title' );
$head_text  = get_field('home_dest_head_text') ?: get_eloping_default( 'front_page', 'destinations', 'head_text' );

// 2. Fetch Default Cards for fallback
$default_cards = get_eloping_default( 'front_page', 'destinations', 'cards' );
$cards = array();

// 3. Loop through 6 cards and check ACF fields dynamically
for ( $i = 1; $i <= 6; $i++ ) {
    $acf_img   = get_field('home_dest_' . $i . '_img');
    $acf_tag   = get_field('home_dest_' . $i . '_tag');
    $acf_title = get_field('home_dest_' . $i . '_title');
    $acf_url   = get_field('home_dest_' . $i . '_url');

    $cards[$i] = array(
        'img'   => $acf_img ?: (isset($default_cards[$i]['img']) ? $default_cards[$i]['img'] : ''),
        'tag'   => $acf_tag ?: (isset($default_cards[$i]['tag']) ? $default_cards[$i]['tag'] : ''),
        'title' => $acf_title ?: (isset($default_cards[$i]['title']) ? $default_cards[$i]['title'] : ''),
        'url'   => $acf_url ?: (isset($default_cards[$i]['url']) ? $default_cards[$i]['url'] : '#'),
    );
}
?>
<section class="destinations" id="destinations">
  <div class="dest-head fade-in">
    <?php if ( $head_title ) : ?>
        <h2><?php echo wp_kses_post( $head_title ); ?></h2>
    <?php endif; ?>

    <?php if ( $head_text ) : ?>
        <p><?php echo wp_kses_post( $head_text ); ?></p>
    <?php endif; ?>
  </div>

  <?php if ( ! empty( $cards ) ) : ?>
  <div class="dest-grid">
    <?php 
    foreach ( $cards as $index => $card ) : 
        $card_class = 'dest d' . esc_attr( $index ) . ' fade-in';
        $url        = ! empty( $card['url'] ) ? $card['url'] : '#';
    ?>
    <a class="<?php echo esc_attr( $card_class ); ?>" href="<?php echo esc_url( $url ); ?>">
      <?php if ( ! empty( $card['img'] ) ) : ?>
        <img src="<?php echo esc_url( $card['img'] ); ?>" alt="<?php echo esc_attr( wp_strip_all_tags( $card['title'] ) ); ?>" loading="lazy" />
      <?php endif; ?>
      
      <div class="cap">
        <?php if ( ! empty( $card['tag'] ) ) : ?>
            <small><?php echo esc_html( $card['tag'] ); ?></small>
        <?php endif; ?>
        
        <?php if ( ! empty( $card['title'] ) ) : ?>
            <h3><?php echo wp_kses_post( $card['title'] ); ?></h3>
        <?php endif; ?>
        
        <span class="arrow-wrap"></span>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>