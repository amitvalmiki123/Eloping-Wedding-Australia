<?php
/**
 * Template part for Queenstown Experiences
 */
$head_label = get_field('queenstown_exp_head_label') ?: get_eloping_default('queenstown', 'experiences', 'head_label');
$head_title = get_field('queenstown_exp_head_title') ?: get_eloping_default('queenstown', 'experiences', 'head_title');

$default_cards = get_eloping_default('queenstown', 'experiences', 'cards');
$cards = array();

// Yahan humne loop ko 3 se badha kar 6 kar diya hai
for ( $i = 1; $i <= 6; $i++ ) {
    $c_img   = get_field('queenstown_exp_'.$i.'_img');
    $c_tag   = get_field('queenstown_exp_'.$i.'_tag');
    $c_title = get_field('queenstown_exp_'.$i.'_title');
    $c_text  = get_field('queenstown_exp_'.$i.'_text');
    $c_price = get_field('queenstown_exp_'.$i.'_price');
    $c_url   = get_field('queenstown_exp_'.$i.'_url');

    $cards[$i] = array(
        'img'   => $c_img ?: (isset($default_cards[$i]['img']) ? $default_cards[$i]['img'] : ''),
        'tag'   => $c_tag ?: (isset($default_cards[$i]['tag']) ? $default_cards[$i]['tag'] : ''),
        'title' => $c_title ?: (isset($default_cards[$i]['title']) ? $default_cards[$i]['title'] : ''),
        'text'  => $c_text ?: (isset($default_cards[$i]['text']) ? $default_cards[$i]['text'] : ''),
        'price' => $c_price ?: (isset($default_cards[$i]['price']) ? $default_cards[$i]['price'] : ''),
        'url'   => $c_url ?: (isset($default_cards[$i]['url']) ? $default_cards[$i]['url'] : '#'),
    );
}
?>
<section class="qs-exp">
  <div class="head fade-in">
    <?php if ( $head_label ) : ?>
        <div class="section-label"><?php echo esc_html($head_label); ?></div>
    <?php endif; ?>
    <?php if ( $head_title ) : ?>
        <h2><?php echo wp_kses_post($head_title); ?></h2>
    <?php endif; ?>
  </div>
  <?php if ( ! empty($cards) ) : ?>
  <div class="exp-grid">
    <?php foreach ( $cards as $card ) : ?>
      <?php 
      // Chhoti si check lagayi hai taaki agar field khali ho toh blank card render na ho
      if( !empty($card['title']) || !empty($card['img']) ): 
      ?>
        <a class="exp-card fade-in" href="<?php echo esc_url($card['url']); ?>">
          <?php if ( !empty($card['img']) ) : ?>
            <div class="img"><img src="<?php echo esc_url($card['img']); ?>" alt="<?php echo esc_attr(wp_strip_all_tags($card['title'])); ?>" loading="lazy"/></div>
          <?php endif; ?>
          <div class="body">
            <?php if ( !empty($card['tag']) ) : ?><span class="tag"><?php echo esc_html($card['tag']); ?></span><?php endif; ?>
            <?php if ( !empty($card['title']) ) : ?><h3><?php echo esc_html($card['title']); ?></h3><?php endif; ?>
            <?php if ( !empty($card['text']) ) : ?><p><?php echo wp_kses_post($card['text']); ?></p><?php endif; ?>
            <div class="meta">
              <?php if ( !empty($card['price']) ) : ?>
                <span class="price">Starting from<strong><?php echo esc_html($card['price']); ?></strong></span>
              <?php endif; ?>
              <span class="arrow-btn" aria-hidden="true"></span>
            </div>
          </div>
        </a>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>