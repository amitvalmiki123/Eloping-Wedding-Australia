<?php
$default_slides = get_eloping_default('gallery', 'testimonial', 'slides');
$slides = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $quote = get_field('gal_test_'.$i.'_quote');
    $cite  = get_field('gal_test_'.$i.'_cite');
    if ($quote) {
        $slides[$i] = array('quote' => $quote, 'cite' => $cite);
    } elseif (isset($default_slides[$i])) {
        $slides[$i] = $default_slides[$i];
    }
}
?>
<section class="gal-test">
  <div class="wrap">
    <div class="section-label">From our couples</div>
    <?php if(!empty($slides)): ?>
    <div class="slides">
      <?php $count=0; foreach($slides as $slide): ?>
      <div class="slide <?php echo ($count==0) ? 'is-active' : ''; ?>">
        <div class="stars">★ ★ ★ ★ ★</div>
        <blockquote><?php echo wp_kses_post($slide['quote']); ?></blockquote>
        <?php if(!empty($slide['cite'])): ?><cite><?php echo esc_html($slide['cite']); ?></cite><?php endif; ?>
      </div>
      <?php $count++; endforeach; ?>
    </div>
    <div class="dots">
      <?php for($j=0; $j<count($slides); $j++): ?>
        <button class="<?php echo ($j==0) ? 'active' : ''; ?>" data-i="<?php echo $j; ?>" aria-label="Slide <?php echo $j+1; ?>"></button>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</section>