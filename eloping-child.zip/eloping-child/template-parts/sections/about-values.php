<?php
/**
 * Template part for About Values
 */
$head_label = get_field('about_val_head_label') ?: get_eloping_default('about', 'values', 'head_label');
$head_title = get_field('about_val_head_title') ?: get_eloping_default('about', 'values', 'head_title');

$default_cards = get_eloping_default('about', 'values', 'cards');
$cards = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $c_title = get_field('about_val_'.$i.'_title');
    $c_text  = get_field('about_val_'.$i.'_text');
    $cards[$i] = array(
        'title' => $c_title ?: (isset($default_cards[$i]['title']) ? $default_cards[$i]['title'] : ''),
        'text'  => $c_text ?: (isset($default_cards[$i]['text']) ? $default_cards[$i]['text'] : '')
    );
}
// SVGs are hardcoded as they usually don't change, but text is dynamic
$svgs = array(
    1 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"/><polyline points="12 6 12 12 16 14"/></svg>',
    2 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 22h20L12 2z"/><line x1="12" y1="9" x2="12" y2="17"/></svg>',
    3 => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>'
);
?>
<section class="ab-values">
  <div class="head fade-in">
    <?php if ( $head_label ) : ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
    <?php if ( $head_title ) : ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
  </div>
  <?php if ( ! empty($cards) ) : ?>
  <div class="val-grid">
    <?php foreach ( $cards as $index => $card ) : ?>
    <div class="val-card fade-in">
      <div class="val-icon"><?php echo $svgs[$index]; ?></div>
      <?php if ( !empty($card['title']) ) : ?><h3><?php echo esc_html($card['title']); ?></h3><?php endif; ?>
      <?php if ( !empty($card['text']) ) : ?><p><?php echo wp_kses_post($card['text']); ?></p><?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>