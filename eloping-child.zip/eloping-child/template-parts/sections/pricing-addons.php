<?php
$head_label = get_field('pricing_add_label') ?: get_eloping_default('pricing', 'addons', 'head_label');
$head_title = get_field('pricing_add_title') ?: get_eloping_default('pricing', 'addons', 'head_title');
$head_text  = get_field('pricing_add_text') ?: get_eloping_default('pricing', 'addons', 'head_text');

$default_items = get_eloping_default('pricing', 'addons', 'items');
$items = array();
for ( $i = 1; $i <= 8; $i++ ) {
    $tit = get_field('pricing_add_'.$i.'_title');
    $prc = get_field('pricing_add_'.$i.'_price');
    $items[$i] = array(
        'title' => $tit ?: (isset($default_items[$i]['title']) ? $default_items[$i]['title'] : ''),
        'price' => $prc ?: (isset($default_items[$i]['price']) ? $default_items[$i]['price'] : '')
    );
}
?>
<section class="addons">
  <div class="head fade-in">
    <div>
      <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
      <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
    </div>
    <?php if($head_text): ?><p><?php echo wp_kses_post($head_text); ?></p><?php endif; ?>
  </div>
  <?php if ( ! empty($items) ) : ?>
  <div class="addons-grid">
    <?php foreach ( $items as $item ) : ?>
    <div class="addon fade-in">
      <?php if(!empty($item['title'])): ?><h4><?php echo esc_html($item['title']); ?></h4><?php endif; ?>
      <?php if(!empty($item['price'])): ?>
      <div class="price">
        <!-- 'FROM' text add kar diya gaya hai -->
        <span>FROM</span>
        <strong><?php echo esc_html($item['price']); ?></strong>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>