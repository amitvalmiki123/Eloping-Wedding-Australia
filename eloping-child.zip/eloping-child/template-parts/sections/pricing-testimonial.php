<?php
/**
 * Template part for Pricing Testimonial
 */
$quote = get_field('pricing_test_quote') ?: get_eloping_default('pricing', 'testimonial', 'quote');
$cite  = get_field('pricing_test_cite') ?: get_eloping_default('pricing', 'testimonial', 'cite');

if ( empty($quote) ) return;
?>
<section class="testimonial">
  <div class="wrap">
    <div class="stars">★ ★ ★ ★ ★</div>
    <blockquote>
      <?php echo wp_kses_post( $quote ); ?>
    </blockquote>
    <?php if ( $cite ) : ?>
        <cite><?php echo esc_html( $cite ); ?></cite>
    <?php endif; ?>
  </div>
</section>