<?php
/**
 * Template part for displaying the Experience section with ACF Bridge.
 */

$label         = get_field('home_exp_label') ?: get_eloping_default( 'front_page', 'experience', 'label' );
$title         = get_field('home_exp_title') ?: get_eloping_default( 'front_page', 'experience', 'title' );
$text_1        = get_field('home_exp_text_1') ?: get_eloping_default( 'front_page', 'experience', 'text_1' );
$text_2        = get_field('home_exp_text_2') ?: get_eloping_default( 'front_page', 'experience', 'text_2' );
$img_1         = get_field('home_exp_img_1') ?: get_eloping_default( 'front_page', 'experience', 'img_1' );
$img_2         = get_field('home_exp_img_2') ?: get_eloping_default( 'front_page', 'experience', 'img_2' );
$floater_small = get_field('home_exp_floater_small') ?: get_eloping_default( 'front_page', 'experience', 'floater_small' );
$floater_main  = get_field('home_exp_floater_main') ?: get_eloping_default( 'front_page', 'experience', 'floater_main' );

// Build stats array dynamically with ACF checks
$default_stats = get_eloping_default( 'front_page', 'experience', 'stats' );
$stats = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $acf_num    = get_field('home_exp_stat_' . $i . '_num');
    $acf_suffix = get_field('home_exp_stat_' . $i . '_suffix');
    $acf_label  = get_field('home_exp_stat_' . $i . '_label');

    $stats[$i] = array(
        'num'    => $acf_num ?: (isset($default_stats[$i]['num']) ? $default_stats[$i]['num'] : ''),
        'suffix' => $acf_suffix ?: (isset($default_stats[$i]['suffix']) ? $default_stats[$i]['suffix'] : ''),
        'label'  => $acf_label ?: (isset($default_stats[$i]['label']) ? $default_stats[$i]['label'] : ''),
    );
}
?>
<section class="experience fade-in">
  <div class="copy">
    <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
    <?php endif; ?>

    <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
    <?php endif; ?>

    <?php if ( $text_1 ) : ?>
        <p><?php echo wp_kses_post( $text_1 ); ?></p>
    <?php endif; ?>

    <?php if ( $text_2 ) : ?>
        <p><?php echo wp_kses_post( $text_2 ); ?></p>
    <?php endif; ?>

    <?php if ( ! empty( $stats ) ) : ?>
    <div class="stats">
      <?php foreach ( $stats as $stat ) : ?>
      <?php 
      $num_val = (string) $stat['num'];
      $decimal_count = 0;
      if ( strpos( $num_val, '.' ) !== false ) {
          $decimal_count = strlen( substr( strrchr( $num_val, "." ), 1 ) );
      }
      ?>
      <div>
        <div class="n" data-target="<?php echo esc_attr( $stat['num'] ); ?>" data-suffix="<?php echo esc_attr( $stat['suffix'] ); ?>" data-decimal="<?php echo esc_attr( $decimal_count ); ?>">0<?php echo esc_html( $stat['suffix'] ); ?></div>
        <?php if ( ! empty( $stat['label'] ) ) : ?>
            <span class="l"><?php echo esc_html( $stat['label'] ); ?></span>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="visual">
    <?php if ( $img_1 ) : ?>
        <div class="v1"><img src="<?php echo esc_url( $img_1 ); ?>" alt="Experience Image 1" loading="lazy" /></div>
    <?php endif; ?>
    
    <?php if ( $img_2 ) : ?>
        <div class="v2"><img src="<?php echo esc_url( $img_2 ); ?>" alt="Experience Image 2" loading="lazy" /></div>
    <?php endif; ?>
    
    <?php if ( $floater_small || $floater_main ) : ?>
    <div class="floater">
        <?php if ( $floater_small ) : ?>
            <small><?php echo esc_html( $floater_small ); ?></small>
        <?php endif; ?>
        <?php echo esc_html( $floater_main ); ?>
    </div>
    <?php endif; ?>
  </div>
</section>