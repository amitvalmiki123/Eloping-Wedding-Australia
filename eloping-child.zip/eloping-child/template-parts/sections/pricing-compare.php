<?php
// Using HTML table for layout accuracy. Text content can be hardcoded here 
// or pulled from defaults if necessary. For complex tables, hardcoding structure in partial is best practice.
$head_label = get_field('pricing_cmp_label') ?: get_eloping_default('pricing', 'compare', 'head_label');
$head_title = get_field('pricing_cmp_title') ?: get_eloping_default('pricing', 'compare', 'head_title');
?>
<section class="compare">
  <div class="head fade-in">
    <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
    <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
  </div>
  <table class="tbl fade-in">
    <thead>
      <tr>
        <th>Feature</th>
        <th><span class="name">Intimate</span>$2,490</th>
        <th class="featured-col"><span class="name">Signature</span>$4,990</th>
        <th><span class="name">Heli</span>$7,990</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>Licensed celebrant</td><td><span class="check">✓</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Photography</td><td>2 hours</td><td class="featured-col-body">4 hours</td><td>6 hours</td></tr>
      <tr><td>Cinematography</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Hand-tied bouquet</td><td><span class="check">✓</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Two witnesses</td><td><span class="check">✓</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Hair &amp; make-up</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Champagne picnic</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Ceremony locations</td><td>1</td><td class="featured-col-body">2</td><td>2 + aerial</td></tr>
      <tr><td>Private helicopter</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="dash">—</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Glacier / alpine landing</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="dash">—</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Aerial drone reel</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="dash">—</span></td><td><span class="check">✓</span></td></tr>
      <tr><td>Dinner reservation</td><td><span class="dash">—</span></td><td class="featured-col-body"><span class="check">✓</span></td><td><span class="check">✓</span> chef's table</td></tr>
      <tr><td>Weather-flex re-booking</td><td>Standard</td><td class="featured-col-body">Priority</td><td>Premium</td></tr>
    </tbody>
  </table>
</section>