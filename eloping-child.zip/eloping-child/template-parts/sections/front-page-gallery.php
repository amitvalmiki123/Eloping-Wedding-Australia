<?php
/**
 * Template part for displaying the Gallery Masonry section with ACF Bridge.
 */

$label    = get_field('home_gallery_label') ?: get_eloping_default( 'front_page', 'gallery', 'label' );
$title    = get_field('home_gallery_title') ?: get_eloping_default( 'front_page', 'gallery', 'title' );
$btn_text = get_field('home_gallery_btn_text') ?: get_eloping_default( 'front_page', 'gallery', 'btn_text' );
$btn_url  = get_field('home_gallery_btn_url') ?: get_eloping_default( 'front_page', 'gallery', 'btn_url' );

// Fetch individual numbered fields for gallery images
$images = array();
for ( $i = 1; $i <= 8; $i++ ) {
    $acf_img = get_field('home_gallery_img_' . $i);
    if ( $acf_img ) {
        $images[] = $acf_img;
    }
}

// Fallback to default array if all ACF gallery fields are empty
if ( empty( $images ) ) {
    $images = get_eloping_default( 'front_page', 'gallery', 'images' );
}
?>
<section class="gallery">
  <div class="head fade-in">
    <div>
      <?php if ( $label ) : ?>
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
      <?php endif; ?>
      <?php if ( $title ) : ?>
        <h2><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>
    </div>
    <?php if ( $btn_text && $btn_url ) : ?>
        <a class="btn btn-dark" href="<?php echo esc_url( $btn_url ); ?>"><?php echo esc_html( $btn_text ); ?> <i class="arrow"></i></a>
    <?php endif; ?>
  </div>

  <?php if ( ! empty( $images ) ) : ?>
  <div class="gallery-grid">
    <?php 
    $classes = ['g-a', 'g-b', 'g-c', 'g-d', 'g-e', 'g-f', 'g-g', 'g-h'];
    foreach ( $images as $index => $img ) : 
        if ( $index >= 8 ) break;
        $tile_class = 'gtile ' . $classes[$index];
    ?>
    <div class="<?php echo esc_attr( $tile_class ); ?>">
        <img src="<?php echo esc_url( $img ); ?>" alt="Gallery Image" loading="lazy" />
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>