<?php
/**
 * Template part for Queenstown Planning Timeline
 */
$img   = get_field('queenstown_plan_img') ?: get_eloping_default('queenstown', 'plan', 'img');
$label = get_field('queenstown_plan_label') ?: get_eloping_default('queenstown', 'plan', 'label');
$title = get_field('queenstown_plan_title') ?: get_eloping_default('queenstown', 'plan', 'title');
$text  = get_field('queenstown_plan_text') ?: get_eloping_default('queenstown', 'plan', 'text');

$default_steps = get_eloping_default('queenstown', 'plan', 'steps');
$steps = array();
for ( $i = 1; $i <= 4; $i++ ) {
    $s_num   = get_field('queenstown_plan_'.$i.'_num');
    $s_title = get_field('queenstown_plan_'.$i.'_title');
    $s_text  = get_field('queenstown_plan_'.$i.'_text');
    $steps[$i] = array(
        'num'   => $s_num ?: (isset($default_steps[$i]['num']) ? $default_steps[$i]['num'] : ''),
        'title' => $s_title ?: (isset($default_steps[$i]['title']) ? $default_steps[$i]['title'] : ''),
        'text'  => $s_text ?: (isset($default_steps[$i]['text']) ? $default_steps[$i]['text'] : ''),
    );
}
?>
<section class="qs-plan">
  <div class="visual fade-in">
    <?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="Planning Timeline" loading="lazy"/><?php endif; ?>
  </div>
  <div class="copy fade-in">
    <?php if($label): ?><div class="section-label"><?php echo esc_html($label); ?></div><?php endif; ?>
    <?php if($title): ?><h2><?php echo wp_kses_post($title); ?></h2><?php endif; ?>
    <?php if($text): ?><p><?php echo wp_kses_post($text); ?></p><?php endif; ?>
    <?php if ( ! empty($steps) ) : ?>
    <div class="steps">
      <?php foreach ( $steps as $step ) : ?>
      <div class="step">
        <div class="n"><?php echo esc_html($step['num']); ?></div>
        <div>
          <strong><?php echo esc_html($step['title']); ?></strong>
          <p><?php echo wp_kses_post($step['text']); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>