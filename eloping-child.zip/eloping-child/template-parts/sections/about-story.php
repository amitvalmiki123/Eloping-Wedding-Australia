<?php
/**
 * Template part for About Story
 */
$label     = get_field('about_story_label') ?: get_eloping_default('about', 'story', 'label');
$title     = get_field('about_story_title') ?: get_eloping_default('about', 'story', 'title');
$text_1    = get_field('about_story_text_1') ?: get_eloping_default('about', 'story', 'text_1');
$text_2    = get_field('about_story_text_2') ?: get_eloping_default('about', 'story', 'text_2');
$text_3    = get_field('about_story_text_3') ?: get_eloping_default('about', 'story', 'text_3');
$signature = get_field('about_story_signature') ?: get_eloping_default('about', 'story', 'signature');
$img_main  = get_field('about_story_img_main') ?: get_eloping_default('about', 'story', 'img_main');
$img_over  = get_field('about_story_img_over') ?: get_eloping_default('about', 'story', 'img_over');
?>
<section class="ab-story fade-in">
  <div>
    <?php if ( $label ) : ?><div class="section-label"><?php echo esc_html( $label ); ?></div><?php endif; ?>
    <?php if ( $title ) : ?><h2><?php echo wp_kses_post( $title ); ?></h2><?php endif; ?>
    <?php if ( $text_1 ) : ?><p><?php echo wp_kses_post( $text_1 ); ?></p><?php endif; ?>
    <?php if ( $text_2 ) : ?><p><?php echo wp_kses_post( $text_2 ); ?></p><?php endif; ?>
    <?php if ( $text_3 ) : ?><p><?php echo wp_kses_post( $text_3 ); ?></p><?php endif; ?>
    <?php if ( $signature ) : ?><div class="sig"><?php echo esc_html( $signature ); ?></div><?php endif; ?>
  </div>
  <div class="image">
    <?php if ( $img_main ) : ?><img src="<?php echo esc_url( $img_main ); ?>" alt="Story Main" loading="lazy" /><?php endif; ?>
    <?php if ( $img_over ) : ?><div class="image-2"><img src="<?php echo esc_url( $img_over ); ?>" alt="Story Detail" loading="lazy" /></div><?php endif; ?>
  </div>
</section>