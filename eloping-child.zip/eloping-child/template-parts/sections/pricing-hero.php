<?php
$bg_img  = get_field('pricing_hero_bg_img') ?: get_eloping_default('pricing', 'hero', 'bg_img');
$eyebrow = get_field('pricing_hero_eyebrow') ?: get_eloping_default('pricing', 'hero', 'eyebrow');
$title   = get_field('pricing_hero_title') ?: get_eloping_default('pricing', 'hero', 'title');
$lede    = get_field('pricing_hero_lede') ?: get_eloping_default('pricing', 'hero', 'lede');
?>
<section class="page-hero minimal" style="min-height:50vh; background:var(--paper-2); align-items:center;">
  <?php if ( $bg_img ) : ?>
  <div class="bg-pink">
    <img src="<?php echo esc_url( $bg_img ); ?>" alt="Pricing Hero" loading="eager" fetchpriority="high" />
  </div>
  <?php endif; ?>
  <div class="inner" style="text-align:center;">
    <?php if ( $eyebrow ) : ?>
      <div class="eyebrow" style="display:inline-flex; justify-content:center;"><span class="dot"></span> <?php echo esc_html( $eyebrow ); ?></div>
    <?php endif; ?>
    <?php if ( $title ) : ?>
      <h1 style="color:var(--forest); max-width:22ch; margin-left:auto; margin-right:auto;"><?php echo wp_kses_post( $title ); ?></h1>
    <?php endif; ?>
    <?php if ( $lede ) : ?>
      <p class="lede" style="color:var(--ink);"><?php echo wp_kses_post( $lede ); ?></p>
    <?php endif; ?>
  </div>
</section>