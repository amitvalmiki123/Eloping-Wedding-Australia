<?php
/**
 * Template part for Queenstown Parallax Band
 */
$bg_img = get_field('queenstown_band_bg_img') ?: get_eloping_default('queenstown', 'band', 'bg_img');
$quote  = get_field('queenstown_band_quote') ?: get_eloping_default('queenstown', 'band', 'quote');
$cite   = get_field('queenstown_band_cite') ?: get_eloping_default('queenstown', 'band', 'cite');
?>
<section class="qs-band">
  <?php if ( $bg_img ) : ?>
    <img src="<?php echo esc_url($bg_img); ?>" alt="Queenstown panorama" loading="lazy" />
  <?php endif; ?>
  <div class="wrap">
    <span class="quote-mark">"</span>
    <?php if ( $quote ) : ?><blockquote><?php echo wp_kses_post($quote); ?></blockquote><?php endif; ?>
    <?php if ( $cite ) : ?><cite><?php echo esc_html($cite); ?></cite><?php endif; ?>
  </div>
</section>