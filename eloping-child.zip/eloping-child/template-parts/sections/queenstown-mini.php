<?php
/**
 * Template part for Queenstown Mini Gallery
 */
$head_label = get_field('queenstown_mini_label') ?: get_eloping_default('queenstown', 'mini', 'head_label');
$head_title = get_field('queenstown_mini_title') ?: get_eloping_default('queenstown', 'mini', 'head_title');

$images = array();
for ( $i = 1; $i <= 4; $i++ ) {
    $img = get_field('queenstown_mini_img_' . $i);
    if ( $img ) $images[] = $img;
}
if ( empty($images) ) {
    $images = get_eloping_default('queenstown', 'mini', 'images');
}
?>
<section class="qs-mini">
  <div class="head fade-in">
    <div>
      <?php if($head_label): ?><div class="section-label"><?php echo esc_html($head_label); ?></div><?php endif; ?>
      <?php if($head_title): ?><h2><?php echo wp_kses_post($head_title); ?></h2><?php endif; ?>
    </div>
    <a class="btn btn-dark" href="/gallery">Open full gallery <i class="arrow"></i></a>
  </div>
  <?php if ( ! empty($images) ) : ?>
  <div class="mini-grid">
    <?php foreach ( $images as $index => $img ) : 
        if ( $index >= 4 ) break;
        $class = ($index == 0 || $index == 3) ? 'mini-tile tall fade-in' : 'mini-tile fade-in';
    ?>
    <div class="<?php echo esc_attr($class); ?>">
      <img src="<?php echo esc_url($img); ?>" alt="Queenstown Gallery Image" loading="lazy"/>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>