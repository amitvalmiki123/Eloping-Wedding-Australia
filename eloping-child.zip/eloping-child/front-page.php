<?php


/**


 * Template Name: Front Page


 * The front page template file.


 */





get_header();





// List of all available sections for the front page


$front_page_sections = array(


    'hero',


    'marquee',


    'story',


    'destinations',


    'experience',


    'heli',


    'packages',


    'testimonial',


    'faq',


    'gallery',


    'journal',


    'cta'


);





// Call the render engine


?>


<main id="main" class="site-main">


    <?php eloping_render_sections( 'front_page', $front_page_sections ); ?>


</main>


<?php





get_footer();