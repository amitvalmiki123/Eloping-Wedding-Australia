<?php
/**
 * SEO Landing — ACF Pro field group registration.
 *
 * Registers every seo_* field the template reads, grouped into tabs, shown on
 * pages using the "SEO Landing" template (template-seo-landing.php). Fields
 * carry NO default_value — they start blank, and the template renders nothing
 * for a blank field. Starter copy is written once by the seeder as real,
 * editable values.
 *
 * Image/URL fields are plain text (they hold full URLs, often to the .com.au
 * media library rather than this install's Media Library), matching how the
 * template consumes them via esc_url().
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Ordered field specification: tabs + fields. Shared with the seeder so both
 * agree on which fields exist and in what order.
 *
 * Each entry: array( 'type' => 'tab'|'text'|'textarea', 'name' => '', 'label' => '', 'instructions' => '' )
 */
if ( ! function_exists( 'seo_landing_field_spec' ) ) {
    function seo_landing_field_spec() {
        // Fields that should render as a textarea in the editor.
        $textareas = array(
            'seo_hero_lede', 'seo_hero_form',
            'seo_story_text_1', 'seo_story_text_2', 'seo_story_text_3',
            'seo_story2_text_1', 'seo_story2_text_2', 'seo_story2_text_3',
            'seo_team_text_1', 'seo_team_text_2',
            'seo_love_text',
            'seo_test_quote',
            'seo_cta_text', 'seo_cta_form',
        );
        for ( $i = 1; $i <= 5; $i++ ) {
            $textareas[] = "seo_check_{$i}_intro";
            $textareas[] = "seo_check_{$i}_items";
            $textareas[] = "seo_check_{$i}_outro";
        }
        for ( $i = 1; $i <= 8; $i++ ) {
            $textareas[] = "seo_faq_{$i}_a";
        }
        $textareas = array_flip( $textareas );

        $type = function ( $name ) use ( $textareas ) {
            return isset( $textareas[ $name ] ) ? 'textarea' : 'text';
        };

        $tab = function ( $label ) {
            return array( 'type' => 'tab', 'label' => $label );
        };
        $f = function ( $name, $label, $instructions = '' ) use ( $type ) {
            return array( 'type' => $type( $name ), 'name' => $name, 'label' => $label, 'instructions' => $instructions );
        };

        $spec = array();

        // Appends one list block's fields (used by the numbered Section tabs).
        $add_list = function ( $i ) use ( &$spec, $f ) {
            $spec[] = $f( "seo_check_{$i}_id", 'Anchor ID (optional)', 'For in-page links, e.g. seo-packages.' );
            $spec[] = $f( "seo_check_{$i}_img", 'Image URL (optional)', 'Full image URL. Shown beside the list; leave blank for a centered block.' );
            $spec[] = $f( "seo_check_{$i}_img2", 'Overlap Image URL (optional)', 'Full image URL. Small photo overlapping the main image (Section-1 style).' );
            $spec[] = $f( "seo_check_{$i}_title", 'Title', 'HTML allowed.' );
            $spec[] = $f( "seo_check_{$i}_intro", 'Intro', 'Blank line = new paragraph.' );
            $spec[] = $f( "seo_check_{$i}_sub", 'List Lead-in' );
            $spec[] = $f( "seo_check_{$i}_items", 'List Items', 'One item per line.' );
            $spec[] = $f( "seo_check_{$i}_outro", 'Outro' );
        };

        /* ---- Hero ---- */
        $spec[] = $tab( 'Hero' );
        $spec[] = $f( 'seo_hero_bg_img', 'Background Image URL', 'Full image URL.' );
        $spec[] = $f( 'seo_hero_eyebrow', 'Eyebrow' );
        $spec[] = $f( 'seo_hero_title', 'Title (H1)', 'HTML allowed, e.g. wrap a word in <em>…</em>.' );
        $spec[] = $f( 'seo_hero_meta_strong', 'Lede — Strong Line' );
        $spec[] = $f( 'seo_hero_lede', 'Lede — Paragraph' );
        $spec[] = $f( 'seo_hero_btn_1_text', 'Primary Button Text' );
        $spec[] = $f( 'seo_hero_btn_1_url', 'Primary Button URL' );
        $spec[] = $f( 'seo_hero_btn_2_text', 'Secondary Button Text' );
        $spec[] = $f( 'seo_hero_btn_2_url', 'Secondary Button URL', 'Can be an anchor, e.g. #seo-packages.' );
        $spec[] = $f( 'seo_hero_form_title', 'Form — Title' );
        $spec[] = $f( 'seo_hero_form_sub', 'Form — Subtitle' );
        $spec[] = $f( 'seo_hero_form', 'Form Shortcode', 'Contact Form 7 shortcode.' );

        /* ---- Section 1 — image RIGHT / content left ---- */
        $spec[] = $tab( 'Section 1' );
        $spec[] = $f( 'seo_story_title', 'Title', 'HTML allowed.' );
        $spec[] = $f( 'seo_story_text_1', 'Paragraph 1' );
        $spec[] = $f( 'seo_story_text_2', 'Paragraph 2' );
        $spec[] = $f( 'seo_story_text_3', 'Paragraph 3' );
        $spec[] = $f( 'seo_story_signature', 'Signature (optional)' );
        $spec[] = $f( 'seo_story_img_main', 'Image URL', 'Full image URL.' );
        $spec[] = $f( 'seo_story_img_over', 'Overlay Image URL (optional)', 'Full image URL.' );

        /* ---- Section 2 — list, image LEFT / content right ---- */
        $spec[] = $tab( 'Section 2' );
        $add_list( 1 );

        /* ---- Section 3 — list, centered ---- */
        $spec[] = $tab( 'Section 3' );
        $add_list( 2 );

        /* ---- Testimonials ---- */
        $spec[] = $tab( 'Testimonials' );
        $spec[] = $f( 'seo_test_bg_img', 'Background Image URL (optional)', 'Full image URL. Shown behind the testimonial with a dark overlay.' );
        $spec[] = $f( 'seo_test_quote', 'Quote', 'Leave blank to hide the testimonial.' );
        $spec[] = $f( 'seo_test_cite', 'Attribution' );

        /* ---- Section 4 — list, image RIGHT / content left ---- */
        $spec[] = $tab( 'Section 4' );
        $add_list( 3 );

        /* ---- Section 5 — list, image LEFT / content right ---- */
        $spec[] = $tab( 'Section 5' );
        $add_list( 4 );

        /* ---- Section 6 — centered prose ---- */
        $spec[] = $tab( 'Section 6' );
        $spec[] = $f( 'seo_story2_title', 'Title', 'HTML allowed.' );
        $spec[] = $f( 'seo_story2_text_1', 'Paragraph 1' );
        $spec[] = $f( 'seo_story2_text_2', 'Paragraph 2' );
        $spec[] = $f( 'seo_story2_text_3', 'Paragraph 3' );

        /* ---- Section 7 — image RIGHT / content left ---- */
        $spec[] = $tab( 'Section 7' );
        $spec[] = $f( 'seo_team_img', 'Image URL', 'Full image URL.' );
        $spec[] = $f( 'seo_team_title', 'Title', 'HTML allowed.' );
        $spec[] = $f( 'seo_team_text_1', 'Paragraph 1' );
        $spec[] = $f( 'seo_team_text_2', 'Paragraph 2' );
        for ( $i = 1; $i <= 3; $i++ ) {
            $spec[] = $f( "seo_team_stat_{$i}_num", "Stat {$i} — Number (optional)", 'Leave blank to hide the stat row.' );
            $spec[] = $f( "seo_team_stat_{$i}_label", "Stat {$i} — Label (optional)" );
        }

        /* ---- Section 8 — list, image LEFT / content right ---- */
        $spec[] = $tab( 'Section 8' );
        $add_list( 5 );

        /* ---- Section 9 — centered prose ---- */
        $spec[] = $tab( 'Section 9' );
        $spec[] = $f( 'seo_love_title', 'Title', 'HTML allowed.' );
        $spec[] = $f( 'seo_love_text', 'Body', 'Blank line = new paragraph.' );

        /* ---- FAQ ---- */
        $spec[] = $tab( 'FAQ' );
        $spec[] = $f( 'seo_faq_title', 'Title', 'HTML allowed.' );
        for ( $i = 1; $i <= 8; $i++ ) {
            $spec[] = $f( "seo_faq_{$i}_q", "Q{$i} — Question" );
            $spec[] = $f( "seo_faq_{$i}_a", "Q{$i} — Answer", 'One line per paragraph. Also feeds FAQ schema.' );
        }

        /* ---- CTA ---- */
        $spec[] = $tab( 'CTA' );
        $spec[] = $f( 'seo_cta_bg_img', 'Background Image URL', 'Full image URL.' );
        $spec[] = $f( 'seo_cta_title', 'Title', 'HTML allowed.' );
        $spec[] = $f( 'seo_cta_text', 'Text' );
        $spec[] = $f( 'seo_cta_form_title', 'Form — Title' );
        $spec[] = $f( 'seo_cta_form_sub', 'Form — Subtitle' );
        $spec[] = $f( 'seo_cta_form', 'Form Shortcode', 'Contact Form 7 shortcode.' );

        return $spec;
    }
}

/**
 * Register the field group with ACF (Pro or free — acf_add_local_field_group
 * exists in both). Requires the template to be assigned to a page.
 */
add_action( 'acf/init', 'seo_landing_register_fields' );
function seo_landing_register_fields() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    $fields = array();

    foreach ( seo_landing_field_spec() as $item ) {
        if ( $item['type'] === 'tab' ) {
            $fields[] = array(
                'key'       => 'field_seo_tab_' . sanitize_key( $item['label'] ),
                'label'     => $item['label'],
                'name'      => '',
                'type'      => 'tab',
                'placement' => 'top',
            );
            continue;
        }

        $name  = $item['name'];
        // No default_value on purpose: fields start blank and a blank field
        // renders nothing on the front end. Starter copy is written once by
        // the seeder (inc/seo-landing-seed.php) as real, editable values.
        $field = array(
            'key'          => 'field_' . $name,
            'label'        => $item['label'],
            'name'         => $name,
            'type'         => $item['type'],
            'instructions' => isset( $item['instructions'] ) ? $item['instructions'] : '',
        );
        if ( $item['type'] === 'textarea' ) {
            $field['new_lines'] = ''; // preserve raw line breaks; template handles paragraphs
            $field['rows']      = 4;
        }
        $fields[] = $field;
    }

    acf_add_local_field_group( array(
        'key'                   => 'group_seo_landing',
        'title'                 => 'SEO Landing Content',
        'fields'                => $fields,
        'location'              => array(
            array(
                array(
                    'param'    => 'page_template',
                    'operator' => '==',
                    'value'    => 'template-seo-landing.php',
                ),
            ),
        ),
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'active'                => true,
        'description'           => 'Fields for the SEO Landing page template.',
    ) );
}