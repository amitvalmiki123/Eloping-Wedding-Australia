<?php
if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

add_action( 'acf/init', 'eloping_register_gallery_fields' );
function eloping_register_gallery_fields() {
    $fields = array();
    
// 1. HERO
    $fields[] = array( 'key' => 'tab_g_h', 'label' => 'Hero', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_g_h_eye', 'label' => 'Eyebrow', 'name' => 'gal_hero_eyebrow', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_g_h_tit', 'label' => 'Title', 'name' => 'gal_hero_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_g_h_led', 'label' => 'Lede', 'name' => 'gal_hero_lede', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_g_h_scr', 'label' => 'Scroll Text', 'name' => 'gal_hero_scroll_text', 'type' => 'text' );

    // 2. FILTERS
    $fields[] = array( 'key' => 'tab_g_flt', 'label' => 'Filters', 'type' => 'tab' );
    for ( $i = 1; $i <= 6; $i++ ) {
        $fields[] = array( 'key' => 'f_g_flt_'.$i.'_slug', 'label' => 'Filter '.$i.' Slug (e.g. queenstown)', 'name' => 'gal_flt_'.$i.'_slug', 'type' => 'text', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_g_flt_'.$i.'_lbl', 'label' => 'Filter '.$i.' Label (e.g. Queenstown)', 'name' => 'gal_flt_'.$i.'_label', 'type' => 'text', 'wrapper' => array('width' => '50') );
    }

    // 3. IMAGES (Up to 24)
    $fields[] = array( 'key' => 'tab_g_img', 'label' => 'Gallery Images', 'type' => 'tab' );
    for ( $i = 1; $i <= 24; $i++ ) {
        $fields[] = array( 'key' => 'f_g_img_'.$i.'_img', 'label' => 'Image '.$i, 'name' => 'gal_img_'.$i.'_file', 'type' => 'image', 'return_format' => 'url', 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_img_'.$i.'_cat', 'label' => 'Categories (Slugs, space separated)', 'name' => 'gal_img_'.$i.'_cat', 'type' => 'text', 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_img_'.$i.'_tag', 'label' => 'Display Tag', 'name' => 'gal_img_'.$i.'_tag', 'type' => 'text', 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_img_'.$i.'_tit', 'label' => 'Title', 'name' => 'gal_img_'.$i.'_title', 'type' => 'text', 'wrapper' => array('width' => '25') );
    }

    // 4. STATS COUNTER
    $fields[] = array( 'key' => 'tab_g_st', 'label' => 'Stats Counter', 'type' => 'tab' );
    for ( $i = 1; $i <= 4; $i++ ) {
        $fields[] = array( 'key' => 'f_g_st_'.$i.'_n', 'label' => 'Number '.$i, 'name' => 'gal_st_'.$i.'_num', 'type' => 'text', 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_st_'.$i.'_s', 'label' => 'Suffix (e.g. + or yrs)', 'name' => 'gal_st_'.$i.'_suf', 'type' => 'text', 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_st_'.$i.'_d', 'label' => 'Decimals', 'name' => 'gal_st_'.$i.'_dec', 'type' => 'number', 'default_value' => 0, 'wrapper' => array('width' => '25') );
        $fields[] = array( 'key' => 'f_g_st_'.$i.'_l', 'label' => 'Label', 'name' => 'gal_st_'.$i.'_lbl', 'type' => 'text', 'wrapper' => array('width' => '25') );
    }

    // 5. TESTIMONIAL
    $fields[] = array( 'key' => 'tab_g_test', 'label' => 'Testimonial (Carousel)', 'type' => 'tab' );
    for ( $i = 1; $i <= 3; $i++ ) {
        $fields[] = array( 'key' => 'f_g_tst_'.$i.'_qot', 'label' => 'Slide '.$i.' Quote', 'name' => 'gal_test_'.$i.'_quote', 'type' => 'textarea', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_g_tst_'.$i.'_cit', 'label' => 'Slide '.$i.' Citation', 'name' => 'gal_test_'.$i.'_cite', 'type' => 'text', 'wrapper' => array('width' => '50') );
    }

    // 6. CTA
    $fields[] = array( 'key' => 'tab_g_cta', 'label' => 'CTA', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_g_cta_bg', 'label' => 'Background Image', 'name' => 'gal_cta_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_g_cta_tit', 'label' => 'Title', 'name' => 'gal_cta_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_g_cta_txt', 'label' => 'Text', 'name' => 'gal_cta_text', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_g_cta_b1t', 'label' => 'Button 1 Text', 'name' => 'gal_cta_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_g_cta_b1u', 'label' => 'Button 1 URL', 'name' => 'gal_cta_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_g_cta_b2t', 'label' => 'Button 2 Text', 'name' => 'gal_cta_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_g_cta_b2u', 'label' => 'Button 2 URL', 'name' => 'gal_cta_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );

    acf_add_local_field_group( array(
        'key'      => 'group_gallery',
        'title'    => 'Gallery Settings',
        'fields'   => $fields,
        'location' => array( array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-gallery.php' ) ) ),
        'style'    => 'default', 'hide_on_screen' => array('the_content'),
    ) );
}