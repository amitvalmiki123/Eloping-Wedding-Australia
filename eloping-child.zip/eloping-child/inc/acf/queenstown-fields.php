<?php
if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

add_action( 'acf/init', 'eloping_register_queenstown_fields' );
function eloping_register_queenstown_fields() {
    $fields = array();

    // 1. HERO
    $fields[] = array( 'key' => 'tab_qt_hero', 'label' => 'Hero', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qt_hero_bg', 'label' => 'Background Image', 'name' => 'queenstown_hero_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'field_qt_hero_eye', 'label' => 'Eyebrow', 'name' => 'queenstown_hero_eyebrow', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qt_hero_title', 'label' => 'Title', 'name' => 'queenstown_hero_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qt_hero_lede', 'label' => 'Lede / Meta Text', 'name' => 'queenstown_hero_lede', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qt_hero_btn1_t', 'label' => 'Button 1 Text', 'name' => 'queenstown_hero_btn_1_text', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qt_hero_btn1_u', 'label' => 'Button 1 URL', 'name' => 'queenstown_hero_btn_1_url', 'type' => 'url' );
    $fields[] = array( 'key' => 'field_qt_hero_btn2_t', 'label' => 'Button 2 Text', 'name' => 'queenstown_hero_btn_2_text', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qt_hero_btn2_u', 'label' => 'Button 2 URL', 'name' => 'queenstown_hero_btn_2_url', 'type' => 'url' );
    $fields[] = array( 'key' => 'field_qt_hero_meta_s', 'label' => 'Meta Bold Text', 'name' => 'queenstown_hero_meta_strong', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qt_hero_scroll', 'label' => 'Scroll Text', 'name' => 'queenstown_hero_scroll_text', 'type' => 'text' );

    // 2. INTRO
    $fields[] = array( 'key' => 'tab_qs_intro', 'label' => 'Intro Story', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_in_lbl', 'label' => 'Label', 'name' => 'queenstown_intro_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_in_title', 'label' => 'Title', 'name' => 'queenstown_intro_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_in_t1', 'label' => 'Paragraph 1', 'name' => 'queenstown_intro_text_1', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_in_t2', 'label' => 'Paragraph 2', 'name' => 'queenstown_intro_text_2', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_in_sig', 'label' => 'Signature', 'name' => 'queenstown_intro_signature', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_in_img1', 'label' => 'Main Image', 'name' => 'queenstown_intro_img_main', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'field_qs_in_img2', 'label' => 'Overlay Image', 'name' => 'queenstown_intro_img_over', 'type' => 'image', 'return_format' => 'url' );

// 3. EXPERIENCES
    $fields[] = array( 'key' => 'tab_qs_exp', 'label' => 'Experiences', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_exp_hlbl', 'label' => 'Section Label', 'name' => 'queenstown_exp_head_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_exp_htit', 'label' => 'Section Title', 'name' => 'queenstown_exp_head_title', 'type' => 'textarea' );
    
    // Yahan humne limit 3 se badha kar 6 kar di hai
    for ( $i = 1; $i <= 6; $i++ ) {
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_img', 'label' => 'Card '.$i.' Image', 'name' => 'queenstown_exp_'.$i.'_img', 'type' => 'image', 'return_format' => 'url', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_tag', 'label' => 'Card '.$i.' Tag', 'name' => 'queenstown_exp_'.$i.'_tag', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_tit', 'label' => 'Card '.$i.' Title', 'name' => 'queenstown_exp_'.$i.'_title', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_txt', 'label' => 'Card '.$i.' Text', 'name' => 'queenstown_exp_'.$i.'_text', 'type' => 'textarea' );
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_prc', 'label' => 'Card '.$i.' Price', 'name' => 'queenstown_exp_'.$i.'_price', 'type' => 'text', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_qs_exp_'.$i.'_url', 'label' => 'Card '.$i.' URL', 'name' => 'queenstown_exp_'.$i.'_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    }

    // 4. HIGHLIGHTS
    $fields[] = array( 'key' => 'tab_qs_hl', 'label' => 'Highlights', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_hl_hlbl', 'label' => 'Section Label', 'name' => 'queenstown_hl_head_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_hl_htit', 'label' => 'Section Title', 'name' => 'queenstown_hl_head_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_hl_htxt', 'label' => 'Section Text', 'name' => 'queenstown_hl_head_text', 'type' => 'textarea' );
    for ( $i = 1; $i <= 6; $i++ ) {
        $fields[] = array( 'key' => 'f_qs_hl_'.$i.'_num', 'label' => 'Item '.$i.' Number', 'name' => 'queenstown_hl_'.$i.'_num', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_qs_hl_'.$i.'_tit', 'label' => 'Item '.$i.' Title', 'name' => 'queenstown_hl_'.$i.'_title', 'type' => 'text', 'wrapper' => array('width' => '66') );
        $fields[] = array( 'key' => 'f_qs_hl_'.$i.'_txt', 'label' => 'Item '.$i.' Text', 'name' => 'queenstown_hl_'.$i.'_text', 'type' => 'textarea' );
    }

    // 5. BAND
    $fields[] = array( 'key' => 'tab_qs_band', 'label' => 'Parallax Band', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_bnd_img', 'label' => 'Background Image', 'name' => 'queenstown_band_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'field_qs_bnd_qot', 'label' => 'Quote', 'name' => 'queenstown_band_quote', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_bnd_cit', 'label' => 'Citation', 'name' => 'queenstown_band_cite', 'type' => 'text' );

    // 6. PLAN
    $fields[] = array( 'key' => 'tab_qs_plan', 'label' => 'Planning', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_pln_img', 'label' => 'Image', 'name' => 'queenstown_plan_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'field_qs_pln_lbl', 'label' => 'Label', 'name' => 'queenstown_plan_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_pln_tit', 'label' => 'Title', 'name' => 'queenstown_plan_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_pln_txt', 'label' => 'Text', 'name' => 'queenstown_plan_text', 'type' => 'textarea' );
    for ( $i = 1; $i <= 4; $i++ ) {
        $fields[] = array( 'key' => 'f_qs_pln_'.$i.'_num', 'label' => 'Step '.$i.' Num', 'name' => 'queenstown_plan_'.$i.'_num', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_qs_pln_'.$i.'_tit', 'label' => 'Step '.$i.' Title', 'name' => 'queenstown_plan_'.$i.'_title', 'type' => 'text', 'wrapper' => array('width' => '66') );
        $fields[] = array( 'key' => 'f_qs_pln_'.$i.'_txt', 'label' => 'Step '.$i.' Text', 'name' => 'queenstown_plan_'.$i.'_text', 'type' => 'textarea' );
    }

    // 7. TESTIMONIAL
    $fields[] = array( 'key' => 'tab_qs_test', 'label' => 'Testimonial', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_tst_qot', 'label' => 'Quote', 'name' => 'queenstown_test_quote', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_tst_cit', 'label' => 'Citation', 'name' => 'queenstown_test_cite', 'type' => 'text' );

    // 8. MINI GALLERY
    $fields[] = array( 'key' => 'tab_qs_mini', 'label' => 'Mini Gallery', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_min_lbl', 'label' => 'Section Label', 'name' => 'queenstown_mini_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_qs_min_tit', 'label' => 'Section Title', 'name' => 'queenstown_mini_title', 'type' => 'textarea' );
    for ( $i = 1; $i <= 4; $i++ ) {
        $fields[] = array( 'key' => 'f_qs_min_'.$i.'_img', 'label' => 'Image '.$i, 'name' => 'queenstown_mini_img_'.$i, 'type' => 'image', 'return_format' => 'url', 'wrapper' => array('width' => '25') );
    }

    // 9. CTA
    $fields[] = array( 'key' => 'tab_qs_cta', 'label' => 'CTA', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_qs_cta_bg', 'label' => 'Background Image', 'name' => 'queenstown_cta_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'field_qs_cta_tit', 'label' => 'Title', 'name' => 'queenstown_cta_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_cta_txt', 'label' => 'Text', 'name' => 'queenstown_cta_text', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_qs_cta_b1t', 'label' => 'Button 1 Text', 'name' => 'queenstown_cta_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'field_qs_cta_b1u', 'label' => 'Button 1 URL', 'name' => 'queenstown_cta_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'field_qs_cta_b2t', 'label' => 'Button 2 Text', 'name' => 'queenstown_cta_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'field_qs_cta_b2u', 'label' => 'Button 2 URL', 'name' => 'queenstown_cta_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );

    // MAGIC PART: Mapping ALL templates to this single field group
    acf_add_local_field_group( array(
        'key'      => 'group_queenstown',
        'title'    => 'Destination / Inner Page Settings',
        'fields'   => $fields,
        'location' => array( 
            // Queenstown Pages
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-queenstown.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-queenstown-lakeside.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-queenstown-garden.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-queenstown-heli.php' ) ),
            
            // Wanaka Pages
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-wanaka.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-wanaka-lake.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-wanaka-heli.php' ) ),
            
            // Destinations & Other Inner Pages
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-destinations.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-mtcook-heli.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-heli-elopement.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-same-sex.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-proposal.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-proposal-classic.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-proposal-heli.php' ) ),

            // Destination Pages
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-destinations.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-abel-tasman.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-auckland.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-bay-of-islands.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-coromandel.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-cruise.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-hobbiton.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-mt-maunganui.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-napier.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-rotorua.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-taupo.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-tekapo.php' ) ),
            array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-dest-waiheke.php' ) )
        ),
        'style'    => 'default', 
        'hide_on_screen' => array('the_content'),
    ) );
}