<?php


/**


 * ACF Free Local Field Group for Front Page


 * Follows Rule 2: No repeaters, strict tab organization, programmatic generation for scale.


 */





if ( ! function_exists( 'acf_add_local_field_group' ) ) {


    return; // Stop if ACF is not installed [cite: 55]


}





add_action( 'acf/init', 'eloping_register_front_page_fields' ); // Hook to acf/init [cite: 54]





function eloping_register_front_page_fields() {





    $fields = array();





    // ------------------------------------------------------------------


    // 1. HERO TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_hero', 'label' => 'Hero Section', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_hero_bg_image', 'label' => 'Background Image', 'name' => 'home_hero_bg_image', 'type' => 'image', 'return_format' => 'url' ); // Image returns URL [cite: 57]


    $fields[] = array( 'key' => 'field_home_hero_eyebrow', 'label' => 'Eyebrow Text', 'name' => 'home_hero_eyebrow', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_hero_title', 'label' => 'Title', 'name' => 'home_hero_title', 'type' => 'textarea', 'instructions' => 'Use <em> tag for italics.' );


    $fields[] = array( 'key' => 'field_home_hero_btn_1_text', 'label' => 'Button 1 Text', 'name' => 'home_hero_btn_1_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_hero_btn_1_url', 'label' => 'Button 1 URL', 'name' => 'home_hero_btn_1_url', 'type' => 'url' );


    $fields[] = array( 'key' => 'field_home_hero_btn_2_text', 'label' => 'Button 2 Text', 'name' => 'home_hero_btn_2_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_hero_btn_2_url', 'label' => 'Button 2 URL', 'name' => 'home_hero_btn_2_url', 'type' => 'url' );


    $fields[] = array( 'key' => 'field_home_hero_meta_strong', 'label' => 'Meta Bold Text', 'name' => 'home_hero_meta_strong', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_hero_meta_desc', 'label' => 'Meta Description', 'name' => 'home_hero_meta_desc', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_hero_scroll_text', 'label' => 'Scroll Text', 'name' => 'home_hero_scroll_text', 'type' => 'text' );





// ------------------------------------------------------------------


    // 2. MARQUEE TAB (Converted to Repeater)


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_marquee', 'label' => 'Marquee Items', 'type' => 'tab' );


    


    $fields[] = array(


        'key'           => 'field_home_marquee_repeater',


        'label'         => 'Marquee List',


        'name'          => 'home_marquee_items_list',


        'type'          => 'repeater',


        'layout'        => 'table', // Table layout keeps it clean for single text fields


        'button_label'  => 'Add Marquee Item',


        'sub_fields'    => array(


            array( 


                'key'   => 'field_home_marquee_item_text', 


                'label' => 'Item Text', 


                'name'  => 'text', 


                'type'  => 'text' 


            )


        )


    );





    // ------------------------------------------------------------------


    // 3. STORY TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_story', 'label' => 'Story Section', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_story_label', 'label' => 'Section Label', 'name' => 'home_story_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_story_title', 'label' => 'Title', 'name' => 'home_story_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_story_text_1', 'label' => 'Paragraph 1', 'name' => 'home_story_text_1', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_story_text_2', 'label' => 'Paragraph 2', 'name' => 'home_story_text_2', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_story_signature', 'label' => 'Signature Text', 'name' => 'home_story_signature', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_story_img_main', 'label' => 'Main Image', 'name' => 'home_story_img_main', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'field_home_story_badge', 'label' => 'Badge Text', 'name' => 'home_story_badge', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_story_img_overlay', 'label' => 'Overlay Image', 'name' => 'home_story_img_overlay', 'type' => 'image', 'return_format' => 'url' );





    // ------------------------------------------------------------------


    // 4. DESTINATIONS TAB (6 Cards generated via loop) [cite: 49, 50]


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_destinations', 'label' => 'Destinations Grid', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_dest_head_title', 'label' => 'Section Head Title', 'name' => 'home_dest_head_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_dest_head_text', 'label' => 'Section Head Text', 'name' => 'home_dest_head_text', 'type' => 'textarea' );


    


    for ( $i = 1; $i <= 6; $i++ ) {


        $fields[] = array( 'key' => 'field_home_dest_' . $i . '_img', 'label' => 'Card ' . $i . ' Image', 'name' => 'home_dest_' . $i . '_img', 'type' => 'image', 'return_format' => 'url', 'wrapper' => array('width' => '25') );


        $fields[] = array( 'key' => 'field_home_dest_' . $i . '_tag', 'label' => 'Card ' . $i . ' Tag', 'name' => 'home_dest_' . $i . '_tag', 'type' => 'text', 'wrapper' => array('width' => '25') );


        $fields[] = array( 'key' => 'field_home_dest_' . $i . '_title', 'label' => 'Card ' . $i . ' Title', 'name' => 'home_dest_' . $i . '_title', 'type' => 'text', 'wrapper' => array('width' => '25') );


        $fields[] = array( 'key' => 'field_home_dest_' . $i . '_url', 'label' => 'Card ' . $i . ' URL', 'name' => 'home_dest_' . $i . '_url', 'type' => 'url', 'wrapper' => array('width' => '25') );


    }





    // ------------------------------------------------------------------


    // 5. EXPERIENCE TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_experience', 'label' => 'Experience', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_exp_label', 'label' => 'Section Label', 'name' => 'home_exp_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_exp_title', 'label' => 'Title', 'name' => 'home_exp_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_exp_text_1', 'label' => 'Paragraph 1', 'name' => 'home_exp_text_1', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_exp_text_2', 'label' => 'Paragraph 2', 'name' => 'home_exp_text_2', 'type' => 'textarea' );


    


    for ( $i = 1; $i <= 3; $i++ ) {


        $fields[] = array( 'key' => 'field_home_exp_stat_' . $i . '_num', 'label' => 'Stat ' . $i . ' Number', 'name' => 'home_exp_stat_' . $i . '_num', 'type' => 'text', 'wrapper' => array('width' => '33') );


        $fields[] = array( 'key' => 'field_home_exp_stat_' . $i . '_suffix', 'label' => 'Stat ' . $i . ' Suffix', 'name' => 'home_exp_stat_' . $i . '_suffix', 'type' => 'text', 'wrapper' => array('width' => '33') );


        $fields[] = array( 'key' => 'field_home_exp_stat_' . $i . '_label', 'label' => 'Stat ' . $i . ' Label', 'name' => 'home_exp_stat_' . $i . '_label', 'type' => 'text', 'wrapper' => array('width' => '33') );


    }


    


    $fields[] = array( 'key' => 'field_home_exp_img_1', 'label' => 'Image 1', 'name' => 'home_exp_img_1', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'field_home_exp_img_2', 'label' => 'Image 2', 'name' => 'home_exp_img_2', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'field_home_exp_floater_small', 'label' => 'Floater Small Text', 'name' => 'home_exp_floater_small', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_exp_floater_main', 'label' => 'Floater Main Text', 'name' => 'home_exp_floater_main', 'type' => 'textarea' );





    // ------------------------------------------------------------------


    // 6. HELI FEATURE TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_heli', 'label' => 'Heli Feature', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_heli_img', 'label' => 'Feature Image', 'name' => 'home_heli_img', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'field_home_heli_label', 'label' => 'Section Label', 'name' => 'home_heli_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_heli_title', 'label' => 'Title', 'name' => 'home_heli_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_heli_text', 'label' => 'Paragraph', 'name' => 'home_heli_text', 'type' => 'textarea' );


    


    for ( $i = 1; $i <= 4; $i++ ) {


        $fields[] = array( 'key' => 'field_home_heli_list_' . $i . '_num', 'label' => 'List Item ' . $i . ' Number', 'name' => 'home_heli_list_' . $i . '_num', 'type' => 'text', 'wrapper' => array('width' => '20') );


        $fields[] = array( 'key' => 'field_home_heli_list_' . $i . '_text', 'label' => 'List Item ' . $i . ' Text', 'name' => 'home_heli_list_' . $i . '_text', 'type' => 'text', 'wrapper' => array('width' => '80') );


    }





    $fields[] = array( 'key' => 'field_home_heli_btn_1_text', 'label' => 'Button 1 Text', 'name' => 'home_heli_btn_1_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_heli_btn_1_url', 'label' => 'Button 1 URL', 'name' => 'home_heli_btn_1_url', 'type' => 'url' );


    $fields[] = array( 'key' => 'field_home_heli_btn_2_text', 'label' => 'Button 2 Text', 'name' => 'home_heli_btn_2_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_heli_btn_2_url', 'label' => 'Button 2 URL', 'name' => 'home_heli_btn_2_url', 'type' => 'url' );


    $fields[] = array( 'key' => 'field_home_heli_tag_top', 'label' => 'Tag Top Text', 'name' => 'home_heli_tag_top', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_heli_tag_main', 'label' => 'Tag Price/Main', 'name' => 'home_heli_tag_main', 'type' => 'text' );





    // ------------------------------------------------------------------


    // 7. PACKAGES TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_packages', 'label' => 'Packages', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_pkg_label', 'label' => 'Section Label', 'name' => 'home_pkg_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_pkg_title', 'label' => 'Section Title', 'name' => 'home_pkg_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_pkg_text', 'label' => 'Section Text', 'name' => 'home_pkg_text', 'type' => 'textarea' );





    for ( $i = 1; $i <= 3; $i++ ) {


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_tag', 'label' => 'Pkg ' . $i . ' Tag', 'name' => 'home_pkg_' . $i . '_tag', 'type' => 'text' );


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_title', 'label' => 'Pkg ' . $i . ' Title', 'name' => 'home_pkg_' . $i . '_title', 'type' => 'text' );


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_price_label', 'label' => 'Pkg ' . $i . ' Price Label', 'name' => 'home_pkg_' . $i . '_price_label', 'type' => 'text' );


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_price_val', 'label' => 'Pkg ' . $i . ' Price Value', 'name' => 'home_pkg_' . $i . '_price_val', 'type' => 'text' );


        


        for ( $f = 1; $f <= 5; $f++ ) { // 5 Features per package


            $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_feat_' . $f, 'label' => 'Pkg ' . $i . ' Feature ' . $f, 'name' => 'home_pkg_' . $i . '_feat_' . $f, 'type' => 'text' );


        }


        


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_btn_text', 'label' => 'Pkg ' . $i . ' Button Text', 'name' => 'home_pkg_' . $i . '_btn_text', 'type' => 'text' );


        $fields[] = array( 'key' => 'field_home_pkg_' . $i . '_btn_url', 'label' => 'Pkg ' . $i . ' Button URL', 'name' => 'home_pkg_' . $i . '_btn_url', 'type' => 'url' );


    }





    // ------------------------------------------------------------------


    // 8. TESTIMONIAL TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_testimonial', 'label' => 'Testimonial', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_test_quote', 'label' => 'Quote Text', 'name' => 'home_test_quote', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_test_cite', 'label' => 'Citation', 'name' => 'home_test_cite', 'type' => 'text' );

    // ------------------------------------------------------------------
    // 8b. FAQ TAB (shown after the Testimonial section)
    // ------------------------------------------------------------------
    $fields[] = array( 'key' => 'tab_faq', 'label' => 'FAQ', 'type' => 'tab' );
    $fields[] = array( 'key' => 'field_home_faq_label', 'label' => 'Section Label', 'name' => 'home_faq_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'field_home_faq_title', 'label' => 'Section Title', 'name' => 'home_faq_title', 'type' => 'textarea', 'instructions' => 'Use <em> tag for italics.' );
    $fields[] = array( 'key' => 'field_home_faq_intro', 'label' => 'Intro Text', 'name' => 'home_faq_intro', 'type' => 'textarea' );
    for ( $i = 1; $i <= 10; $i++ ) {
        $fields[] = array( 'key' => 'field_home_faq_' . $i . '_q', 'label' => 'FAQ ' . $i . ' Question', 'name' => 'home_faq_' . $i . '_q', 'type' => 'text' );
        $fields[] = array( 'key' => 'field_home_faq_' . $i . '_a', 'label' => 'FAQ ' . $i . ' Answer', 'name' => 'home_faq_' . $i . '_a', 'type' => 'textarea', 'instructions' => 'Leave a blank line between paragraphs.' );
    }
    $fields[] = array( 'key' => 'field_home_faq_note', 'label' => 'Closing Note (e.g. permits)', 'name' => 'home_faq_note', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'field_home_faq_outro', 'label' => 'Outro Line', 'name' => 'home_faq_outro', 'type' => 'textarea' );





    // ------------------------------------------------------------------


    // 9. GALLERY TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_gallery', 'label' => 'Gallery Masonry', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_gallery_label', 'label' => 'Section Label', 'name' => 'home_gallery_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_gallery_title', 'label' => 'Section Title', 'name' => 'home_gallery_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_gallery_btn_text', 'label' => 'Button Text', 'name' => 'home_gallery_btn_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_gallery_btn_url', 'label' => 'Button URL', 'name' => 'home_gallery_btn_url', 'type' => 'url' );





    for ( $i = 1; $i <= 8; $i++ ) {


        $fields[] = array( 'key' => 'field_home_gallery_img_' . $i, 'label' => 'Gallery Image ' . $i, 'name' => 'home_gallery_img_' . $i, 'type' => 'image', 'return_format' => 'url', 'wrapper' => array('width' => '25') );


    }





    // ------------------------------------------------------------------


    // 10. JOURNAL TAB (Header only, Posts are dynamic)


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_journal', 'label' => 'Journal Header', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_journal_label', 'label' => 'Section Label', 'name' => 'home_journal_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_journal_title', 'label' => 'Section Title', 'name' => 'home_journal_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_journal_btn_text', 'label' => 'Button Text', 'name' => 'home_journal_btn_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_journal_btn_url', 'label' => 'Button URL', 'name' => 'home_journal_btn_url', 'type' => 'url' );





    // ------------------------------------------------------------------


    // 11. CTA BAND TAB


    // ------------------------------------------------------------------


    $fields[] = array( 'key' => 'tab_cta', 'label' => 'CTA Band', 'type' => 'tab' );


    $fields[] = array( 'key' => 'field_home_cta_bg_img', 'label' => 'Background Image', 'name' => 'home_cta_bg_img', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'field_home_cta_title', 'label' => 'Title', 'name' => 'home_cta_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_cta_text', 'label' => 'Paragraph Text', 'name' => 'home_cta_text', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'field_home_cta_btn_1_text', 'label' => 'Button 1 Text', 'name' => 'home_cta_btn_1_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_cta_btn_1_url', 'label' => 'Button 1 URL', 'name' => 'home_cta_btn_1_url', 'type' => 'url' );


    $fields[] = array( 'key' => 'field_home_cta_btn_2_text', 'label' => 'Button 2 Text', 'name' => 'home_cta_btn_2_text', 'type' => 'text' );


    $fields[] = array( 'key' => 'field_home_cta_btn_2_url', 'label' => 'Button 2 URL', 'name' => 'home_cta_btn_2_url', 'type' => 'url' );





    // Register the grouped fields into ACF [cite: 53]


    acf_add_local_field_group( array(


        'key'                   => 'group_front_page',


        'title'                 => 'Front Page Content',


        'fields'                => $fields,


        'location'              => array(


            array(


                array(


                    'param'    => 'page_type', // Location Rule [cite: 71]


                    'operator' => '==',


                    'value'    => 'front_page',


                ),


            ),


        ),


        'menu_order'            => 0,


        'position'              => 'normal',


        'style'                 => 'default',


        'label_placement'       => 'top',


        'instruction_placement' => 'label',


        'hide_on_screen'        => array('the_content'), // Hide default editor to keep UI clean


        'active'                => true,


        'description'           => 'Manage content for the homepage.',


    ) );


}