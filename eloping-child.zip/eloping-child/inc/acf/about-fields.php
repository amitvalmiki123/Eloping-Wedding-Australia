<?php
if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

add_action( 'acf/init', 'eloping_register_about_fields' );
function eloping_register_about_fields() {
    $fields = array();

    // 1. HERO
    $fields[] = array( 'key' => 'tab_ab_hero', 'label' => 'Hero', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_h_bg', 'label' => 'Background Image', 'name' => 'about_hero_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_ab_h_eye', 'label' => 'Eyebrow', 'name' => 'about_hero_eyebrow', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_h_tit', 'label' => 'Title', 'name' => 'about_hero_title', 'type' => 'textarea' );
    
    // Yahan humne right meta ki missing fields add ki hain
    $fields[] = array( 'key' => 'f_ab_h_meta_str', 'label' => 'Meta Strong Title', 'name' => 'about_hero_meta_strong', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_h_led', 'label' => 'Lede / Meta Text', 'name' => 'about_hero_lede', 'type' => 'textarea' );
    
    // Yahan humne buttons ki missing fields add ki hain
    $fields[] = array( 'key' => 'f_ab_h_b1t', 'label' => 'Button 1 Text', 'name' => 'about_hero_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_h_b1u', 'label' => 'Button 1 URL', 'name' => 'about_hero_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_h_b2t', 'label' => 'Button 2 Text', 'name' => 'about_hero_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_h_b2u', 'label' => 'Button 2 URL', 'name' => 'about_hero_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );

    // 2. STORY
    $fields[] = array( 'key' => 'tab_ab_story', 'label' => 'Story', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_s_lbl', 'label' => 'Label', 'name' => 'about_story_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_s_tit', 'label' => 'Title', 'name' => 'about_story_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_s_t1', 'label' => 'Paragraph 1', 'name' => 'about_story_text_1', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_s_t2', 'label' => 'Paragraph 2', 'name' => 'about_story_text_2', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_s_t3', 'label' => 'Paragraph 3', 'name' => 'about_story_text_3', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_s_sig', 'label' => 'Signature', 'name' => 'about_story_signature', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_s_mimg', 'label' => 'Main Image', 'name' => 'about_story_img_main', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_ab_s_oimg', 'label' => 'Overlay Image', 'name' => 'about_story_img_over', 'type' => 'image', 'return_format' => 'url' );

    // 3. VALUES
    $fields[] = array( 'key' => 'tab_ab_val', 'label' => 'Values', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_v_hlbl', 'label' => 'Head Label', 'name' => 'about_val_head_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_v_htit', 'label' => 'Head Title', 'name' => 'about_val_head_title', 'type' => 'textarea' );
    for ( $i = 1; $i <= 3; $i++ ) {
        $fields[] = array( 'key' => 'f_ab_v_'.$i.'_tit', 'label' => 'Card '.$i.' Title', 'name' => 'about_val_'.$i.'_title', 'type' => 'text' );
        $fields[] = array( 'key' => 'f_ab_v_'.$i.'_txt', 'label' => 'Card '.$i.' Text', 'name' => 'about_val_'.$i.'_text', 'type' => 'textarea' );
    }

    // 4. TEAM
    $fields[] = array( 'key' => 'tab_ab_team', 'label' => 'Team', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_t_img', 'label' => 'Image', 'name' => 'about_team_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_ab_t_lbl', 'label' => 'Label', 'name' => 'about_team_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_t_tit', 'label' => 'Title', 'name' => 'about_team_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_t_t1', 'label' => 'Paragraph 1', 'name' => 'about_team_text_1', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_t_t2', 'label' => 'Paragraph 2', 'name' => 'about_team_text_2', 'type' => 'textarea' );
    for ( $i = 1; $i <= 3; $i++ ) {
        $fields[] = array( 'key' => 'f_ab_ts_'.$i.'_num', 'label' => 'Stat '.$i.' Number', 'name' => 'about_team_stat_'.$i.'_num', 'type' => 'text', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_ab_ts_'.$i.'_lbl', 'label' => 'Stat '.$i.' Label', 'name' => 'about_team_stat_'.$i.'_label', 'type' => 'text', 'wrapper' => array('width' => '50') );
    }

    // 5. PARTNERS
    $fields[] = array( 'key' => 'tab_ab_part', 'label' => 'Partners', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_p_hlbl', 'label' => 'Head Label', 'name' => 'about_part_head_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_ab_p_htit', 'label' => 'Head Title', 'name' => 'about_part_head_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_p_htxt', 'label' => 'Head Text', 'name' => 'about_part_head_text', 'type' => 'textarea' );
    for ( $i = 1; $i <= 6; $i++ ) {
        $fields[] = array( 'key' => 'f_ab_p_'.$i.'_tit', 'label' => 'Item '.$i.' Title', 'name' => 'about_part_'.$i.'_title', 'type' => 'text' );
        $fields[] = array( 'key' => 'f_ab_p_'.$i.'_txt', 'label' => 'Item '.$i.' Text', 'name' => 'about_part_'.$i.'_text', 'type' => 'textarea' );
    }

    // 6. TESTIMONIAL
    $fields[] = array( 'key' => 'tab_ab_test', 'label' => 'Testimonial', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_tst_qot', 'label' => 'Quote', 'name' => 'about_test_quote', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_tst_cit', 'label' => 'Citation', 'name' => 'about_test_cite', 'type' => 'text' );

    // 7. CTA
    $fields[] = array( 'key' => 'tab_ab_cta', 'label' => 'CTA', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_ab_cta_bg', 'label' => 'Background Image', 'name' => 'about_cta_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_ab_cta_tit', 'label' => 'Title', 'name' => 'about_cta_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_cta_txt', 'label' => 'Text', 'name' => 'about_cta_text', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_ab_cta_b1t', 'label' => 'Button 1 Text', 'name' => 'about_cta_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_cta_b1u', 'label' => 'Button 1 URL', 'name' => 'about_cta_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_cta_b2t', 'label' => 'Button 2 Text', 'name' => 'about_cta_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_ab_cta_b2u', 'label' => 'Button 2 URL', 'name' => 'about_cta_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );

    acf_add_local_field_group( array(
        'key'      => 'group_about',
        'title'    => 'About Us Settings',
        'fields'   => $fields,
        'location' => array( array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-about.php' ) ) ),
        'style'    => 'default', 'hide_on_screen' => array('the_content'),
    ) );
}