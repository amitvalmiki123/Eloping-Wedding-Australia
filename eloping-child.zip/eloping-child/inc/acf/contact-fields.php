<?php


if ( ! function_exists( 'acf_add_local_field_group' ) ) return;





add_action( 'acf/init', 'eloping_register_contact_fields' );


function eloping_register_contact_fields() {


    $fields = array();





    // 1. HERO


    $fields[] = array( 'key' => 'tab_cnt_hero', 'label' => 'Hero', 'type' => 'tab' );


    $fields[] = array( 'key' => 'f_cnt_h_bg', 'label' => 'Background Image', 'name' => 'contact_hero_bg_img', 'type' => 'image', 'return_format' => 'url' );


    $fields[] = array( 'key' => 'f_cnt_h_eye', 'label' => 'Eyebrow', 'name' => 'contact_hero_eyebrow', 'type' => 'text' );


    $fields[] = array( 'key' => 'f_cnt_h_tit', 'label' => 'Title', 'name' => 'contact_hero_title', 'type' => 'textarea' );


    


    // Yahan humne right meta ki missing fields add ki hain


    $fields[] = array( 'key' => 'f_cnt_h_meta_str', 'label' => 'Meta Strong Title', 'name' => 'contact_hero_meta_title', 'type' => 'text' );


    $fields[] = array( 'key' => 'f_cnt_h_led', 'label' => 'Lede / Meta Text', 'name' => 'contact_hero_lede', 'type' => 'textarea' );


    


    // Yahan humne buttons ki missing fields add ki hain


    $fields[] = array( 'key' => 'f_cnt_h_b1t', 'label' => 'Button 1 Text', 'name' => 'contact_hero_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );


    $fields[] = array( 'key' => 'f_cnt_h_b1u', 'label' => 'Button 1 URL', 'name' => 'contact_hero_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );


    $fields[] = array( 'key' => 'f_cnt_h_b2t', 'label' => 'Button 2 Text', 'name' => 'contact_hero_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );


    $fields[] = array( 'key' => 'f_cnt_h_b2u', 'label' => 'Button 2 URL', 'name' => 'contact_hero_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );





    // Scroll Text


    $fields[] = array( 'key' => 'f_cnt_h_scr', 'label' => 'Scroll Text', 'name' => 'contact_hero_scroll_text', 'type' => 'text' );








    // 2. CONTACT DETAILS


    $fields[] = array( 'key' => 'tab_cnt_info', 'label' => 'Contact Details', 'type' => 'tab' );


    $fields[] = array( 'key' => 'f_cnt_i_lbl', 'label' => 'Section Label', 'name' => 'contact_info_label', 'type' => 'text' );


    $fields[] = array( 'key' => 'f_cnt_i_tit', 'label' => 'Section Title', 'name' => 'contact_info_title', 'type' => 'textarea' );


    $fields[] = array( 'key' => 'f_cnt_i_dsc', 'label' => 'Description', 'name' => 'contact_info_desc', 'type' => 'textarea' );


    


    $fields[] = array( 'key' => 'f_cnt_e_tit', 'label' => 'Email Title', 'name' => 'contact_email_title', 'type' => 'text', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_e_lnk', 'label' => 'Email Address', 'name' => 'contact_email_link', 'type' => 'text', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_e_sub', 'label' => 'Email Subtext', 'name' => 'contact_email_sub', 'type' => 'text', 'wrapper' => array('width' => '33') );


    


    $fields[] = array( 'key' => 'f_cnt_p_tit', 'label' => 'Phone Title', 'name' => 'contact_phone_title', 'type' => 'text', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_p_lnk', 'label' => 'Phone Number', 'name' => 'contact_phone_link', 'type' => 'text', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_p_sub', 'label' => 'Phone Subtext', 'name' => 'contact_phone_sub', 'type' => 'text', 'wrapper' => array('width' => '33') );


    


    $fields[] = array( 'key' => 'f_cnt_a_tit', 'label' => 'Address Title', 'name' => 'contact_address_title', 'type' => 'text', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_a_txt', 'label' => 'Address Text', 'name' => 'contact_address_text', 'type' => 'textarea', 'wrapper' => array('width' => '33') );


    $fields[] = array( 'key' => 'f_cnt_a_sub', 'label' => 'Address Subtext', 'name' => 'contact_address_sub', 'type' => 'text', 'wrapper' => array('width' => '33') );


    


    $fields[] = array( 'key' => 'f_cnt_map', 'label' => 'Google Map iFrame URL (src)', 'name' => 'contact_map_src', 'type' => 'url', 'instructions' => 'Only paste the URL from the src="..." attribute of the Google Maps iframe.' );





    // 3. FORM TEXT & SHORTCODE


    $fields[] = array( 'key' => 'tab_cnt_form', 'label' => 'Form Settings', 'type' => 'tab' );


    $fields[] = array( 'key' => 'f_cnt_f_tit', 'label' => 'Form Title', 'name' => 'contact_form_title', 'type' => 'text' );


    $fields[] = array( 'key' => 'f_cnt_f_int', 'label' => 'Form Intro', 'name' => 'contact_form_intro', 'type' => 'textarea' );


    



// Studio Ninja Embed Code
$fields[] = array(
    'key'           => 'field_contact_form_iframe',
    'label'         => 'Studio Ninja Embed Code',
    'name'          => 'contact_form_iframe',
    'type'          => 'textarea',
    'instructions'  => 'Paste the complete Studio Ninja iframe embed code here.',
    'required'      => 0,
    'rows'          => 8,
    'new_lines'     => '',
);






    acf_add_local_field_group( array(


        'key'      => 'group_contact',


        'title'    => 'Contact Settings',


        'fields'   => $fields,


        'location' => array( array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-contact.php' ) ) ),


        'style'    => 'default', 'hide_on_screen' => array('the_content'),


    ) );


}