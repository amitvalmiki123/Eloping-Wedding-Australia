<?php
if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

add_action( 'acf/init', 'eloping_register_pricing_fields' );
function eloping_register_pricing_fields() {
    $fields = array();

// 1. HERO
    $fields[] = array( 'key' => 'tab_prc_hero', 'label' => 'Hero', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_h_bg', 'label' => 'Background Image', 'name' => 'pricing_hero_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_prc_h_eye', 'label' => 'Eyebrow', 'name' => 'pricing_hero_eyebrow', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_prc_h_tit', 'label' => 'Title', 'name' => 'pricing_hero_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_h_led', 'label' => 'Lede', 'name' => 'pricing_hero_lede', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_h_scr', 'label' => 'Scroll Text', 'name' => 'pricing_hero_scroll_text', 'type' => 'text' );
    
    // 2. PACKAGES
    $fields[] = array( 'key' => 'tab_prc_pkg', 'label' => 'Packages', 'type' => 'tab' );
    for ( $i = 1; $i <= 3; $i++ ) {
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_tag', 'label' => 'Pkg '.$i.' Tag', 'name' => 'pricing_pkg_'.$i.'_tag', 'type' => 'text' );
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_tit', 'label' => 'Pkg '.$i.' Title', 'name' => 'pricing_pkg_'.$i.'_title', 'type' => 'text' );
        
        // UPDATED: Width set to 33 and Currency field added
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_lbl', 'label' => 'Pkg '.$i.' Price Label', 'name' => 'pricing_pkg_'.$i.'_price_label', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_val', 'label' => 'Pkg '.$i.' Price Value', 'name' => 'pricing_pkg_'.$i.'_price_val', 'type' => 'text', 'wrapper' => array('width' => '33') );
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_cur', 'label' => 'Pkg '.$i.' Currency', 'name' => 'pricing_pkg_'.$i.'_currency', 'type' => 'text', 'default_value' => 'AUD', 'wrapper' => array('width' => '33') );
        
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_blb', 'label' => 'Pkg '.$i.' Blurb', 'name' => 'pricing_pkg_'.$i.'_blurb', 'type' => 'textarea' );
        for ( $f = 1; $f <= 10; $f++ ) {
            $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_f_'.$f, 'label' => 'Feature '.$f, 'name' => 'pricing_pkg_'.$i.'_feat_'.$f, 'type' => 'text' );
        }
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_bt', 'label' => 'Btn Text', 'name' => 'pricing_pkg_'.$i.'_btn_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_prc_pkg_'.$i.'_bu', 'label' => 'Btn URL', 'name' => 'pricing_pkg_'.$i.'_btn_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    }

    // 3. INCLUDED
    $fields[] = array( 'key' => 'tab_prc_inc', 'label' => 'Included Features', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_inc_lbl', 'label' => 'Head Label', 'name' => 'pricing_inc_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_prc_inc_tit', 'label' => 'Head Title', 'name' => 'pricing_inc_title', 'type' => 'textarea' );
    for ( $i = 1; $i <= 8; $i++ ) {
        $fields[] = array( 'key' => 'f_prc_inc_'.$i.'_tit', 'label' => 'Item '.$i.' Title', 'name' => 'pricing_inc_'.$i.'_title', 'type' => 'text' );
        $fields[] = array( 'key' => 'f_prc_inc_'.$i.'_txt', 'label' => 'Item '.$i.' Text', 'name' => 'pricing_inc_'.$i.'_text', 'type' => 'textarea' );
    }

    // 4. ADD-ONS
    $fields[] = array( 'key' => 'tab_prc_add', 'label' => 'Add-ons', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_add_lbl', 'label' => 'Head Label', 'name' => 'pricing_add_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_prc_add_tit', 'label' => 'Head Title', 'name' => 'pricing_add_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_add_txt', 'label' => 'Head Text', 'name' => 'pricing_add_text', 'type' => 'textarea' );
    for ( $i = 1; $i <= 8; $i++ ) {
        $fields[] = array( 'key' => 'f_prc_add_'.$i.'_tit', 'label' => 'Add-on '.$i.' Title', 'name' => 'pricing_add_'.$i.'_title', 'type' => 'text', 'wrapper' => array('width' => '50') );
        $fields[] = array( 'key' => 'f_prc_add_'.$i.'_prc', 'label' => 'Add-on '.$i.' Price', 'name' => 'pricing_add_'.$i.'_price', 'type' => 'text', 'wrapper' => array('width' => '50') );
    }

    // 5. COMPARE (Headings only)
    $fields[] = array( 'key' => 'tab_prc_cmp', 'label' => 'Compare', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_cmp_lbl', 'label' => 'Head Label', 'name' => 'pricing_cmp_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_prc_cmp_tit', 'label' => 'Head Title', 'name' => 'pricing_cmp_title', 'type' => 'textarea' );

    // 6. FAQ
    $fields[] = array( 'key' => 'tab_prc_faq', 'label' => 'FAQ', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_faq_lbl', 'label' => 'Head Label', 'name' => 'pricing_faq_label', 'type' => 'text' );
    $fields[] = array( 'key' => 'f_prc_faq_tit', 'label' => 'Head Title', 'name' => 'pricing_faq_title', 'type' => 'textarea' );
    for ( $i = 1; $i <= 8; $i++ ) {
        $fields[] = array( 'key' => 'f_prc_faq_'.$i.'_q', 'label' => 'Question '.$i, 'name' => 'pricing_faq_'.$i.'_q', 'type' => 'text' );
        $fields[] = array( 'key' => 'f_prc_faq_'.$i.'_a', 'label' => 'Answer '.$i, 'name' => 'pricing_faq_'.$i.'_a', 'type' => 'textarea' );
    }

    // 7. TESTIMONIAL
    $fields[] = array( 'key' => 'tab_prc_test', 'label' => 'Testimonial', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_tst_qot', 'label' => 'Quote', 'name' => 'pricing_test_quote', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_tst_cit', 'label' => 'Citation', 'name' => 'pricing_test_cite', 'type' => 'text' );

    // 8. CTA
    $fields[] = array( 'key' => 'tab_prc_cta', 'label' => 'CTA', 'type' => 'tab' );
    $fields[] = array( 'key' => 'f_prc_cta_bg', 'label' => 'Background Image', 'name' => 'pricing_cta_bg_img', 'type' => 'image', 'return_format' => 'url' );
    $fields[] = array( 'key' => 'f_prc_cta_tit', 'label' => 'Title', 'name' => 'pricing_cta_title', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_cta_txt', 'label' => 'Text', 'name' => 'pricing_cta_text', 'type' => 'textarea' );
    $fields[] = array( 'key' => 'f_prc_cta_b1t', 'label' => 'Button 1 Text', 'name' => 'pricing_cta_btn_1_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_prc_cta_b1u', 'label' => 'Button 1 URL', 'name' => 'pricing_cta_btn_1_url', 'type' => 'url', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_prc_cta_b2t', 'label' => 'Button 2 Text', 'name' => 'pricing_cta_btn_2_text', 'type' => 'text', 'wrapper' => array('width' => '50') );
    $fields[] = array( 'key' => 'f_prc_cta_b2u', 'label' => 'Button 2 URL', 'name' => 'pricing_cta_btn_2_url', 'type' => 'url', 'wrapper' => array('width' => '50') );

    acf_add_local_field_group( array(
        'key'      => 'group_pricing',
        'title'    => 'Pricing Settings',
        'fields'   => $fields,
        'location' => array( array( array( 'param' => 'page_template', 'operator' => '==', 'value' => 'template-pricing.php' ) ) ),
        'style'    => 'default', 'hide_on_screen' => array('the_content'),
    ) );
}