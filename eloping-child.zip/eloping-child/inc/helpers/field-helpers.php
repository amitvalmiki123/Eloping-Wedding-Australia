<?php
/**
 * ACF & Defaults Bridge
 * Implements Rule 3: Checks ACF first, falls back to defaults, outputs nothing if both empty.
 */

function get_eloping_field( $acf_field_name, $page, $section, $key = null, $subkey = null ) {
    $value = '';

    // Step 1: Check if ACF is active and field exists 
    if ( function_exists( 'get_field' ) ) {
        $acf_value = get_field( $acf_field_name );
        if ( ! empty( $acf_value ) ) {
            $value = $acf_value;
        }
    }

    // Step 2: If ACF is empty, fallback to defaults.php 
    if ( empty( $value ) ) {
        global $eloping_defaults;
        
        if ( isset( $eloping_defaults[$page][$section] ) ) {
            if ( $key ) {
                if ( $subkey && isset( $eloping_defaults[$page][$section][$key][$subkey] ) ) {
                    $value = $eloping_defaults[$page][$section][$key][$subkey];
                } elseif ( isset( $eloping_defaults[$page][$section][$key] ) && ! $subkey ) {
                    $value = $eloping_defaults[$page][$section][$key];
                }
            } else {
                $value = $eloping_defaults[$page][$section];
            }
        }
    }

    // Step 3: Return value or strictly nothing [cite: 79, 80]
    return $value;
}

// Override original default fetcher to seamlessly use the bridge
// (Replace the small helper in defaults.php with this logic internally)