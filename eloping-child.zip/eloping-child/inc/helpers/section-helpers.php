<?php


/**


 * Section Rendering Engine


 * Filters, sorts, and renders template parts dynamically.


 */





function eloping_render_sections( $page_id, $sections ) {


    $rendered_sections = array();





    foreach ( $sections as $section ) {


        // Get show/order from defaults


        $show  = get_eloping_default( $page_id, $section, 'show' );


        $order = get_eloping_default( $page_id, $section, 'order' );





        if ( $show ) {


            while ( isset( $rendered_sections[(string)$order] ) ) {


                $order += 0.1; 


            }


            $rendered_sections[(string)$order] = $section;


        }


    }





    ksort( $rendered_sections );





    // FIX: Convert 'front_page' to 'front-page' for matching filenames


    $file_prefix = str_replace( '_', '-', $page_id );





    /*
     * Shared FAQ: the front page FAQ (template-parts/sections/front-page-faq.php) is also
     * shown on the About page and every page built on the destination layout
     * (Destinations, the 10 destination pages, Heli Elopements, Same Sex, Proposals).
     * It is inserted directly after the Testimonial section. Gallery, Pricing, Contact,
     * legal, thank-you and SEO landing pages are not in this list and are unaffected.
     */
    $shared_faq_pages = apply_filters( 'eloping_shared_faq_pages', array( 'about', 'queenstown' ) );
    $inject_faq       = in_array( $page_id, $shared_faq_pages, true ) && ! in_array( 'faq', $rendered_sections, true );

    if ( $inject_faq ) {
        $ordered = array_values( $rendered_sections );
        $pos     = array_search( 'testimonial', $ordered, true );
        if ( false === $pos ) {
            $pos = array_search( 'cta', $ordered, true );
            $pos = ( false === $pos ) ? count( $ordered ) : $pos;
        } else {
            $pos = $pos + 1;
        }
        array_splice( $ordered, $pos, 0, array( 'shared-faq' ) );
        $rendered_sections = $ordered;
    }

    foreach ( $rendered_sections as $section ) {
        if ( 'shared-faq' === $section ) {
            get_template_part( 'template-parts/sections/front-page', 'faq' );
            continue;
        }
        get_template_part( 'template-parts/sections/' . $file_prefix, $section );
    }


}