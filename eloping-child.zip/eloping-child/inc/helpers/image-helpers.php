<?php
/**
 * Image Helper
 * Implements Rule 15: Image Alt Text with 3-Tier Fallback
 */

function get_eloping_image_alt( $image_url, $acf_alt_field = '', $default_alt = '' ) {
    $alt_text = '';

    // Tier 1: Try to get alt text from WordPress Media Library using URL
    $attachment_id = attachment_url_to_postid( $image_url );
    if ( $attachment_id ) {
        $alt_text = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
    }

    // Tier 2: Dedicated ACF alt text field (if provided and Tier 1 is empty)
    if ( empty( $alt_text ) && ! empty( $acf_alt_field ) && function_exists( 'get_field' ) ) {
        $alt_text = get_field( $acf_alt_field );
    }

    // Tier 3: Fallback string or empty string
    if ( empty( $alt_text ) ) {
        $alt_text = $default_alt;
    }

    return esc_attr( $alt_text );
}