<?php
/**
 * SEO Landing — starter content for the ONE-TIME seeder.
 *
 * Returns a flat map of ACF field name => starter value. This is the ONLY
 * consumer: inc/seo-landing-seed.php writes these into a page's ACF fields
 * once, as real editable values. The template and the ACF fields carry no
 * defaults of their own — a blank field renders nothing on the front end.
 *
 * Contact Form 7: seo_hero_form / seo_cta_form use the elopingweddings.com.au
 * "SEO Forms" form (id "db74934").
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'seo_landing_defaults' ) ) {
    function seo_landing_defaults() {
        $form = '[contact-form-7 id="db74934" title="SEO Forms"]';

        $d = array(

            /* ---------------- HERO ---------------- */
            'seo_hero_bg_img'    => 'https://elopingweddings.com.au/wp-content/uploads/2026/07/Ellie-Flynn-edits52-scaled.jpg-1.webp',
            'seo_hero_eyebrow'   => 'Elopement Planning · Australia',
            'seo_hero_title'     => 'Australian Elopement Planner for Couples Who Want a Wedding That Feels Like <em>Them</em>',
            'seo_hero_meta_strong' => 'A wedding day that feels like you.',
            'seo_hero_lede'      => 'Create a calm, intimate, and beautifully personal wedding day with an Australian elopement planner who brings every essential detail together. At Eloping Weddings, we help couples plan meaningful ceremonies with celebrants, photography, flowers, witnesses, legal guidance, and thoughtful extras arranged with care.',
            'seo_hero_btn_1_text' => 'Start Planning Your Elopement',
            'seo_hero_btn_1_url' => home_url( '/contact-us/' ),
            'seo_hero_btn_2_text' => 'View Elopement Packages',
            'seo_hero_btn_2_url' => '#seo-packages',
            'seo_hero_form_title' => 'Start Planning Your Elopement',
            'seo_hero_form_sub'  => 'Tell us a little about the day you imagine and we\'ll be in touch.',
            'seo_hero_form'      => $form,

            /* ---------------- STORY — A More Meaningful Way ---------------- */
            'seo_story_title'    => 'A More Meaningful Way to <em>Get Married</em>',
            'seo_story_text_1'   => 'At Eloping Weddings, we believe eloping is not about making your wedding smaller. It is about choosing a ceremony that feels honest, beautiful, and centred on your relationship. With an Australian elopement planner, you can enjoy the significance of a wedding day without the pressure of a large celebration.',
            'seo_story_text_2'   => 'Your elopement can be simple, cinematic, adventurous, luxurious, or quietly romantic. You might exchange vows barefoot on the sand, stand above a windswept coastline, walk through a tropical garden, or share champagne after a private ceremony for two.',
            'seo_story_text_3'   => 'We help shape the day so it feels carefully planned without feeling overworked. There are fewer distractions, fewer opinions, and fewer moving parts, so you can focus on your vows, your setting, your photographs, and the first moments of married life.',
            'seo_story_signature' => '',
            'seo_story_img_main' => 'https://elopingweddings.com.au/wp-content/uploads/2026/06/R6KA1398-scaled-1.webp',
            'seo_story_img_over' => '',

            /* ---------------- STORY 2 — Legal Support ---------------- */
            'seo_story2_title'   => 'Legal Elopement Support <em>Made Simple</em>',
            'seo_story2_text_1'  => 'Legal marriage in Australia requires the correct documents, timing, celebrant involvement, declarations, and witnesses. These steps are straightforward when handled properly, but they can feel confusing if you are planning from another state, living overseas, or organising everything for the first time.',
            'seo_story2_text_2'  => 'With an Australian elopement planner, you receive guidance that helps the formal side of your ceremony feel clear and manageable. We can help you understand the planning timeline and connect you with authorised celebrant support, while your celebrant manages the legal marriage process.',
            'seo_story2_text_3'  => 'Your elopement can still feel romantic, relaxed, and deeply personal while being properly organised. You can focus on writing your vows, choosing your setting, and imagining the day, knowing the important legal steps are being considered from the beginning.',

            /* ---------------- TEAM — Photography ---------------- */
            'seo_team_img'       => 'https://elopingweddings.com.au/wp-content/uploads/2026/05/Eloping-Wedding-7.jpg',
            'seo_team_title'     => 'Photography That Captures the <em>Feeling of the Day</em>',
            'seo_team_text_1'    => 'Elopement photography is one of the most important parts of the experience. With fewer guests and a more relaxed timeline, your photographer can capture the quiet emotion, natural movement, scenery, and atmosphere of the day. As your Australian elopement planner, we help align your ceremony location, time of day, styling, and timeline with the kind of imagery you want.',
            'seo_team_text_2'    => 'Light, walking distance, privacy, weather, and ceremony timing all influence how your gallery will feel. A thoughtfully planned elopement gives your photographer time to document more than the ceremony — getting ready moments, first looks, vows, portraits, champagne, landscapes, and the small details that tell the full story of your day.',
            'seo_team_stat_1_num' => '',
            'seo_team_stat_1_label' => '',
            'seo_team_stat_2_num' => '',
            'seo_team_stat_2_label' => '',
            'seo_team_stat_3_num' => '',
            'seo_team_stat_3_label' => '',

            /* ---------------- LOVE STORY — Start Planning ---------------- */
            'seo_love_title'     => 'Start Planning Your Australian Elopement',
            'seo_love_text'      => "Your wedding does not need to be large to be unforgettable. It does not need to follow every tradition to feel meaningful. With an Australian elopement planner, your day can be calm, romantic, organised, and fully centred on the two of you.\n\nTell us what you imagine. Share the places you are drawn to, the feeling you want, and the details that matter most.\n\nFrom there, our team can help shape your location, ceremony, celebrant, photography, florals, legal guidance, timeline, and optional extras into an elopement experience that feels effortless from beginning to end.",

            /* ---------------- FAQ ---------------- */
            'seo_faq_title'      => 'Frequently Asked <em>Questions</em>',

            /* ---------------- TESTIMONIAL (quote blank — add a real review) ---------------- */
            'seo_test_bg_img'    => 'https://elopingweddings.com.au/wp-content/uploads/2026/07/Ellie-Flynn-edits52-scaled.jpg-1.webp',
            'seo_test_quote'     => '',
            'seo_test_cite'      => '',

            /* ---------------- CTA ---------------- */
            'seo_cta_bg_img'     => 'https://elopingweddings.com.au/wp-content/uploads/2026/07/Ellie-Flynn-edits52-scaled.jpg-1.webp',
            'seo_cta_title'      => 'Start Planning Your Australian Elopement',
            'seo_cta_text'       => 'Tell us what you imagine — the places you are drawn to, the feeling you want, and the details that matter most. From there, our team can help shape it all into an elopement experience that feels effortless from beginning to end.',
            'seo_cta_form_title' => 'Let\'s Start Planning',
            'seo_cta_form_sub'   => 'Share a few details and one of our planners will be in touch personally.',
            'seo_cta_form'       => $form,
        );

        /* ---------------- CHECKLIST BLOCKS 1–5 ---------------- */
        $checklists = array(
            1 => array(
                'id'    => '',
                'label' => 'Full-Service Planning',
                'title' => 'What We Can Help You <em>Plan</em>',
                'intro' => 'Working with an Australian elopement planner means you do not need to piece every supplier, document, and decision together on your own. Our team brings the practical, creative, and emotional details into one calm planning experience.',
                'sub'   => 'Your elopement planning support may include:',
                'items' => "Ceremony location guidance\nRegistered celebrant coordination\nLegal paperwork support\nPhotography planning\nFloral design\nWitness arrangements\nHair and make-up recommendations\nCeremony styling\nTimeline planning\nWet weather guidance\nTransport suggestions\nPrivate dining recommendations\nPicnic, champagne, or cake options\nAccommodation guidance\nOptional adventure experiences",
                'outro' => 'Every couple imagines eloping differently. Some want a simple legal ceremony with beautiful photographs, while others want a fuller destination experience with styling, videography, florals, private dining, and a slow, romantic timeline. We help shape the experience around your relationship, not a fixed wedding formula.',
            ),
            2 => array(
                'id'    => '',
                'label' => 'Why Us',
                'title' => 'Why Couples Choose to <em>Elope With Us</em>',
                'intro' => "Many couples come to Eloping Weddings because they want a wedding that feels more personal and less performative. A large wedding can be beautiful, but it can also bring guest list pressure, family expectations, seating plans, strict timelines, and endless supplier decisions.\n\nWith an Australian elopement planner, you can choose another way. Your day is still beautifully organised, but the experience feels lighter, calmer, and more intentional.",
                'sub'   => 'Elopements are ideal for couples who value:',
                'items' => "Privacy\nMeaningful vows\nBeautiful scenery\nStress-free planning\nIntimate photography\nFlexible ceremony locations\nLower guest numbers\nLess tradition, and more personality\nA wedding experience that feels true to them",
                'outro' => 'Choosing to elope does not mean giving up on beauty, detail, or atmosphere. It simply means choosing the details that matter most.',
            ),
            3 => array(
                'id'    => '',
                'label' => 'Locations',
                'title' => 'Destination-Led Elopement Planning <em>Across Australia</em>',
                'intro' => "Australia offers an incredible range of elopement settings, from golden beaches and tropical islands to rainforest edges, private gardens, coastal headlands, and quiet hinterland locations. As your Australian elopement planner, we help you choose a setting that suits your ceremony style, photography goals, guest numbers, accessibility needs, and preferred season.\n\nThe location is more than a backdrop. It influences the light, mood, privacy, weather plan, timeline, footwear, transport, ceremony setup, and the style of your photos.",
                'sub'   => 'We can help you consider:',
                'items' => "Sunrise or sunset ceremony timing\nPublic access and privacy\nPermit requirements where applicable\nNearby photo locations\nWind, tide, heat, and seasonal conditions\nWet weather alternatives\nGuest comfort and accessibility\nAccommodation nearby\nPost-ceremony dining options",
                'outro' => 'The best elopement locations are not only beautiful. They are comfortable, achievable, and thoughtfully matched to the way you want to remember the day.',
            ),
            4 => array(
                'id'    => 'seo-packages',
                'label' => 'Packages',
                'title' => 'Elopement Packages Designed <em>Around You</em>',
                'intro' => 'An elopement package should make your wedding easier to plan, not make your day feel generic. As an Australian elopement planner, we help you choose a package that gives you structure while still leaving room for personal touches.',
                'sub'   => 'Your package may include:',
                'items' => "Celebrant\nCeremony planning\nLegal guidance\nPhotographer\nFlorals\nWitnesses\nLocation recommendations\nTimeline creation\nSupplier coordination\nStyling options\nHair and make-up\nVideography\nChampagne or picnic styling\nPrivate dinner recommendations",
                'outro' => 'Some couples want everything pared back. Others want elevated details that make the day feel luxurious and complete. The beauty of eloping is that you can choose what feels meaningful and leave out anything that does not.',
            ),
            5 => array(
                'id'    => '',
                'label' => 'Is This You?',
                'title' => 'Who Our Elopement Planning <em>Service Is For</em>',
                'intro' => 'An Australian elopement planner is ideal for couples who want a wedding that feels beautiful, personal, and easy to navigate. You may already know that a large wedding is not for you, or you may be exploring elopement because you want a calmer and more meaningful alternative.',
                'sub'   => 'Our service is well suited to couples who:',
                'items' => "Want a private or intimate ceremony\nAre planning from interstate or overseas\nNeed help choosing the right location\nWant beautiful photography without a large wedding\nPrefer a relaxed planning experience\nWant trusted supplier recommendations\nNeed guidance around legal marriage requirements\nWant a scenic, romantic, and personal ceremony",
                'outro' => 'Whether it is just the two of you or a small group of loved ones, your elopement can still feel significant. It can be simple without being plain, emotional without being formal, and beautifully planned without becoming stressful.',
            ),
        );
        // Per-block main image. Blocks rendered in an image layout show this
        // beside the list; the centered block (Why Couples Choose, block 2) has none.
        $check_imgs = array(
            1 => 'https://elopingweddings.com.au/wp-content/uploads/2026/05/Eloping-Wedding-14.jpg',
            2 => '',
            3 => 'https://elopingweddings.com.au/wp-content/uploads/2026/06/449A0970-scaled-e1741774586103.jpg.webp',
            4 => 'https://elopingweddings.com.au/wp-content/uploads/2026/06/DSC0323-scaled-1.webp',
            5 => 'https://elopingweddings.com.au/wp-content/uploads/2026/06/449A4261-scaled-e1743575801274.jpg.webp',
        );
        // Optional overlap photo (small image overlapping the main one, Section-1
        // style). Only Section 4 / block 3 is imaged this way by default.
        $check_imgs2 = array(
            1 => '',
            2 => '',
            3 => 'https://elopingweddings.com.au/wp-content/uploads/2026/06/DSC07468-1-scaled.jpg.webp',
            4 => '',
            5 => '',
        );
        foreach ( $checklists as $i => $c ) {
            $d[ "seo_check_{$i}_id" ]    = $c['id'];
            $d[ "seo_check_{$i}_img" ]   = isset( $check_imgs[ $i ] ) ? $check_imgs[ $i ] : '';
            $d[ "seo_check_{$i}_img2" ]  = isset( $check_imgs2[ $i ] ) ? $check_imgs2[ $i ] : '';
            $d[ "seo_check_{$i}_title" ] = $c['title'];
            $d[ "seo_check_{$i}_intro" ] = $c['intro'];
            $d[ "seo_check_{$i}_sub" ]   = $c['sub'];
            $d[ "seo_check_{$i}_items" ] = $c['items'];
            $d[ "seo_check_{$i}_outro" ] = $c['outro'];
        }

        /* ---------------- FAQ ITEMS 1–8 ---------------- */
        $faqs = array(
            1 => array(
                'Q' => 'What does an Australian elopement planner do?',
                'A' => "An Australian elopement planner helps coordinate the key details of your intimate wedding, including your ceremony location, celebrant, photography, flowers, witnesses, and timeline.\nAt Eloping Weddings, we also help guide practical decisions such as timing, styling, weather planning, supplier coordination, and legal requirements.\nWe shape the day around your relationship, your location, and your preferred style, so your wedding feels personal, organised, and beautifully simple.",
            ),
            2 => array(
                'Q' => 'Can we legally elope in Australia?',
                'A' => "Yes, you can legally elope in Australia as long as the correct marriage requirements are met.\nThis usually includes lodging the required notice, providing identification, using an authorised celebrant, signing the necessary documents, and having two witnesses present.\nAs your Australian elopement planner, we can help you understand the planning timeline and connect you with celebrant support.",
            ),
            3 => array(
                'Q' => 'How far in advance should we plan our elopement?',
                'A' => "It is helpful to begin planning as early as possible, especially if you want a specific date, location, photographer, or celebrant.\nMany couples start several months ahead so they have time to choose their setting, prepare paperwork, book suppliers, and organise travel.\nAn Australian elopement planner can help you understand what needs to happen first, what can wait, and which decisions are most time-sensitive.",
            ),
            4 => array(
                'Q' => 'Can we include guests in our elopement?',
                'A' => "Yes, many couples include a small number of guests in their elopement.\nAn elopement does not have to mean marrying without anyone present, although some couples prefer a ceremony for just the two of them.\nAs your Australian elopement planner, we can help you choose a location and package that suits your guest numbers while keeping the day intimate.",
            ),
            5 => array(
                'Q' => 'What should be included in an elopement package?',
                'A' => "A strong elopement package should include the essentials needed for a smooth and meaningful ceremony.\nThis may include planning support, a registered celebrant, legal guidance, photography, florals, witnesses, location advice, and timeline coordination.\nAn Australian elopement planner can also help you add extras such as hair and make-up, styling, videography, champagne, cake, picnic styling, or private dining.",
            ),
            6 => array(
                'Q' => 'Is an elopement cheaper than a traditional wedding?',
                'A' => "An elopement is often more affordable than a traditional wedding because it usually has fewer guests, fewer venue requirements, and fewer large-scale event costs.\nThe final price depends on your location, package inclusions, photography coverage, styling, travel plans, and optional extras.\nAn Australian elopement planner can help you prioritise the details that matter most, so your budget is spent intentionally.",
            ),
            7 => array(
                'Q' => 'Where can we elope in Australia?',
                'A' => "Australia offers many beautiful elopement locations, including beaches, islands, gardens, rainforests, hinterland settings, coastal headlands, and private venues.\nThe best location depends on your ceremony style, preferred season, guest numbers, accessibility needs, and photography vision.\nAs your Australian elopement planner, we can help you compare locations based on privacy, weather, permits, light, travel time, and nearby celebration options.",
            ),
            8 => array(
                'Q' => 'Do we need witnesses for an Australian elopement?',
                'A' => "Yes, legal weddings in Australia require two witnesses to be present at the ceremony.\nThese witnesses must be able to understand the ceremony and sign the required marriage documents.\nAn Australian elopement planner can help you understand how witness arrangements may work for your chosen package, especially if you are eloping without guests.",
            ),
        );
        foreach ( $faqs as $i => $f ) {
            $d[ "seo_faq_{$i}_q" ] = $f['Q'];
            $d[ "seo_faq_{$i}_a" ] = $f['A'];
        }

        return $d;
    }
}