<?php
/**
 * SEO Landing — one-time content seeder.
 *
 * Writes the starter defaults into every page that uses the SEO Landing
 * template, so all ACF fields are populated (not just rendered from the
 * template fallback). Runs once per page, guarded by the post meta
 * `_seo_landing_seeded`, and never overwrites a value an editor has set.
 *
 * Force a re-seed (overwrites all fields on matching pages) by visiting any
 * wp-admin page as an administrator with ?seo_reseed=1 appended to the URL.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_init', 'seo_landing_seed_pages' );
function seo_landing_seed_pages() {

    // ACF must be active — update_field() writes the field-key references too.
    if ( ! function_exists( 'update_field' ) || ! function_exists( 'seo_landing_field_spec' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_pages' ) ) {
        return;
    }

    $force = isset( $_GET['seo_reseed'] ) && '1' === $_GET['seo_reseed'] && current_user_can( 'manage_options' );

    // Find pages assigned the SEO Landing template.
    $page_ids = get_posts( array(
        'post_type'      => 'page',
        'post_status'    => 'any',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_key'       => '_wp_page_template',
        'meta_value'     => 'template-seo-landing.php',
        'no_found_rows'  => true,
    ) );
    if ( empty( $page_ids ) ) {
        return;
    }

    $defaults = function_exists( 'seo_landing_defaults' ) ? seo_landing_defaults() : array();
    $spec     = seo_landing_field_spec();
    $seeded   = 0;

    foreach ( $page_ids as $pid ) {

        if ( ! $force && get_post_meta( $pid, '_seo_landing_seeded', true ) ) {
            continue; // already seeded — leave editor content alone
        }

        foreach ( $spec as $item ) {
            if ( 'tab' === $item['type'] || empty( $item['name'] ) ) {
                continue;
            }
            $name = $item['name'];

            // Skip fields the editor already filled in (unless forcing a full reset).
            if ( ! $force && metadata_exists( 'post', $pid, $name ) ) {
                continue;
            }

            $value = isset( $defaults[ $name ] ) ? $defaults[ $name ] : '';

            // IMPORTANT: seed by field KEY, not name. ACF requires the key to
            // write a value that doesn't exist yet on a fresh page; by name it
            // silently fails to save. Keys are registered as 'field_' . name.
            update_field( 'field_' . $name, $value, $pid );
        }

        update_post_meta( $pid, '_seo_landing_seeded', current_time( 'mysql' ) );
        $seeded++;
    }

    if ( $seeded > 0 ) {
        set_transient( 'seo_landing_seeded_notice', $seeded, 60 );
    }
}

/**
 * Admin notice confirming how many pages were seeded.
 */
add_action( 'admin_notices', 'seo_landing_seed_notice' );
function seo_landing_seed_notice() {
    $count = get_transient( 'seo_landing_seeded_notice' );
    if ( false === $count ) {
        return;
    }
    delete_transient( 'seo_landing_seeded_notice' );
    printf(
        '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
        esc_html( sprintf(
            /* translators: %d: number of pages seeded */
            _n( 'SEO Landing: %d page populated with starter content.', 'SEO Landing: %d pages populated with starter content.', (int) $count, 'eloping-child' ),
            (int) $count
        ) )
    );
}