<?php
/**
 * Theme Customizer for CSS Variables & Global Settings
 */

function eloping_customize_register( $wp_customize ) {
    
    // ==========================================
    // 1. DESIGN VARIABLES (Colors - Existing)
    // ==========================================
    $wp_customize->add_panel( 'eloping_design', array(
        'title'       => __( 'Theme Design Variables', 'eloping' ),
        'description' => 'Edit base colors, typography, and spacing.',
        'priority'    => 20,
    ) );

    $wp_customize->add_section( 'eloping_colors', array(
        'title' => __( 'Colors', 'eloping' ),
        'panel' => 'eloping_design',
    ) );

    $colors = array(
        'color_forest' => array( 'label' => 'Forest (Brand Dark)', 'default' => '#41503A' ),
        'color_rose'   => array( 'label' => 'Rose (Primary Accent)', 'default' => '#EB99A2' ),
        'color_blush'  => array( 'label' => 'Blush (Soft Pink)', 'default' => '#F6BBBA' ),
        'color_cream'  => array( 'label' => 'Cream (Highlights)', 'default' => '#FAE6DD' ),
        'color_ink'    => array( 'label' => 'Ink (Text)', 'default' => '#1c211a' ),
        'color_paper'  => array( 'label' => 'Paper (Background)', 'default' => '#fbf7f3' ),
    );

    foreach ( $colors as $id => $data ) {
        $wp_customize->add_setting( $id, array(
            'default'           => $data['default'],
            'transport'         => 'postMessage', 
            'sanitize_callback' => 'sanitize_hex_color',
        ) );

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
            'label'   => $data['label'],
            'section' => 'eloping_colors',
        ) ) );
    }

    // ==========================================
    // 2. GLOBAL SETTINGS (Buttons & Contact Info)
    // ==========================================
    $wp_customize->add_section( 'eloping_global_settings', array(
        'title'    => __( 'Global Settings (Hero & Header)', 'eloping' ),
        'priority' => 30,
    ) );

    // Enquire Now (Contact) Page Link
    $wp_customize->add_setting( 'eloping_enquire_url', array(
        'default'           => '/contact-us/',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'eloping_enquire_url', array(
        'label'    => __( 'Begin Your Story URL', 'eloping' ),
        'section'  => 'eloping_global_settings',
        'type'     => 'text',
        'description' => 'Best practice: Use root-relative URL (e.g., /contact-us/)'
    ) );

    // Our Journey (Story) Section Link
    $wp_customize->add_setting( 'eloping_story_url', array(
        'default'           => '/#story',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'eloping_story_url', array(
        'label'    => __( 'Our Journey (Story) URL', 'eloping' ),
        'section'  => 'eloping_global_settings',
        'type'     => 'text',
        'description' => 'Best practice: Use root-relative URL (e.g., /#story)'
    ) );

    // Phone Number Setting
    $wp_customize->add_setting( 'eloping_phone_number', array(
        'default'           => '+64 21 000 000',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'eloping_phone_number', array(
        'label'    => __( 'Call Us Phone Number', 'eloping' ),
        'section'  => 'eloping_global_settings',
        'type'     => 'text',
    ) );

// Email Address Setting (Pehle se tha)
    $wp_customize->add_setting( 'eloping_email_address', array(
        'default'           => 'hello@elopingweddings.co.nz',
        'sanitize_callback' => 'sanitize_email',
    ) );
    $wp_customize->add_control( 'eloping_email_address', array(
        'label'    => __( 'Header Email Address', 'eloping' ),
        'section'  => 'eloping_global_settings',
        'type'     => 'email',
    ) );

    // ==========================================
    // NAYA ADD KIYA: Top Bar Marquee Text
    // ==========================================
    $wp_customize->add_setting( 'eloping_marquee_text', array(
        'default'           => 'Boutique elopements across Aotearoa <em>·</em> Queenstown <em>·</em> Wanaka <em>·</em> Lake Tekapo <em>·</em> Bay of Islands <em>·</em> Featured in NZ Wedding Mag <em>·</em> 5 Star <em>·</em> 200+ Couples <em>·</em> Est. 2014',
        'sanitize_callback' => 'wp_kses_post', // Allows HTML like <em> tags
    ) );
    $wp_customize->add_control( 'eloping_marquee_text', array(
        'label'       => __( 'Top Bar Marquee Text', 'eloping' ),
        'description' => 'Text ke beech mein dot lagane ke liye <em>·</em> use karein.',
        'section'     => 'eloping_global_settings',
        'type'        => 'textarea',
    ) );
}
add_action( 'customize_register', 'eloping_customize_register' );

// ==========================================
// Output Customizer Settings as Inline CSS in <head>
// ==========================================
function eloping_customizer_css() {
    $forest = get_theme_mod( 'color_forest', '#41503A' );
    $rose   = get_theme_mod( 'color_rose', '#EB99A2' );
    $blush  = get_theme_mod( 'color_blush', '#F6BBBA' );
    $cream  = get_theme_mod( 'color_cream', '#FAE6DD' );
    $ink    = get_theme_mod( 'color_ink', '#1c211a' );
    $paper  = get_theme_mod( 'color_paper', '#fbf7f3' );

    $css = "
    <style id='eloping-customizer-vars'>
        :root {
            --forest: {$forest};
            --rose: {$rose};
            --blush: {$blush};
            --cream: {$cream};
            --ink: {$ink};
            --paper: {$paper};
        }
    </style>
    ";
    echo $css;
}
add_action( 'wp_head', 'eloping_customizer_css' );

// ==========================================
// Enqueue Live Preview JS
// ==========================================
function eloping_customize_preview_js() {
    wp_enqueue_script( 'eloping-customizer', THEME_URI . '/assets/js/customizer-preview.js', array( 'jquery', 'customize-preview' ), THEME_VERSION, true );
}
add_action( 'customize_preview_init', 'eloping_customize_preview_js' );