<?php
/**
 * Template Name: Heli Proposal
 */
get_header();

$heli_prop_sections = array(
    'hero', 'intro', 'experiences', 'highlights', 'band', 'plan', 'testimonial', 'mini', 'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'queenstown', $heli_prop_sections ); ?>
</main>
<?php get_footer(); ?>