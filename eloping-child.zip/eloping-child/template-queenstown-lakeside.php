<?php
/**
 * Template Name: Queenstown Lakeside Elopement
 */
get_header();

// Same sections array to keep the exact same design structure
$lakeside_sections = array(
    'hero',
    'intro',
    'experiences',
    'highlights',
    'band',
    'plan',
    'testimonial',
    'mini',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php 
    // Hum yahan 'queenstown' prefix hi pass kar rahe hain taaki ye wahi same 
    // template-parts load kare (jaise queenstown-hero.php). Design same rahega,
    // aur ACF automatically is naye page ke ID ke hisaab se naya content fetch kar lega!
    eloping_render_sections( 'queenstown', $lakeside_sections ); 
    ?>
</main>
<?php
get_footer();
?>