<?php
/**
 * Template Name: Lake Wanaka Elopement Packages
 */
get_header();

$wanaka_sections = array(
    'hero', 'intro', 'experiences', 'highlights', 'band', 'plan', 'testimonial', 'mini', 'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'queenstown', $wanaka_sections ); ?>
</main>
<?php get_footer(); ?>