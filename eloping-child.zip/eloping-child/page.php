<?php
/**
 * The template for displaying all single pages (Default Template)
 */

get_header();
?>

<main id="main" class="site-main default-page-wrapper" style="padding: 120px 0; min-height: 60vh;">
    <div class="container">
        <?php
        // Start the Loop
        while ( have_posts() ) :
            the_post();
            ?>
            
            <header class="page-header" style="margin-bottom: 40px; text-align: center;">
                <h1 class="page-title display-lg"><?php the_title(); ?></h1>
            </header>

            <div class="page-content">
                <?php
                // Page ka default Gutenberg/Classic editor content yahan aayega
                the_content();
                ?>
            </div>

        <?php
        endwhile; // End of the loop.
        ?>
    </div>
</main>

<?php
get_footer();
?>