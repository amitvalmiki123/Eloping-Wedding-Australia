<?php
/**
 * Template Name: Thank You Page
 */
get_header();
?>

<main id="main" class="site-main" style="min-height: 65vh; display: flex; align-items: center; justify-content: center; background: var(--paper);">
    <div style="text-align: center; max-width: 680px; padding: 40px 20px;">
        
        <!-- Premium Italic Heading -->
        <h1 style="font-family: var(--serif); font-weight: 300; font-size: clamp(40px, 6vw, 64px); color: var(--forest); margin-bottom: 24px; line-height: 1;">
            <em>Thank You</em>
        </h1>
        
        <!-- Custom Message -->
        <p style="font-size: 17px; opacity: 0.85; line-height: 1.6; margin-bottom: 40px; color: var(--ink);">
            Thank you for reaching out. Your quiet inquiry has been received, and we will get back to you within 24 hours.
        </p>
        
        <!-- Back to Home Button -->
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary" style="display: inline-flex; justify-content: center;">
            Back to Home <i class="arrow"></i>
        </a>

    </div>
</main>

<?php get_footer(); ?>