<?php
/**
 * Template Name: Napier Elopement
 */
get_header();

$dest_sections = array(
    'hero', 'intro', 'experiences', 'highlights', 'band', 'plan', 'testimonial', 'mini', 'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'queenstown', $dest_sections ); ?>
</main>
<?php get_footer(); ?>