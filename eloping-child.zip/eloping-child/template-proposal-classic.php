<?php
/**
 * Template Name: Marriage Proposal Classic
 */
get_header();

$proposal_sections = array(
    'hero', 'intro', 'experiences', 'highlights', 'band', 'plan', 'testimonial', 'mini', 'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'queenstown', $proposal_sections ); ?>
</main>
<?php get_footer(); ?>