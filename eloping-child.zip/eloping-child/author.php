<?php
/**
 * The template for displaying Author Archive pages
 */
get_header();

// Get current author data
$author = get_queried_object();
$author_id = $author->ID;
$author_name = get_the_author_meta( 'display_name', $author_id );
$author_bio = get_the_author_meta( 'description', $author_id );
?>

<main id="main" class="site-main">
    
    <section class="page-hero minimal" style="min-height: 40vh; background: linear-gradient(180deg, var(--paper) 0%, var(--cream) 100%);">
        <div class="inner" style="padding-top: 120px; padding-bottom: 60px; max-width: 800px; margin: 0 auto;">
            <div class="eyebrow" style="justify-content: center;">
                <span class="dot"></span> Journal Author
            </div>
            
            <h1 style="color: var(--forest); margin-bottom: 16px;">Stories by <em><?php echo esc_html( $author_name ); ?></em></h1>
            
            <?php if ( $author_bio ) : ?>
                <p class="lede" style="font-size: 16px; opacity: 0.85; max-width: 60ch; margin: 0 auto;">
                    <?php echo esc_html( $author_bio ); ?>
                </p>
            <?php else : ?>
                <p class="lede" style="font-size: 16px; opacity: 0.85;">
                    A curated collection of real elopements and journal entries captured across Aotearoa.
                </p>
            <?php endif; ?>
        </div>
    </section>

    <section class="author-posts-sec" style="background: var(--paper); padding: clamp(60px, 10vw, 100px) var(--gutter);">
        <div style="max-width: var(--maxw); margin: 0 auto;">
            
            <?php if ( have_posts() ) : ?>
                <div class="author-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article class="blog-card">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <div class="blog-card-img">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'medium_large' ); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <div class="blog-card-meta">
                                <span><?php echo get_the_date(); ?></span>
                            </div>
                            
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_trim_words( get_the_excerpt(), 18, '...' ); ?></p>
                            
                            <a href="<?php the_permalink(); ?>" class="read-more-btn">Read Story <i class="arrow"></i></a>
                        </article>
                    <?php endwhile; ?>
                </div>

                <div class="author-pagination" style="text-align: center; margin-top: 50px;">
                    <?php 
                    echo paginate_links( array(
                        'prev_text' => '<i class="arrow" style="transform:rotate(-135deg); display:inline-block; width:6px; height:6px;"></i> Prev',
                        'next_text' => 'Next <i class="arrow" style="transform:rotate(45deg); display:inline-block; width:6px; height:6px;"></i>',
                    ) ); 
                    ?>
                </div>

            <?php else : ?>
                <p style="text-align: center; opacity: 0.6;">No posts found by this author.</p>
            <?php endif; ?>

        </div>
    </section>

</main>

<?php
get_footer();