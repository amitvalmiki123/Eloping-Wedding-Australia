<?php


/**


 * Fallback Content Engine


 * Stores all original HTML content as PHP arrays.


 */





$eloping_defaults = array(


    


    // ==========================================


    // FRONT PAGE


    // ==========================================


    'front_page' => array(


        'hero' => array( 'show' => true, 'order' => 10, 'bg_image' => THEME_URI . '/assets/images/hero.jpg', 'eyebrow' => 'Aotearoa · New Zealand · Est. 2014', 'title' => 'Two hearts.<br/>One wild<br/><em>landscape.</em>', 'btn_1_text' => 'Explore destinations', 'btn_1_url' => '#destinations', 'btn_2_text' => 'View pricing', 'btn_2_url' => '#packages', 'meta_strong' => 'Just the two of you.', 'meta_desc' => 'Intimate ceremonies in New Zealand\'s most cinematic places — lakesides, alpine summits, secret beaches and quiet chapels.', 'scroll_text' => 'Scroll to begin' ),


        'marquee' => array( 'show' => true, 'order' => 20, 'items' => array('Queenstown', 'Wanaka', 'Lake Tekapo', 'Mt Cook', 'Bay of Islands', 'Coromandel', 'Hobbiton', 'Waiheke', 'Abel Tasman') ),


        'story' => array( 'show' => true, 'order' => 30, 'label' => 'Our philosophy', 'title' => 'An elopement is not a smaller wedding. It\'s a <em>louder</em> love story, told quietly.', 'text_1' => 'For over a decade we\'ve helped couples from around the world say "I do" in the wild, weather-changing beauty of New Zealand.', 'text_2' => 'We handle every thread of the day — so the two of you can simply stand still in it.', 'signature' => '— Eloping Weddings, Aotearoa', 'img_main' => THEME_URI . '/assets/images/story1.jpg', 'badge' => 'Since 2014 · Aotearoa', 'img_overlay' => THEME_URI . '/assets/images/story2.jpg' ),


        'destinations' => array( 'show' => true, 'order' => 40, 'head_title' => 'Find your <em>somewhere.</em>', 'head_text' => 'From a private jetty on Lake Wanaka to a windswept summit at Mt Cook.', 'cards' => array( 1 => array( 'img' => THEME_URI . '/assets/images/story1.jpg', 'tag' => 'South Island · Otago', 'title' => 'Queenstown<br/>Lakeside & Alpine', 'url' => '#' ), 2 => array( 'img' => THEME_URI . '/assets/images/wanaka.jpg', 'tag' => 'South Island', 'title' => 'Wanaka<br/>Tussock & Lake', 'url' => '#' ), 3 => array( 'img' => THEME_URI . '/assets/images/heli.jpg', 'tag' => 'By Helicopter', 'title' => 'Mt Cook & the Alps', 'url' => '#' ), 4 => array( 'img' => THEME_URI . '/assets/images/hero.jpg', 'tag' => 'North Island', 'title' => 'Coromandel<br/>Cathedral Cove', 'url' => '#' ), 5 => array( 'img' => THEME_URI . '/assets/images/tekapo.jpg', 'tag' => 'South Island', 'title' => 'Garden & Vineyard', 'url' => '#' ), 6 => array( 'img' => THEME_URI . '/assets/images/bay.jpg', 'tag' => 'North Island', 'title' => 'Bay of Islands', 'url' => '#' ) ) ),


        'experience' => array( 'show' => true, 'order' => 50, 'label' => 'The experience', 'title' => 'Held in beauty, <em>head to heart.</em>', 'text_1' => 'From the first hello to the final toast, every detail is gently held by your dedicated planner.', 'text_2' => 'We work with New Zealand\'s most quietly extraordinary celebrants, florists, hair & make-up artists.', 'stats' => array( 1 => array('num'=>'200','suffix'=>'+','label'=>'Couples married'), 2 => array('num'=>'12','suffix'=>' yrs','label'=>'In Aotearoa'), 3 => array('num'=>'4.9','suffix'=>'★','label'=>'Average rating') ), 'img_1' => THEME_URI . '/assets/images/exp1.jpg', 'img_2' => THEME_URI . '/assets/images/exp2.jpg', 'floater_small' => 'From our couples', 'floater_main' => '“Felt less like a wedding day, more like a love letter to ourselves.”' ),


        'heli' => array( 'show' => true, 'order' => 60, 'img' => THEME_URI . '/assets/images/heli.jpg', 'label' => 'Heli elopements', 'title' => 'Marry where <em>only the eagles</em> get to stand.', 'text' => 'Lift off from Queenstown, Wanaka or Mt Cook and land on a private glacier.', 'list' => array( 1 => array('num'=>'01','text'=>'Private chopper for you and your celebrant'), 2 => array('num'=>'02','text'=>'Choice of glacier, ridge or hidden valley'), 3 => array('num'=>'03','text'=>'Champagne & ceremony at altitude'), 4 => array('num'=>'04','text'=>'Cinematic photography included') ), 'btn_1_text' => 'See heli packages', 'btn_1_url' => '#', 'btn_2_text' => 'Watch the film', 'btn_2_url' => '#', 'tag_top' => 'From', 'tag_main' => '$4,990' ),


        'packages' => array( 'show' => true, 'order' => 70, 'label' => 'Pricing', 'title' => 'Three thoughtfully built <em>experiences.</em>', 'text' => 'Every elopement is bespoke, but most couples begin from one of three starting points.', 'pkgs' => array( 1 => array('tag'=>'Intimate','title'=>'Just the two of us','price_label'=>'From','price_val'=>'$2,490','btn_text'=>'Enquire','btn_url'=>'#','feats'=>array('Licensed celebrant & legal paperwork','2 hour photography','Hand-tied seasonal bouquet','Two witnesses on the day','Your dedicated planner')), 2 => array('tag'=>'Signature','title'=>'Lakeside & lens','price_label'=>'From','price_val'=>'$4,990','btn_text'=>'Enquire','btn_url'=>'#','feats'=>array('Everything in <em>Just the two of us</em>','Half-day photography + cinema','Hair & make-up artist','Private vehicle & champagne picnic','Two ceremony locations')), 3 => array('tag'=>'Heli','title'=>'Above the world','price_label'=>'From','price_val'=>'$7,990','btn_text'=>'Enquire','btn_url'=>'#','feats'=>array('Everything in <em>Signature</em>','Private helicopter charter','Glacier / alpine landing site','Cinematic aerial photography','Dinner reservation for two')) ) ),


        'testimonial' => array( 'show' => true, 'order' => 80, 'quote' => '“We chose <span class="hl">a ridge above Lake Wanaka</span> over a hall full of strangers.”', 'cite' => 'Ana & Tom · Wanaka' ),
        'faq' => array( 'show' => true, 'order' => 85, 'label' => 'Frequently asked questions', 'title' => 'The questions worth asking before you say <em>I do.</em>', 'intro' => 'Beyond the paperwork, there is a second layer of questions couples tend to ask once they start picturing the actual day: what is included, what can be changed, and what happens to the small details nobody puts in a brochure. These are the ten we at Eloping Weddings hear most often once a couple has moved past "can we legally do this" and into "what will our actual morning look like," gathered from enquiry calls, follow-up emails, and the questions people usually save until the second or third conversation, once the practical worries have settled and the real planning begins.', 'note' => '<strong><em>A small note on permits.</em></strong> Ceremonies on national park, coastal reserve or council-managed land generally require some form of booking or permit, but the exact process, permit type and fee differ by state and by the specific reserve. What is true for a headland in Byron Bay is not necessarily true for a beach further north in Queensland. This answer reflects how these things usually work rather than a fixed rulebook, and it is worth confirming the current requirements for each reserve we actually use before finalising the ceremony.', 'outro' => 'Still have a question of your own? That is exactly what the twenty-minute call is for. No pressure, no obligation, just a chance to ask us anything before you begin your story.', 'items' => array( 1 => array( 'q' => 'What is actually included in each package, and can we customise it?', 'a' => "Every package lists a starting point, not a ceiling. \"Just the two of us\" covers a licensed celebrant, legal paperwork, two hours of photography, a bouquet and your two witnesses; \"Lakeside and lens\" and \"Above the world\" build on that with more coverage, hair and make-up, a private vehicle, or a helicopter charter. Almost everything can be added, swapped or dropped once we know what your day should feel like: an extra hour of photography, a videographer, a second outfit change, a bigger bouquet, a musician on the sand, or a florist who works only with native blooms if that matters to you.\n\nWe treat the listed packages as a sketch, not a script, and the final quote reflects the day you actually want rather than the closest tier to it, so do not feel limited to choosing exactly what is written on the page." ), 2 => array( 'q' => 'How do we choose between beach, rainforest, island and heli locations?', 'a' => "Most couples choose with their eyes first and their logistics second, and both matter. A beach ceremony at sunrise suits couples who want soft light and easy access; a rainforest or hinterland setting suits couples chasing shade, greenery and a quieter soundscape; an island or sandbar location suits couples happy to add a short boat transfer for real seclusion; a heli elopement suits couples who want a view no road could ever reach.\n\nDuring your enquiry call we talk through travel time, budget, weather patterns for the season you are marrying in, and how many people, if any, are coming with you, and narrow the shortlist from there rather than asking you to pick blind from a map. If two locations are calling to you equally, we can often build a day that touches both, a ceremony in one and photographs in the other, rather than forcing a single choice too early." ), 3 => array( 'q' => 'Do you need a permit to hold a ceremony on public land, a national park or a beach?', 'a' => "Often, yes, and this is one of the details we handle rather than leave to you. A number of our most photogenic locations sit within national park land, coastal reserves or council-managed foreshore, all of which can require a commercial activity permit, a venue booking, or advance notice to the relevant land manager before a ceremony can legally take place there, particularly if a photographer or celebrant is working commercially on site.\n\nRequirements and fees vary by state, by park, and sometimes by season, so we check the specific rules for your chosen location rather than assuming what worked for a previous couple applies again. We arrange these permits and bookings as part of your planning, well ahead of your date, so you are never the one filling out a council form the week of your wedding." ), 4 => array( 'q' => 'Can we do a symbolic ceremony if we are already legally married, or renewing our vows?', 'a' => "Yes, and we host these often. Some couples married quickly at a registry office, in another country, or during a season when a big wedding was not possible, and want a proper ceremony later, in a place that actually feels like them. Others are marking five, ten or twenty years and want to say the vows again, this time with a view instead of a waiting room.\n\nA symbolic ceremony carries no separate legal paperwork, so there is no notice period or witness requirement to plan around, only the parts of the day you actually want: the celebrant, the words, the photographs, the toast, and, if you would like it, a small nod to the original day woven into the new one." ), 5 => array( 'q' => 'Is there a deposit, and what is your cancellation or rescheduling policy?', 'a' => "A deposit secures your date, celebrant and vendors, with the remaining balance due closer to your ceremony; the exact figures and timing are set out in your proposal once your package is confirmed. Rescheduling due to weather, illness or a change of travel plans is common enough that we build flexibility into our vendor agreements wherever we can, and we will always try to move your date rather than treat it as lost.\n\nCancellations are handled case by case, since a booking made eight months out and one made eight days out carry different costs to unwind, and we would rather talk it through honestly with you than hide behind a fixed clause buried in the fine print." ), 6 => array( 'q' => 'Can our dog, or another pet, be part of the ceremony?', 'a' => "Often, yes. A number of our couples want their dog standing beside them, and where the location and celebrant allow it, we are glad to build that into the day, whether that means a beach walk together beforehand, a spot in the ceremony photographs, or simply a calm presence nearby held by a friend or a pet minder we can arrange.\n\nSome locations, particularly certain national park or protected beach areas, restrict animals for conservation reasons, so this is worth raising early so we can check the specific rules for your chosen spot before you get attached to the idea, and so we can suggest an equally beautiful alternative if the answer turns out to be no." ), 7 => array( 'q' => 'Who owns the rights to our photos, and can we share them ourselves?', 'a' => "Your photographs are yours to keep, print and share however you like, on social media, in a frame, or in an album for family who could not be there. Your photographer retains the right to use selected images in their own portfolio and on our galleries, in keeping with standard industry practice, but this is never exclusive and never limits what you can do with your own copies.\n\nIf you would prefer certain images kept private, simply tell us during planning and we will make sure that preference is passed on before the day, not negotiated after it, and your photographer will treat that request the same way they would treat any other part of your brief." ), 8 => array( 'q' => 'Do you help with anything beyond the ceremony, like the honeymoon or celebration dinner?', 'a' => "We can, if you would like us to. Many couples extend the day with a dinner reservation, a private picnic, or a night at a nearby stay, and several of our packages already build one of these in.\n\nBeyond the day itself, we are happy to point you toward accommodation, restaurants and honeymoon experiences we trust in the region, drawing on relationships built over years of working these same coastlines, though full honeymoon planning, flights and multi-day itineraries sit outside what our packages formally cover, since we would rather do a small number of things well than everything at a distance." ), 9 => array( 'q' => 'Is eloping in Australia an option for same-sex couples?', 'a' => "Yes, without exception. Marriage equality became law across Australia in December 2017, and same-sex couples marry here every week in exactly the same places, under exactly the same paperwork, as anyone else. A number of our own celebrants and photographers are part of the community they serve, and every destination on our list, from island sandbar to rainforest clifftop, is offered equally, with no asterisk attached and no separate conversation needed.\n\nIf you are travelling from a country where your marriage may not yet be legally recognised, we are glad to talk that through honestly with you, and to help you plan a day that still feels wholly, unapologetically yours." ), 10 => array( 'q' => 'What if one of us has mobility needs or accessibility requirements?', 'a' => "Tell us as early as possible, ideally during your first enquiry, so we can shortlist locations that genuinely work rather than ones that only look accessible in a photograph. Some of our beach and headland settings involve sand, steps or uneven ground that are difficult for wheelchairs, walking aids or limited mobility, while others, including several lookout and garden settings, are level, close to parking, and easy to reach.\n\nWe would rather have this conversation honestly upfront, and adjust the plan around it, than let you discover a limitation on the day itself, and we are always glad to arrange a site visit or a detailed photo walkthrough beforehand if that would help you decide." ) ) ),


        'gallery' => array( 'show' => true, 'order' => 90, 'label' => 'Recently wed', 'title' => 'A few of our <em>quiet days.</em>', 'btn_text' => 'Open full gallery', 'btn_url' => '#', 'images' => array( THEME_URI.'/assets/images/wanaka.jpg', THEME_URI.'/assets/images/gallery2.jpg', THEME_URI.'/assets/images/story1.jpg', THEME_URI.'/assets/images/exp2.jpg', THEME_URI.'/assets/images/hero.jpg', THEME_URI.'/assets/images/tekapo.jpg', THEME_URI.'/assets/images/heli.jpg', THEME_URI.'/assets/images/bay.jpg' ) ),


        'journal' => array( 'show' => true, 'order' => 100, 'label' => 'The journal', 'title' => 'Notes from <em>the field.</em>', 'btn_text' => 'Read all journal', 'btn_url' => '#' ),


        'cta' => array( 'show' => true, 'order' => 110, 'bg_img' => THEME_URI . '/assets/images/cta-bg.jpg', 'title' => 'So — where shall we <em>elope you?</em>', 'text' => 'Tell us a little about the two of you.', 'btn_1_text' => 'Begin your story', 'btn_1_url' => '#', 'btn_2_text' => 'Book a call', 'btn_2_url' => '#' )


    ),





    // ==========================================


    // QUEENSTOWN PAGE


    // ==========================================


    'queenstown' => array(


        'hero' => array( 'show' => true, 'order' => 10, 'bg_img' => THEME_URI . '/assets/images/hero.jpg', 'eyebrow' => 'South Island · Otago · Queenstown', 'title' => 'Queenstown —<br/>where mountains meet <em>your moment.</em>', 'lede' => 'The Remarkables hold the horizon.' ),


        'intro' => array( 'show' => true, 'order' => 20, 'label' => 'Why Queenstown', 'title' => 'A landscape that doesn\'t <em>perform</em> — it remembers.', 'text_1' => 'Queenstown isn\'t a backdrop; it\'s a co-conspirator.', 'text_2' => 'For couples drawn to a wedding that feels less like an event...', 'signature' => '— Quietly held since 2014', 'img_main' => THEME_URI . '/assets/images/exp1.jpg', 'img_over' => THEME_URI . '/assets/images/exp2.jpg' ),


        'experiences' => array( 'show' => true, 'order' => 30, 'head_label' => 'Choose your ceremony', 'head_title' => 'Three ways to say <em>I do</em> in Queenstown.', 'cards' => array( 1 => array('img'=>THEME_URI.'/assets/images/hero.jpg','tag'=>'Lakeside','title'=>'Lakeside Elopement','text'=>'Stand together on a still morning...','price'=>'$2,990','url'=>'#'), 2 => array('img'=>THEME_URI.'/assets/images/wanaka.jpg','tag'=>'Garden','title'=>'Garden Elopement','text'=>'Late roses, climbing jasmine...','price'=>'$3,490','url'=>'#'), 3 => array('img'=>THEME_URI.'/assets/images/heli.jpg','tag'=>'Heli','title'=>'Heli Elopement','text'=>'Twelve minutes after take-off...','price'=>'$7,990','url'=>'#') ) ),


        'highlights' => array( 'show' => true, 'order' => 40, 'head_label' => 'What makes it special', 'head_title' => 'A landscape <em>designed</em> for love.', 'head_text' => 'Six quiet reasons couples keep choosing Queenstown.', 'items' => array( 1 => array('num'=>'01','title'=>'The Remarkables','text'=>'That sawtoothed mountain range...'), 2 => array('num'=>'02','title'=>'Lake Reflections','text'=>'On still mornings the lake mirrors the sky...'), 3 => array('num'=>'03','title'=>'Ceremony Weather','text'=>'Four genuine seasons...'), 4 => array('num'=>'04','title'=>'Golden Hour','text'=>'Late afternoon light lingers...'), 5 => array('num'=>'05','title'=>'Private Jetty','text'=>'Small wooden platforms...'), 6 => array('num'=>'06','title'=>'Alpine Meadows','text'=>'In late spring, the high tussock fields bloom...') ) ),


        'band' => array( 'show' => true, 'order' => 50, 'bg_img' => THEME_URI . '/assets/images/cta-bg.jpg', 'quote' => 'The lake was so still it felt like the world was <em>holding its breath</em> for us.', 'cite' => 'Ana & Tom' ),


        'plan' => array( 'show' => true, 'order' => 60, 'img' => THEME_URI . '/assets/images/story1.jpg', 'label' => 'Planning your day', 'title' => 'From <em>first hello</em> to "I do".', 'text' => 'From the first message in your inbox...', 'steps' => array( 1 => array('num'=>'01','title'=>'Enquire & dream','text'=>'A long, no-pressure conversation.'), 2 => array('num'=>'02','title'=>'Choose ceremony','text'=>'We draft a bespoke sketch.'), 3 => array('num'=>'03','title'=>'We handle details','text'=>'Bouquet, licence, witnesses...'), 4 => array('num'=>'04','title'=>'Your day unfolds','text'=>'Gently, exactly itself.') ) ),


        'testimonial' => array( 'show' => true, 'order' => 70, 'quote' => '"We came to Queenstown thinking we\'d booked a wedding..."', 'cite' => 'Maia & Jack' ),


        'mini' => array( 'show' => true, 'order' => 80, 'head_label' => 'A quieter look', 'head_title' => 'A few quiet moments in <em>Queenstown.</em>', 'images' => array( THEME_URI.'/assets/images/story1.jpg', THEME_URI.'/assets/images/exp2.jpg', THEME_URI.'/assets/images/heli.jpg', THEME_URI.'/assets/images/wanaka.jpg' ) ),


        'cta' => array( 'show' => true, 'order' => 90, 'bg_img' => THEME_URI . '/assets/images/cta-bg.jpg', 'title' => 'So — where shall we <em>elope you?</em>', 'text' => 'Tell us a little about the two of you.', 'btn_1_text' => 'Begin your story', 'btn_1_url' => '#', 'btn_2_text' => 'Book a call', 'btn_2_url' => '#' )


    ),





    // ==========================================


    // ABOUT PAGE


    // ==========================================


    'about' => array(


        'hero' => array( 'show' => true, 'order' => 10, 'bg_img' => THEME_URI . '/assets/images/hero.jpg', 'eyebrow' => 'Our Philosophy', 'title' => 'Born from love.<br/>Built for <em>yours.</em>', 'lede' => 'For more than a decade, we have helped couples...' ),


        'story' => array( 'show' => true, 'order' => 20, 'label' => 'How it all began', 'title' => 'A decade of quiet <em>I do\'s</em> across the South Island.', 'text_1' => 'Eloping Weddings was not born in a corporate planning suite...', 'text_2' => 'We realized then that an elopement is not a compromised wedding...', 'text_3' => 'We have coordinated helicopter landings...', 'signature' => '— The Eloping Weddings Team', 'img_main' => THEME_URI . '/assets/images/exp1.jpg', 'img_over' => THEME_URI . '/assets/images/exp2.jpg' ),


        'values' => array( 'show' => true, 'order' => 30, 'head_label' => 'What we believe', 'head_title' => 'Our three quiet <em>promises.</em>', 'cards' => array( 1 => array('title'=>'Presence Over Performance','text'=>'We believe a wedding day should feel like a memory...'), 2 => array('title'=>'Nature As Our Cathedral','text'=>'Aotearoa New Zealand has designed the most stunning venues...'), 3 => array('title'=>'Every Thread, Gently Held','text'=>'We do not ask you to deal with multiple vendors...') ) ),


        'team' => array( 'show' => true, 'order' => 40, 'img' => THEME_URI . '/assets/images/story1.jpg', 'label' => 'Behind the scenes', 'title' => 'Meet the souls who <em>protect</em> your day.', 'text_1' => 'We are a small, tight-knit collective...', 'text_2' => 'Our celebrants are chosen for their warmth...', 'stats' => array( 1 => array('num'=>'200+','label'=>'Stories Told'), 2 => array('num'=>'12Y','label'=>'In Aotearoa'), 3 => array('num'=>'4.9★','label'=>'Average Rating') ) ),


        'partners' => array( 'show' => true, 'order' => 50, 'head_label' => 'We work with the best', 'head_title' => 'Curated with <em>extraordinary</em> local souls.', 'head_text' => 'We believe that an elopement is only as good as the people who hold it.', 'items' => array( 1 => array('title'=>'Alpine Pilots','text'=>'Highly skilled mountain pilots...'), 2 => array('title'=>'Boutique Florists','text'=>'Artisanal floral designers...'), 3 => array('title'=>'Quiet Celebrants','text'=>'Officiants chosen specifically...'), 4 => array('title'=>'Beauty Stylists','text'=>'Hair and make-up artists...'), 5 => array('title'=>'Private Chefs','text'=>'Culinary artists...'), 6 => array('title'=>'Keepsake Crafters','text'=>'Artisans who turn your gallery...') ) ),


        'testimonial' => array( 'show' => true, 'order' => 60, 'quote' => '"We chose a cold ridge above Lake Wanaka over a hall full of strangers..."', 'cite' => 'Ana & Tom' ),


        'cta' => array( 'show' => true, 'order' => 70, 'bg_img' => THEME_URI . '/assets/images/cta-bg.jpg', 'title' => 'So — where shall we <em>elope you?</em>', 'text' => 'Tell us a little about the two of you.', 'btn_1_text' => 'Begin your story', 'btn_1_url' => '#', 'btn_2_text' => 'Book a call', 'btn_2_url' => '#' )


    ),





    // ==========================================


    // PRICING PAGE


    // ==========================================


    'pricing' => array(


        'hero' => array(


            'show'    => true, 'order' => 10,


            'bg_img'  => THEME_URI . '/assets/images/hero.jpg',


            'eyebrow' => 'Investment',


            'title'   => 'Thoughtfully priced, <em>beautifully delivered.</em>',


            'lede'    => 'No hidden fees, no surprise quotes. Three thoughtfully built starting points — add anything, drop anything. Every elopement is yours to shape.'


        ),


        'packages' => array(


            'show'  => true, 'order' => 20,


            'pkgs'  => array(


                1 => array('tag'=>'Intimate', 'title'=>'Just the two of us', 'price_label'=>'From', 'price_val'=>'$2,490', 'blurb'=>'A quietly held ceremony, beautifully photographed. Everything you need to say "I do" legally and tenderly.', 'feats'=>array('Licensed celebrant & full legal paperwork', '2 hours photography at one location', 'Hand-tied seasonal bouquet', 'Two witnesses on the day', 'Dedicated planner from enquiry to "I do"', 'Location scouting & booking', 'Champagne toast for two'), 'btn_text'=>'Enquire', 'btn_url'=>'#'),


                2 => array('tag'=>'Signature', 'title'=>'Lakeside & lens', 'price_label'=>'From', 'price_val'=>'$4,990', 'blurb'=>'Our most-loved package — adds cinematography, beauty styling and a second ceremony location.', 'feats'=>array('Everything in <em>Just the two of us</em>', 'Half-day photography (4 hours)', 'Cinema reel & full ceremony film', 'Hair & make-up artist', 'Private vehicle & champagne picnic', 'Two ceremony locations', 'Pre-ceremony "first look" coverage', 'Curated dinner reservation', 'Personalised digital keepsake', '72-hour sneak-peek gallery'), 'btn_text'=>'Enquire', 'btn_url'=>'#'),


                3 => array('tag'=>'Heli', 'title'=>'Above the world', 'price_label'=>'From', 'price_val'=>'$7,990', 'blurb'=>'For couples who want to stand somewhere most people will never see. Helicopter, glacier, aerial cinematography.', 'feats'=>array('Everything in <em>Signature</em>', 'Private helicopter charter', 'Glacier / alpine / ridge landing', 'Cinematic aerial photography', 'Champagne & canapés at altitude', 'Pilot & flight insurance included', 'Weather-flex re-booking promise', 'Full-day photography (6 hours)', 'Reservation at a chef\'s-table dinner', 'Aerial drone reel of your day'), 'btn_text'=>'Enquire', 'btn_url'=>'#')


            )


        ),


        'included' => array(


            'show'       => true, 'order' => 30,


            'head_label' => 'Every elopement includes',


            'head_title' => 'The quiet <em>essentials.</em>',


            'items'      => array(


                1 => array('title'=>'Licensed celebrant', 'text'=>'An officiant chosen for warmth and presence, not just paperwork.'),


                2 => array('title'=>'Photography', 'text'=>'Quietly observant photographers whose work feels remembered.'),


                3 => array('title'=>'Seasonal bouquet', 'text'=>'Hand-tied florals built from what\'s blooming in Aotearoa that week.'),


                4 => array('title'=>'Two witnesses', 'text'=>'Quietly provided by us — so it really can just be the two of you.'),


                5 => array('title'=>'Dedicated planner', 'text'=>'One human who knows your story end to end. No call-centres, ever.'),


                6 => array('title'=>'Legal paperwork', 'text'=>'Marriage licence, witness signatures, official registration — handled.'),


                7 => array('title'=>'Champagne toast', 'text'=>'A chilled bottle of NZ sparkling, ready the moment the rings go on.'),


                8 => array('title'=>'Location scouting', 'text'=>'Sunrise visits, weather watches, jetty bookings — the quiet pre-work.')


            )


        ),


        'addons' => array(


            'show'       => true, 'order' => 40,


            'head_label' => 'Optional extras',


            'head_title' => 'Make it <em>yours.</em>',


            'head_text'  => 'A curated list of additions our couples reach for most. Each can be added to any package.',


            'items'      => array(


                1 => array('title'=>'Videography', 'price'=>'From $1,490'),


                2 => array('title'=>'Hair & make-up', 'price'=>'From $590'),


                3 => array('title'=>'Extra photo hours', 'price'=>'From $290 / hr'),


                4 => array('title'=>'Private dinner', 'price'=>'From $680'),


                5 => array('title'=>'Accommodation', 'price'=>'From $420 / night'),


                6 => array('title'=>'Second location', 'price'=>'From $390'),


                7 => array('title'=>'Live musician', 'price'=>'From $540'),


                8 => array('title'=>'Custom florals', 'price'=>'From $220')


            )


        ),


        'compare' => array(


            'show'       => true, 'order' => 50,


            'head_label' => 'Side by side',


            'head_title' => 'Compare <em>at a glance.</em>'


        ),


        'faq' => array(


            'show'       => true, 'order' => 60,


            'head_label' => 'Common questions',


            'head_title' => 'The questions we hear <em>most often.</em>',


            'items'      => array(


                1 => array('q'=>'What exactly is included in each package?', 'a'=>'Every package includes the celebrant, full legal paperwork, two witnesses, a seasonal bouquet, location scouting and a dedicated planner.'),


                2 => array('q'=>'Can we customise a package?', 'a'=>'Yes, completely. Most of our couples adjust at least one or two elements.'),


                3 => array('q'=>'How far in advance should we book?', 'a'=>'Three to six months is comfortable for most ceremonies. Peak season dates book up faster.'),


                4 => array('q'=>'What if the weather is bad on the day?', 'a'=>'Every package includes a weather-flex re-booking promise. We either move to a plan B or reschedule entirely.'),


                5 => array('q'=>'Do you cater to same-sex couples?', 'a'=>'Always have, always will. New Zealand has full marriage equality.'),


                6 => array('q'=>'What about legalities for overseas couples?', 'a'=>'Marrying in NZ as an overseas couple is straightforward. We\'ve helped couples from Australia, US, UK and beyond.'),


                7 => array('q'=>'Is a deposit required?', 'a'=>'A 30% deposit secures your date. The remaining balance is due 30 days before the ceremony.'),


                8 => array('q'=>'Can a few guests attend?', 'a'=>'Yes — though we keep numbers gentle. Up to six guests can attend any package without changing the price.')


            )


        ),


        'testimonial' => array(


            'show'  => true, 'order' => 70,


            'quote' => '"The Signature package felt like it was <span class="hl">written for us</span>. We didn\'t ask for one customisation — and yet it landed like a tailored suit."',


            'cite'  => 'Charlotte & David · Wanaka'


        ),


        'cta' => array(


            'show'       => true, 'order' => 80,


            'bg_img'     => THEME_URI . '/assets/images/cta-bg.jpg',


            'title'      => 'So — where shall we <em>elope you?</em>',


            'text'       => 'Tell us a little about the two of you. Within a day, we\'ll write back with a thoughtful sketch of what your elopement could look like.',


            'btn_1_text' => 'Begin your story', 'btn_1_url' => '#',


            'btn_2_text' => 'Book a 20-min call', 'btn_2_url' => '#'


        )


    ),





    // ==========================================


    // CONTACT PAGE


    // ==========================================


    'contact' => array(


        'hero' => array(


            'show'    => true, 'order' => 10,


            'bg_img'  => THEME_URI . '/assets/images/hero.jpg',


            'eyebrow' => 'Begin your story · Contact Us',


            'title'   => 'Let\'s plan your<br/><em>great escape.</em>',


            'lede'    => 'Tell us a little about the two of you, your chosen scenery, and the moment you want to share. We\'ll write back within one business day.'


        ),


        'form' => array(


            'show'          => true, 'order' => 20,


            'info_label'    => 'Get in touch',


            'info_title'    => 'We protect your <em>quietest moments.</em>',


            'info_desc'     => 'Every message is received directly by our core planning coordinators. We don\'t use automated questionnaires or call centers.',


            


            'email_title'   => 'Bespoke Enquiries',


            'email_link'    => 'hello@elopingweddings.co.nz',


            'email_sub'     => 'We answer personal email queries within 24 hours',


            


            'phone_title'   => 'Direct Office Phone',


            'phone_link'    => '+64 21 000 000',


            'phone_sub'     => 'Monday to Friday, 9:00 AM – 5:00 PM (NZST)',


            


            'address_title' => 'Planning Studio',


            'address_text'  => 'Level 2, 10 Shotover Street, Queenstown 9300, New Zealand',


            'address_sub'   => 'Consultations by appointment only',


            


            'map_src'       => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11394.398687352345!2d168.65345758223696!3d-45.031174175376176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xa9d51df191405e39%3A0x500ef8684799980!2sQueenstown%2C%20New%20Zealand!5e0!3m2!1sen!2sau!4v1716000000000!5m2!1sen!2sau',


            


            'form_title'    => 'Start your planning',


            'form_intro'    => 'Fill in the fields below to share the shape of your dream. No commitment, no automated spam.',


            'success_title' => 'Your story is in our hands',


            'success_text'  => 'Thank you for sharing your thoughts with us. A senior coordinator will read your details and write back with a custom sketch of your elopement within one business day.'


        )


    ),


    


    // ==========================================


    // GALLERY PAGE (NEW)


    // ==========================================


    'gallery' => array(


        'hero' => array(


            'show'    => true, 'order' => 10,


            'eyebrow' => 'Our Portfolio',


            'title'   => 'Every love story <em>looks different.</em>',


            'lede'    => 'A quiet portfolio of real elopements across Aotearoa — the morning light, the held hands, the moments after the kiss.'


        ),


        'grid' => array(


            'show'    => true, 'order' => 20,


            'filters' => array(


                1 => array('slug' => 'queenstown', 'label' => 'Queenstown'),


                2 => array('slug' => 'wanaka', 'label' => 'Wanaka'),


                3 => array('slug' => 'heli', 'label' => 'Heli'),


                4 => array('slug' => 'beach', 'label' => 'Beach'),


                5 => array('slug' => 'garden', 'label' => 'Garden'),


                6 => array('slug' => 'alpine', 'label' => 'Alpine')


            ),


            'items' => array(


                1 => array('cat' => 'queenstown', 'img' => THEME_URI.'/assets/images/story1.jpg', 'tag' => 'Queenstown', 'title' => 'Ana & Tom · Lake Wakatipu'),


                2 => array('cat' => 'heli alpine', 'img' => THEME_URI.'/assets/images/heli.jpg', 'tag' => 'Heli · Alpine', 'title' => 'Maia & Jack · Cecil Peak'),


                3 => array('cat' => 'wanaka', 'img' => THEME_URI.'/assets/images/wanaka.jpg', 'tag' => 'Wanaka', 'title' => 'Sophie & Liam · Tussock Fields'),


                4 => array('cat' => 'beach', 'img' => THEME_URI.'/assets/images/bay.jpg', 'tag' => 'Beach', 'title' => 'Ruby & Noah · Bay of Islands'),


                5 => array('cat' => 'garden', 'img' => THEME_URI.'/assets/images/exp2.jpg', 'tag' => 'Garden', 'title' => 'Lillian & Sam · Walled Garden'),


                6 => array('cat' => 'alpine', 'img' => THEME_URI.'/assets/images/tekapo.jpg', 'tag' => 'Alpine', 'title' => 'Olivia & James · Chapel')


                // System supports up to 24 items dynamically via ACF


            )


        ),


        'stats' => array(


            'show'  => true, 'order' => 30,


            'items' => array(


                1 => array('num' => '200', 'suffix' => '+', 'decimal' => '0', 'label' => 'Couples married'),


                2 => array('num' => '12', 'suffix' => ' yrs', 'decimal' => '0', 'label' => 'In Aotearoa'),


                3 => array('num' => '15', 'suffix' => '+', 'decimal' => '0', 'label' => 'Stunning locations'),


                4 => array('num' => '4.9', 'suffix' => '★', 'decimal' => '1', 'label' => 'Average rating')


            )


        ),


        'testimonial' => array(


            'show'  => true, 'order' => 40,


            'label' => 'From our couples',


            'slides' => array(


                1 => array('quote' => '"We chose <span class="hl">a ridge above Lake Wanaka</span> over a hall full of strangers. Best decision of our lives..."', 'cite' => 'Ana & Tom · Wanaka'),


                2 => array('quote' => '"From our first call to the last frame of the wedding film, every moment felt <span class="hl">curated, never staged</span>."', 'cite' => 'Maia & Jack · Cecil Peak'),


                3 => array('quote' => '"They thought of everything we forgot to think of — even the little things, like <span class="hl">a warm flask of coffee</span>..."', 'cite' => 'Eden & Ben · Glenorchy')


            )


        ),


        'cta' => array(


            'show'       => true, 'order' => 50,


            'bg_img'     => THEME_URI . '/assets/images/cta-bg.jpg',


            'title'      => 'So — where shall we <em>elope you?</em>',


            'text'       => 'Tell us a little about the two of you. Within a day, we\'ll write back with a thoughtful sketch of what your elopement could look like.',


            'btn_1_text' => 'Begin your story', 'btn_1_url' => '#',


            'btn_2_text' => 'Book a 20-min call', 'btn_2_url' => '#'


        )


    )





); // End of $eloping_defaults array





// Helper function to safely fetch defaults


function get_eloping_default( $page, $section, $key = null, $subkey = null ) {


    global $eloping_defaults;


    if ( ! isset( $eloping_defaults[$page][$section] ) ) return '';


    


    if ( $key ) {


        if ( $subkey && isset( $eloping_defaults[$page][$section][$key][$subkey] ) ) {


            return $eloping_defaults[$page][$section][$key][$subkey];


        }


        return isset( $eloping_defaults[$page][$section][$key] ) ? $eloping_defaults[$page][$section][$key] : '';


    }


    


    return $eloping_defaults[$page][$section];


}