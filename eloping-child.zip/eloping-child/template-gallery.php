<?php
/**
 * Template Name: Gallery
 */
get_header();

$gallery_sections = array(
    'hero',
    'grid',
    'stats',
    'testimonial',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'gallery', $gallery_sections ); ?>
</main>
<?php
get_footer();