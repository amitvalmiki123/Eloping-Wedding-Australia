<?php
/**
 * Template Name: Queenstown Garden Elopement
 */
get_header();

// Same sections array for identical design structure
$garden_sections = array(
    'hero',
    'intro',
    'experiences',
    'highlights',
    'band',
    'plan',
    'testimonial',
    'mini',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php 
    // Same 'queenstown' prefix to fetch the parent design
    eloping_render_sections( 'queenstown', $garden_sections ); 
    ?>
</main>
<?php
get_footer();
?>