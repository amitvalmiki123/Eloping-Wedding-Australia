<?php
/**
 * Template Name: SEO Landing
 *
 * .com.au adaptation of the Eloping Weddings SEO Landing template.
 *
 * Same design system as the About Us sections (markup/classes mirror
 * template-parts/sections/about/* so the parent theme's CSS styles it 1:1),
 * wired to its own `seo_*` ACF fields so each destination page is edited
 * independently in WP admin.
 *
 * Content model:
 *   - Pure ACF renderer: it outputs only what is saved in the page's ACF
 *     fields. No fallback/default values here — a blank field renders nothing.
 *   - ACF field group: inc/seo-landing-acf.php (tabs named in page order:
 *     Hero, Section 1..9, Testimonials, FAQ, CTA). One-time content populate:
 *     inc/seo-landing-seed.php (source copy in inc/seo-landing-defaults.php).
 *
 * Layout (top to bottom). "Eyebrows" removed from every section except Hero.
 *   Hero
 *   Section 1  A More Meaningful Way ....... content LEFT  / image RIGHT
 *   Section 2  What We Can Help You Plan ... content RIGHT / image LEFT   (list)
 *   Section 3  Why Couples Choose .......... centered (list)
 *              Testimonials
 *   Section 4  Destination-Led ............. content LEFT  / image RIGHT  (list)
 *   Section 5  Elopement Packages .......... content RIGHT / image LEFT   (list)
 *   Section 6  Legal Support ............... centered
 *   Section 7  Photography ................. content LEFT  / image RIGHT
 *   Section 8  Who Our Service Is For ...... content RIGHT / image LEFT   (list)
 *   Section 9  Start Planning ............. centered
 *   FAQ (accordion + JSON-LD FAQPage schema)
 *   CTA (+ Contact Form 7)
 *
 * Contact Form 7: hero + CTA forms use the .com.au "SEO Forms" form
 * (id "db74934"), set in inc/seo-landing-defaults.php and overridable per page.
 */
get_header();

/* ---------- helpers ---------- */
if ( ! function_exists( 'seo_f' ) ) {
    /**
     * Return the page's saved ACF value, or '' if it is unset/blank. No
     * defaults: a blank field renders nothing on the front end.
     */
    function seo_f( $name ) {
        $pid = get_queried_object_id();
        if ( ! $pid ) {
            return '';
        }
        $v = get_field( $name, $pid );
        return ( $v === null || $v === false ) ? '' : $v;
    }
}
if ( ! function_exists( 'seo_lines' ) ) {
    /** Split a textarea value into an array of trimmed, non-empty lines. */
    function seo_lines( $str ) {
        $out = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $str ) as $line ) {
            $line = trim( $line );
            if ( $line !== '' ) {
                $out[] = $line;
            }
        }
        return $out;
    }
}

/* ============================ HERO ============================ */
$h_bg         = seo_f( 'seo_hero_bg_img' );
$h_eyebrow    = seo_f( 'seo_hero_eyebrow' );
$h_title      = seo_f( 'seo_hero_title' );
$h_b1_text    = seo_f( 'seo_hero_btn_1_text' );
$h_b1_url     = seo_f( 'seo_hero_btn_1_url' );
$h_b2_text    = seo_f( 'seo_hero_btn_2_text' );
$h_b2_url     = seo_f( 'seo_hero_btn_2_url' );
$h_strong     = seo_f( 'seo_hero_meta_strong' );
$h_lede       = seo_f( 'seo_hero_lede' );
$h_form       = seo_f( 'seo_hero_form' );
$h_form_title = seo_f( 'seo_hero_form_title' );
$h_form_sub   = seo_f( 'seo_hero_form_sub' );

/* ============================ Section 1 — A More Meaningful Way (content left / image right) ============================ */
$s_title = seo_f( 'seo_story_title' );
$s_t1    = seo_f( 'seo_story_text_1' );
$s_t2    = seo_f( 'seo_story_text_2' );
$s_t3    = seo_f( 'seo_story_text_3' );
$s_sig   = seo_f( 'seo_story_signature' );
$s_main  = seo_f( 'seo_story_img_main' );
$s_over  = seo_f( 'seo_story_img_over' );

/* ============================ Section 6 — Legal Support (centered prose) ============================ */
$s2_title = seo_f( 'seo_story2_title' );
$s2_t1    = seo_f( 'seo_story2_text_1' );
$s2_t2    = seo_f( 'seo_story2_text_2' );
$s2_t3    = seo_f( 'seo_story2_text_3' );

/* ============================ Section 7 — Photography (content left / image right) ============================ */
$t_img   = seo_f( 'seo_team_img' );
$t_title = seo_f( 'seo_team_title' );
$t_t1    = seo_f( 'seo_team_text_1' );
$t_t2    = seo_f( 'seo_team_text_2' );
/* Stats optional — blank by default. Add real figures via seo_team_stat_* to show the row. */
$stats = array();
for ( $i = 1; $i <= 3; $i++ ) {
    $stats[ $i ] = array(
        'num'   => seo_f( "seo_team_stat_{$i}_num" ),
        'label' => seo_f( "seo_team_stat_{$i}_label" ),
    );
}

/* ============================ LIST BLOCKS 1–5 ============================
 * Each block: image (optional), title, intro (blank line = new paragraph),
 * a "sub" lead-in line, items (one per line, checkmark bullets) and an outro.
 * Content mapping: 1=What We Can Help, 2=Why Couples Choose, 3=Destination-Led,
 * 4=Packages, 5=Who Our Service Is For.
 */
$lists = array();
for ( $i = 1; $i <= 5; $i++ ) {
    $lists[ $i ] = array(
        'id'    => seo_f( "seo_check_{$i}_id" ),
        'img'   => seo_f( "seo_check_{$i}_img" ),
        'img2'  => seo_f( "seo_check_{$i}_img2" ),
        'title' => seo_f( "seo_check_{$i}_title" ),
        'intro' => seo_f( "seo_check_{$i}_intro" ),
        'sub'   => seo_f( "seo_check_{$i}_sub" ),
        'items' => seo_lines( seo_f( "seo_check_{$i}_items" ) ),
        'outro' => seo_f( "seo_check_{$i}_outro" ),
    );
}

if ( ! function_exists( 'seo_list_inner' ) ) {
    /** Shared inner markup (heading + intro + checkmark list + outro). */
    function seo_list_inner( $c ) {
        if ( ! empty( $c['title'] ) ) {
            echo '<h2>' . wp_kses_post( $c['title'] ) . '</h2>';
        }
        if ( ! empty( $c['intro'] ) ) {
            echo '<div class="ls-intro">';
            foreach ( preg_split( '/\n\s*\n/', $c['intro'] ) as $para ) {
                $para = trim( $para );
                if ( $para !== '' ) {
                    echo '<p>' . wp_kses_post( $para ) . '</p>';
                }
            }
            echo '</div>';
        }
        if ( ! empty( $c['sub'] ) ) {
            echo '<p class="ls-sub">' . wp_kses_post( $c['sub'] ) . '</p>';
        }
        if ( ! empty( $c['items'] ) ) {
            echo '<ul class="ls-items">';
            foreach ( $c['items'] as $item ) {
                echo '<li>' . wp_kses_post( $item ) . '</li>';
            }
            echo '</ul>';
        }
        if ( ! empty( $c['outro'] ) ) {
            echo '<p class="ls-outro">' . wp_kses_post( $c['outro'] ) . '</p>';
        }
    }
}

if ( ! function_exists( 'seo_render_list' ) ) {
    /**
     * Render a list block.
     * $layout: 'centered' | 'image-left' | 'image-right'. Image layouts fall
     * back to centered when no image is set. $bg: 'paper' | 'paper2' | 'cream'.
     * $cta: optional HTML appended after the content.
     */
    function seo_render_list( $c, $layout = 'centered', $bg = '', $cta = '' ) {
        if ( empty( $c['title'] ) && empty( $c['items'] ) ) {
            return;
        }
        $has_image = ( 'image-left' === $layout || 'image-right' === $layout ) && ! empty( $c['img'] );
        $classes   = 'seo-list';
        if ( $bg ) {
            $classes .= ' seo-band-' . $bg;
        }
        $classes  .= $has_image ? ' has-image ' . $layout : ' centered';
        $id_attr = ! empty( $c['id'] ) ? ' id="' . esc_attr( $c['id'] ) . '"' : '';
        ?>
        <section class="<?php echo esc_attr( $classes ); ?>"<?php echo $id_attr; ?>>
          <?php if ( $has_image ) : ?>
          <div class="wrap ls-split">
            <div class="ls-media">
              <img class="ls-img-main" src="<?php echo esc_url( $c['img'] ); ?>" alt="<?php echo esc_attr( wp_strip_all_tags( $c['title'] ) ); ?>" loading="lazy" />
              <?php if ( ! empty( $c['img2'] ) ) : ?><img class="ls-img-over" src="<?php echo esc_url( $c['img2'] ); ?>" alt="" loading="lazy" /><?php endif; ?>
            </div>
            <div class="ls-body"><?php seo_list_inner( $c ); echo $cta; ?></div>
          </div>
          <?php else : ?>
          <div class="wrap"><?php seo_list_inner( $c ); echo $cta; ?></div>
          <?php endif; ?>
        </section>
        <?php
    }
}

/* ============================ Section 9 — Start Planning (centered) ============================ */
$ls_title = seo_f( 'seo_love_title' );
$ls_text  = seo_f( 'seo_love_text' );

/* ============================ FAQ ============================ */
$faq_title = seo_f( 'seo_faq_title' );
$faqs = array();
for ( $i = 1; $i <= 8; $i++ ) {
    $q = seo_f( "seo_faq_{$i}_q" );
    $a = seo_f( "seo_faq_{$i}_a" );
    if ( $q && $a ) {
        $faqs[] = array( 'q' => $q, 'a' => $a );
    }
}

/* ============================ TESTIMONIAL (renders only when a quote is set) ============================ */
$q_bg    = seo_f( 'seo_test_bg_img' );
$q_quote = seo_f( 'seo_test_quote' );
$q_cite  = seo_f( 'seo_test_cite' );

/* ============================ CTA ============================ */
$c_bg         = seo_f( 'seo_cta_bg_img' );
$c_title      = seo_f( 'seo_cta_title' );
$c_text       = seo_f( 'seo_cta_text' );
$c_form       = seo_f( 'seo_cta_form' );
$c_form_title = seo_f( 'seo_cta_form_title' );
$c_form_sub   = seo_f( 'seo_cta_form_sub' );

/* Build FAQ JSON-LD once. */
$faq_schema = '';
if ( ! empty( $faqs ) ) {
    $faq_entities = array();
    foreach ( $faqs as $f ) {
        $answer_text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $f['a'] ) ) );
        $faq_entities[] = array(
            '@type'          => 'Question',
            'name'           => wp_strip_all_tags( $f['q'] ),
            'acceptedAnswer' => array(
                '@type' => 'Answer',
                'text'  => $answer_text,
            ),
        );
    }
    $faq_schema = wp_json_encode( array(
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => $faq_entities,
    ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
}

/* Section CTA — the same two buttons as the hero, reused at the bottom of each
 * content section (not FAQ / testimonial / bottom CTA). Empty if the hero has
 * no buttons set. */
$cta_html = '';
if ( ( $h_b1_text && $h_b1_url ) || ( $h_b2_text && $h_b2_url ) ) {
    ob_start(); ?>
    <div class="seo-sec-cta">
      <?php if ( $h_b1_text && $h_b1_url ) : ?><a href="<?php echo esc_url( $h_b1_url ); ?>" class="btn btn-primary"><?php echo esc_html( $h_b1_text ); ?> <i class="arrow"></i></a><?php endif; ?>
      <?php if ( $h_b2_text && $h_b2_url ) : ?><a href="<?php echo esc_url( $h_b2_url ); ?>" class="btn btn-ghost"><?php echo esc_html( $h_b2_text ); ?></a><?php endif; ?>
    </div>
    <?php $cta_html = ob_get_clean();
}
?>

<style>
  /* ---- HERO: side text under H1, form on the right ---- */
  .seo-hero .inner{align-items:center;}
  .seo-hero .hero-lede{max-width:48ch;margin:8px 0 26px;padding-left:22px;border-left:1px solid rgba(235,153,162,.75);}
  .seo-hero .hero-lede strong{display:block;font-family:var(--serif,"Cormorant Garamond",serif);
    font-style:italic;font-weight:400;color:var(--blush,#F6BBBA);font-size:1.5rem;line-height:1.2;margin-bottom:.35em;}
  .seo-hero .hero-lede .hero-lede-text{color:#f0e8dc;font-size:1rem;line-height:1.65;}
  .seo-hero .hero-form-col{width:100%;}
  .hero-form-card{background:#fff;color:var(--ink,#1c211a);padding:32px 30px 26px;
    border-top:3px solid var(--rose,#EB99A2);box-shadow:0 26px 60px rgba(28,33,26,.28);}
  .hero-form-card h3{font-family:var(--serif,"Cormorant Garamond",serif);color:var(--forest,#41503A);
    font-size:1.7rem;text-align:center;margin:0 0 .3em;}
  .hero-form-card .sub{font-size:.82rem;color:#6c6a62;text-align:center;margin:0 0 18px;}
  .hero-form-card .ph-note{font-size:.85rem;color:#6c6a62;text-align:center;margin:0 0 16px;}
  .hero-form-card .btn{display:block;text-align:center;}

  /* ---- Photography: content LEFT / image RIGHT (flip ab-team's default) ---- */
  .ab-team.seo-team-alt > .copy{order:0;}
  .ab-team.seo-team-alt > .visual{order:1;}

  /* ---- More breathing room: taller vertical padding on every section.
     (This <style> is inline in the template, so it only affects this page —
     .ab-story / .ab-team overrides here don't touch the About page.) ---- */
  .ab-story,.ab-team{padding-top:clamp(100px,9vw,150px);padding-bottom:clamp(100px,9vw,150px);}

  /* ---- Section background bands: alternate --paper / --paper-2, --cream on centered ---- */
  .seo-band-paper{background:var(--paper,#fbf7f3);}
  .seo-band-paper2{background:var(--paper-2,#f4eee6);}
  .seo-band-cream{background:var(--cream,#FAE6DD);}
  .ab-story.seo-band-paper,.ab-team.seo-band-paper{background:var(--paper,#fbf7f3);}
  .ab-story.seo-band-paper2,.ab-team.seo-band-paper2{background:var(--paper-2,#f4eee6);}

  /* ---- List blocks (checkmark bullets; centered OR image-beside) ---- */
  .seo-list{padding:84px 0;}
  .seo-list .wrap{max-width:var(--maxw,1240px);margin:0 auto;padding:0 var(--gutter,28px);}
  .seo-list h2{font-family:var(--serif,"Cormorant Garamond",serif);font-weight:300;
    font-size:clamp(2rem,4.2vw,3.2rem);line-height:1.06;letter-spacing:-.01em;
    color:var(--forest,#41503A);margin:0 0 .4em;}
  .seo-list .ls-intro p{font-family:var(--sans,"DM Sans",sans-serif);font-size:17px;
    line-height:1.6;color:var(--ink,#1c211a);margin:0 0 14px;}
  .seo-list .ls-sub{font-family:var(--sans,"DM Sans",sans-serif);font-weight:600;
    color:var(--forest,#41503A);margin:8px 0 22px;}
  .seo-list .ls-items{list-style:none;padding:0;margin:0 0 26px;
    display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:13px 36px;}
  .seo-list .ls-items li{position:relative;padding-left:34px;text-align:left;
    font-family:var(--sans,"DM Sans",sans-serif);font-size:15.5px;line-height:1.5;color:var(--ink,#1c211a);}
  .seo-list .ls-items li::before{content:"";position:absolute;left:0;top:1px;
    width:21px;height:21px;border-radius:50%;background:var(--rose,#EB99A2);}
  .seo-list .ls-items li::after{content:"";position:absolute;left:6.5px;top:7px;
    width:8px;height:4px;border-left:2px solid #fff;border-bottom:2px solid #fff;transform:rotate(-45deg);}
  .seo-list .ls-outro{font-family:var(--sans,"DM Sans",sans-serif);font-size:16px;
    line-height:1.6;color:var(--ink,#1c211a);max-width:74ch;margin:0;}

  /* Centered variant — stretch to the full section width (like the image sections) */
  .seo-list.centered{text-align:center;}
  .seo-list.centered .ls-outro{max-width:none;margin:0;}

  /* Image-beside variant */
  .seo-list.has-image .ls-split{display:grid;grid-template-columns:1fr 1fr;gap:min(6vw,60px);align-items:center;}
  .seo-list.has-image .ls-body .ls-items{grid-template-columns:repeat(auto-fit,minmax(200px,1fr));}
  .seo-list.image-right .ls-media{order:1;}
  .seo-list.image-right .ls-body{order:0;}
  .seo-list.image-left .ls-media{order:0;}
  .seo-list.image-left .ls-body{order:1;}
  /* Arched main image (both sides): pronounced arch top, subtle bottom corners */
  .seo-list.has-image .ls-media{position:relative;}
  .seo-list.has-image .ls-img-main{width:100%;height:auto;display:block;position:relative;z-index:1;
    border-radius:48% 48% 16px 16px / 34% 34% 16px 16px;
    box-shadow:0 24px 60px rgba(28,33,26,.16);}
  /* Overlapping secondary photo (Section-1 "overlap" style) */
  .seo-list.has-image .ls-img-over{position:absolute;z-index:2;width:46%;height:auto;display:block;
    border-radius:10px;border:6px solid #fff;box-shadow:0 18px 42px rgba(28,33,26,.24);}
  .seo-list.image-right .ls-img-over{left:-26px;bottom:-30px;}
  .seo-list.image-left .ls-img-over{right:-26px;bottom:-30px;}
  @media(max-width:900px){
    .seo-list.has-image .ls-img-over{width:42%;left:14px;right:auto;bottom:-20px;}
  }
  @media(max-width:900px){
    .seo-list.has-image .ls-split{grid-template-columns:1fr;gap:26px;}
    /* Mobile: content first, image second */
    .seo-list.has-image .ls-body{order:0 !important;}
    .seo-list.has-image .ls-media{order:1 !important;}
  }

  /* ---- Plain content sections (Legal, Start Planning) — centered ---- */
  .seo-plain{padding:90px 0;text-align:center;}
  .seo-plain .wrap{max-width:var(--maxw,1240px);margin:0 auto;padding:0 var(--gutter,28px);}
  .seo-plain h2{
    font-family:var(--serif,"Cormorant Garamond",serif);font-weight:300;
    font-size:clamp(2.2rem,4.6vw,3.6rem);line-height:1.05;letter-spacing:-.01em;
    color:var(--forest,#41503A);margin:0 0 .3em;}
  .seo-plain p{
    font-family:var(--sans,"DM Sans",sans-serif);font-size:17px;line-height:1.65;
    color:var(--ink,#1c211a);margin:0 0 14px;}
  .seo-plain p:last-child{margin-bottom:0;}

  /* ---- Section CTA buttons (reused hero buttons) ---- */
  .seo-sec-cta{display:flex;flex-wrap:wrap;gap:14px;margin-top:34px;}
  .seo-list.centered .seo-sec-cta,.seo-plain .seo-sec-cta{justify-content:center;}
  .seo-list.has-image .ls-body .seo-sec-cta{margin-top:28px;}
  /* Keep the ghost button legible on the light section backgrounds */
  .seo-sec-cta .btn-ghost{color:var(--forest,#41503A);border-color:var(--forest,#41503A);background:transparent;}
  .seo-sec-cta .btn-ghost:hover{background:var(--forest,#41503A);color:#fff;}
  @media(max-width:900px){
    .seo-sec-cta{justify-content:center;}
    /* Keep FAQ question + answer left-aligned on mobile */
    .seo-faq summary,.seo-faq .seo-faq-ans,.seo-faq .seo-faq-ans p{text-align:left;}
  }

  /* ---- FAQ accordion ---- */
  .seo-faq{padding:92px 0;}
  .seo-faq .wrap{max-width:880px;margin:0 auto;padding:0 var(--gutter,28px);}
  .seo-faq .faq-head{text-align:center;margin:0 auto 44px;}
  .seo-faq h2{font-family:var(--serif,"Cormorant Garamond",serif);font-weight:300;
    font-size:clamp(2rem,4.4vw,3.4rem);line-height:1.05;color:var(--forest,#41503A);margin:0;}
  /* Card-style items: white rounded cards, spaced, rose border when open */
  .seo-faq details{background:#fff;border:1px solid transparent;border-radius:16px;
    margin-bottom:14px;padding:6px 32px 18px;overflow:visible;box-shadow:0 10px 30px rgba(28,33,26,.06);
    transition:border-color .25s ease,box-shadow .25s ease;}
  .seo-faq details[open]{border-color:var(--rose,#EB99A2);box-shadow:0 16px 42px rgba(28,33,26,.09);}
  .seo-faq summary{list-style:none;cursor:pointer;display:block;position:relative;
    padding:22px 44px 22px 0;font-family:var(--sans,"DM Sans",sans-serif);
    font-size:1.05rem;line-height:1.4;color:#3c3b37;font-weight:500;}
  .seo-faq summary::-webkit-details-marker{display:none;}
  .seo-faq summary::after{content:"+";position:absolute;right:0;top:23px;
    font-family:var(--sans,"DM Sans",sans-serif);font-size:1.5rem;line-height:1;color:#b8b2aa;font-weight:400;}
  .seo-faq details[open] summary::after{content:"\2013";color:var(--rose,#EB99A2);}
  .seo-faq .seo-faq-ans{padding:4px 0 18px;}
  .seo-faq .seo-faq-ans p{font-family:var(--sans,"DM Sans",sans-serif);font-size:15.5px;
    line-height:1.7;color:#6b6862;margin:0 0 12px;}
  .seo-faq .seo-faq-ans p:first-child{margin-top:0;}
  .seo-faq .seo-faq-ans p:last-child{margin-bottom:0;}

  /* ---- Testimonial: min height, vertically centered content ---- */
  .ab-testimonial.seo-testi{min-height:70vh;display:flex;align-items:center;}
  .ab-testimonial.seo-testi > .wrap{width:100%;}
  /* ---- Testimonial with background image (dark overlay, light text) ---- */
  .ab-testimonial.seo-testi-bg{position:relative;background-size:cover;background-position:center;background-repeat:no-repeat;}
  .ab-testimonial.seo-testi-bg::before{content:"";position:absolute;inset:0;background:rgba(28,33,26,.55);}
  .ab-testimonial.seo-testi-bg .wrap{position:relative;z-index:1;}
  .ab-testimonial.seo-testi-bg .stars,
  .ab-testimonial.seo-testi-bg blockquote,
  .ab-testimonial.seo-testi-bg cite{color:#fff;}

  /* ---- Shared CF7 form styling (hero card + CTA band) ---- */
  .seo-form .grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
  .seo-form p{margin:0 0 12px;}
  .seo-form label{display:block;font-family:var(--accent,"Quicksand",sans-serif);font-size:.66rem;
    letter-spacing:.16em;text-transform:uppercase;color:var(--forest,#41503A);font-weight:600;margin-bottom:5px;}
  .seo-form input[type=text],.seo-form input[type=email],.seo-form input[type=tel],.seo-form textarea{
    width:100%;font-family:var(--sans,"DM Sans",sans-serif);font-size:.95rem;color:var(--ink,#1c211a);
    padding:11px 14px;border:1px solid var(--line,#ecd9d0);background:#fbf9f5;border-radius:0;}
  .seo-form input:focus,.seo-form textarea:focus{outline:none;border-color:var(--rose,#EB99A2);}
  .seo-form textarea{height:112px;min-height:112px;resize:vertical;}
  .seo-form input[type=submit],.seo-form button[type=submit],.seo-form .wpcf7-submit{
    width:100%;font-family:var(--accent,"Quicksand",sans-serif);font-size:13px;letter-spacing:.14em;
    text-transform:uppercase;font-weight:600;padding:15px 30px;border:1px solid var(--rose,#EB99A2);
    background:var(--rose,#EB99A2);color:#fff;border-radius:999px;cursor:pointer;transition:all .25s ease;-webkit-appearance:none;appearance:none;}
  .seo-form input[type=submit]:hover,.seo-form button[type=submit]:hover,.seo-form .wpcf7-submit:hover{background:#e07f8b;border-color:#e07f8b;}
  .seo-form .wpcf7-spinner{margin:14px auto 0;display:block;}

  /* ---- CTA band form (kept centered, as a card) ---- */
  .seo-cta .cta-form-wrap{max-width:660px;margin:30px auto 0;background:#fff;color:var(--ink,#1c211a);
    padding:34px 34px 28px;border-top:3px solid var(--rose,#EB99A2);box-shadow:0 24px 60px rgba(28,33,26,.16);text-align:left;}
  .cta-form-wrap h3{font-family:var(--serif,"Cormorant Garamond",serif);font-weight:300;color:var(--forest,#41503A);
    font-size:1.9rem;text-align:center;margin:0 0 .1em;}
  .cta-form-wrap .sub{text-align:center;font-size:.85rem;color:#6c6a62;margin:0 0 18px;}

  @media(max-width:960px){
    .seo-hero .inner{align-items:stretch;}
    .seo-hero .hero-form-col{order:3;margin-top:8px;}
  }
  @media(max-width:620px){
    .seo-form .grid2{grid-template-columns:1fr;}
  }
</style>

<main id="main" class="site-main">

  <!-- ===================== HERO ===================== -->
  <section class="page-hero split-hero seo-hero" style="position: relative;">
    <?php if ( $h_bg ) : ?>
    <div class="bg">
      <img src="<?php echo esc_url( $h_bg ); ?>" alt="<?php echo esc_attr( wp_strip_all_tags( $h_title ) ); ?>" loading="eager" fetchpriority="high" />
    </div>
    <?php endif; ?>
    <div class="inner">
      <div class="left">
        <?php if ( $h_eyebrow ) : ?><div class="eyebrow"><span class="dot"></span> <?php echo esc_html( $h_eyebrow ); ?></div><?php endif; ?>
        <?php if ( $h_title ) : ?><h1><?php echo wp_kses_post( $h_title ); ?></h1><?php endif; ?>

        <?php if ( $h_strong || $h_lede ) : ?>
        <div class="hero-lede">
          <?php if ( $h_strong ) : ?><strong><?php echo esc_html( $h_strong ); ?></strong><?php endif; ?>
          <?php if ( $h_lede ) : ?><span class="hero-lede-text"><?php echo wp_kses_post( $h_lede ); ?></span><?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="actions" style="margin-bottom: 22px;">
          <?php if ( $h_b1_text && $h_b1_url ) : ?><a href="<?php echo esc_url( $h_b1_url ); ?>" class="btn btn-primary"><?php echo esc_html( $h_b1_text ); ?> <i class="arrow"></i></a><?php endif; ?>
          <?php if ( $h_b2_text && $h_b2_url ) : ?><a href="<?php echo esc_url( $h_b2_url ); ?>" class="btn btn-ghost"><?php echo esc_html( $h_b2_text ); ?></a><?php endif; ?>
        </div>
        <div class="crumbs">
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><span class="sep">›</span>
          <span><?php echo esc_html( get_the_title() ); ?></span>
        </div>
      </div>

      <div class="hero-form-col">
        <div class="hero-form-card seo-form">
          <?php if ( $h_form_title ) : ?><h3><?php echo esc_html( $h_form_title ); ?></h3><?php endif; ?>
          <?php if ( $h_form_sub ) : ?><p class="sub"><?php echo esc_html( $h_form_sub ); ?></p><?php endif; ?>
          <?php if ( $h_form ) : ?>
            <?php echo do_shortcode( $h_form ); ?>
          <?php else : ?>
            <p class="ph-note">Paste your Contact Form 7 shortcode into the <strong>Hero Form Shortcode</strong> field to show your enquiry form here.</p>
            <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>">Enquire Now <i class="arrow"></i></a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- ===================== Section 1 — A More Meaningful Way (content left / image right) ===================== -->
  <section class="ab-story fade-in seo-band-paper">
    <div>
      <?php if ( $s_title ) : ?><h2><?php echo wp_kses_post( $s_title ); ?></h2><?php endif; ?>
      <?php if ( $s_t1 ) : ?><p><?php echo wp_kses_post( $s_t1 ); ?></p><?php endif; ?>
      <?php if ( $s_t2 ) : ?><p><?php echo wp_kses_post( $s_t2 ); ?></p><?php endif; ?>
      <?php if ( $s_t3 ) : ?><p><?php echo wp_kses_post( $s_t3 ); ?></p><?php endif; ?>
      <?php if ( $s_sig ) : ?><div class="sig"><?php echo esc_html( $s_sig ); ?></div><?php endif; ?>
      <?php echo $cta_html; ?>
    </div>
    <div class="image">
      <?php if ( $s_main ) : ?><img src="<?php echo esc_url( $s_main ); ?>" alt="A more meaningful way to get married" loading="lazy" /><?php endif; ?>
      <?php if ( $s_over ) : ?><div class="image-2"><img src="<?php echo esc_url( $s_over ); ?>" alt="Elopement detail" loading="lazy" /></div><?php endif; ?>
    </div>
  </section>

  <!-- ===================== Section 2 — What We Can Help You Plan (content right / image left) ===================== -->
  <?php seo_render_list( $lists[1], 'image-left', 'paper2', $cta_html ); ?>

  <!-- ===================== Section 3 — Why Couples Choose to Elope With Us (centered, white so the pink testimonial stands out) ===================== -->
  <?php seo_render_list( $lists[2], 'centered', 'cream', $cta_html ); ?>

  <!-- ===================== Testimonials (directly below Section 3) ===================== -->
  <?php if ( $q_quote ) : ?>
  <section class="ab-testimonial seo-testi<?php echo $q_bg ? ' seo-testi-bg' : ''; ?>"<?php echo $q_bg ? ' style="background-image:url(' . esc_url( $q_bg ) . ')"' : ''; ?>>
    <div class="wrap">
      <div class="stars">★ ★ ★ ★ ★</div>
      <blockquote><?php echo wp_kses_post( $q_quote ); ?></blockquote>
      <?php if ( $q_cite ) : ?><cite><?php echo esc_html( $q_cite ); ?></cite><?php endif; ?>
    </div>
  </section>
  <?php endif; ?>

  <!-- ===================== Section 4 — Destination-Led Planning (content left / image right) ===================== -->
  <?php seo_render_list( $lists[3], 'image-right', 'paper', $cta_html ); ?>

  <!-- ===================== Section 5 — Elopement Packages (content right / image left) ===================== -->
  <?php seo_render_list( $lists[4], 'image-left', 'paper2', $cta_html ); ?>

  <!-- ===================== Section 6 — Legal Support (centered prose) ===================== -->
  <section class="seo-plain seo-band-cream">
    <div class="wrap">
      <?php if ( $s2_title ) : ?><h2><?php echo wp_kses_post( $s2_title ); ?></h2><?php endif; ?>
      <?php if ( $s2_t1 ) : ?><p><?php echo wp_kses_post( $s2_t1 ); ?></p><?php endif; ?>
      <?php if ( $s2_t2 ) : ?><p><?php echo wp_kses_post( $s2_t2 ); ?></p><?php endif; ?>
      <?php if ( $s2_t3 ) : ?><p><?php echo wp_kses_post( $s2_t3 ); ?></p><?php endif; ?>
      <?php echo $cta_html; ?>
    </div>
  </section>

  <!-- ===================== Section 7 — Photography (content left / image right) ===================== -->
  <section class="ab-team seo-team-alt seo-band-paper">
    <div class="visual fade-in">
      <?php if ( $t_img ) : ?><img src="<?php echo esc_url( $t_img ); ?>" alt="Elopement photography that captures the feeling of the day" loading="lazy" /><?php endif; ?>
    </div>
    <div class="copy fade-in">
      <?php if ( $t_title ) : ?><h2><?php echo wp_kses_post( $t_title ); ?></h2><?php endif; ?>
      <?php if ( $t_t1 ) : ?><p><?php echo wp_kses_post( $t_t1 ); ?></p><?php endif; ?>
      <?php if ( $t_t2 ) : ?><p><?php echo wp_kses_post( $t_t2 ); ?></p><?php endif; ?>
      <?php $has_stats = array_filter( $stats, function( $s ){ return $s['num'] !== '' || $s['label'] !== ''; } ); ?>
      <?php if ( $has_stats ) : ?>
      <div class="stat-row">
        <?php foreach ( $stats as $stat ) : if ( $stat['num'] === '' && $stat['label'] === '' ) continue; ?>
        <div class="stat-item">
          <?php if ( $stat['num'] !== '' ) : ?><div class="num"><?php echo esc_html( $stat['num'] ); ?></div><?php endif; ?>
          <?php if ( $stat['label'] !== '' ) : ?><span><?php echo esc_html( $stat['label'] ); ?></span><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <?php echo $cta_html; ?>
    </div>
  </section>

  <!-- ===================== Section 8 — Who Our Service Is For (content right / image left) ===================== -->
  <?php seo_render_list( $lists[5], 'image-left', 'paper2', $cta_html ); ?>

  <!-- ===================== Section 9 — Start Planning (plain, centered) ===================== -->
  <section class="seo-plain seo-band-cream">
    <div class="wrap">
      <?php if ( $ls_title ) : ?><h2><?php echo wp_kses_post( $ls_title ); ?></h2><?php endif; ?>
      <?php if ( $ls_text ) : foreach ( preg_split( '/\n\s*\n/', $ls_text ) as $para ) : $para = trim( $para ); if ( $para === '' ) continue; ?>
        <p><?php echo wp_kses_post( $para ); ?></p>
      <?php endforeach; endif; ?>
      <?php echo $cta_html; ?>
    </div>
  </section>

  <!-- ===================== FAQ (accordion + FAQPage schema) ===================== -->
  <?php if ( ! empty( $faqs ) ) : ?>
  <section class="seo-faq seo-band-paper">
    <div class="wrap">
      <div class="faq-head">
        <?php if ( $faq_title ) : ?><h2><?php echo wp_kses_post( $faq_title ); ?></h2><?php endif; ?>
      </div>
      <?php foreach ( $faqs as $f ) : ?>
      <details>
        <summary><?php echo wp_kses_post( $f['q'] ); ?></summary>
        <div class="seo-faq-ans">
          <?php foreach ( seo_lines( $f['a'] ) as $para ) : ?>
            <p><?php echo wp_kses_post( $para ); ?></p>
          <?php endforeach; ?>
        </div>
      </details>
      <?php endforeach; ?>
    </div>
  </section>
  <?php if ( $faq_schema ) : ?>
  <script type="application/ld+json"><?php echo $faq_schema; ?></script>
  <?php endif; ?>
  <?php endif; ?>

  <!-- ===================== CTA + CONTACT FORM ===================== -->
  <section class="cta-band seo-cta">
    <?php if ( $c_bg ) : ?><img src="<?php echo esc_url( $c_bg ); ?>" alt="Start planning your Australian elopement" loading="lazy" /><?php endif; ?>
    <div class="wrap">
      <?php if ( $c_title ) : ?><h2><?php echo wp_kses_post( $c_title ); ?></h2><?php endif; ?>
      <?php if ( $c_text ) : ?><p><?php echo wp_kses_post( $c_text ); ?></p><?php endif; ?>

      <?php if ( $c_form ) : ?>
        <div class="cta-form-wrap seo-form">
          <?php if ( $c_form_title ) : ?><h3><?php echo esc_html( $c_form_title ); ?></h3><?php endif; ?>
          <?php if ( $c_form_sub ) : ?><p class="sub"><?php echo esc_html( $c_form_sub ); ?></p><?php endif; ?>
          <?php echo do_shortcode( $c_form ); ?>
        </div>
      <?php else : ?>
        <div class="actions">
          <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>">Start Planning Your Elopement <i class="arrow"></i></a>
        </div>
      <?php endif; ?>
    </div>
  </section>

</main>

<?php get_footer();