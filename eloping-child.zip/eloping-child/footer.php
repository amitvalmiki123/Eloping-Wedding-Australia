<?php


/**


 * The template for displaying the footer


 */


?>


<footer>


  <div class="footer-grid">


    


    <div class="footer-brand">


      <span class="wordmark"><img src="<?php echo esc_url( THEME_URI . '/assets/images/eloping-weddings-Logo.png' ); ?>" alt="Eloping Weddings" class="footer-logo"></span>


      <p>Boutique elopement experiences across Noosa Australia. Quietly orchestrated. Cinematically remembered.</p>


       <div class="socials">


          <!-- Facebook Icon -->


          <a href="https://www.facebook.com/elopingweddings/" target="_blank" aria-label="Facebook"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg></a>


        


          <!-- Instagram Icon -->


          <a href="https://www.instagram.com/elopingweddingscom/" target="_blank" aria-label="Instagram"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>


        


          <!-- YouTube Icon -->


          <a href="https://www.youtube.com/channel/UCgAJcKTFcOWgev0oJ6EeX3w?view_as=subscriber" target="_blank" aria-label="YouTube"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/></svg></a>


      </div>


    </div>





    <div class="footer-col-accordion">


      <button class="footer-acc-trigger" aria-expanded="false">Destinations<span class="footer-acc-icon"></span></button>


      <div class="footer-acc-body">


        <h4>Destinations</h4>


        <?php


        if ( has_nav_menu( 'footer_dest' ) ) {


            wp_nav_menu( array(


                'theme_location' => 'footer_dest',


                'container'      => false,


                'items_wrap'     => '<ul>%3$s</ul>',


                'fallback_cb'    => false,


            ) );


        }


        ?>


      </div>


    </div>





    <div class="footer-col-accordion">


      <button class="footer-acc-trigger" aria-expanded="false">Experience<span class="footer-acc-icon"></span></button>


      <div class="footer-acc-body">


        <h4>Experience</h4>


        <?php


        if ( has_nav_menu( 'footer_exp' ) ) {


            wp_nav_menu( array(


                'theme_location' => 'footer_exp',


                'container'      => false,


                'items_wrap'     => '<ul>%3$s</ul>',


                'fallback_cb'    => false,


            ) );


        }


        ?>


      </div>


    </div>





    <div class="news footer-news-col">


      <h4>The slow newsletter</h4>


      <p>Once a month, we send a quiet email — new destinations, real elopements, planning notes. Nothing else.</p>


      


      <!-- Newsletter Shortcode Wrapper -->


      <div class="input">


        <?php echo do_shortcode('[newsletter_form]'); ?>


      </div>





    </div>


    


  </div>





  <div class="footer-bottom">


    <span>© <?php echo date('Y'); ?> Eloping Weddings. All rights reserved. Designed by <a href="https://www.digitalmovement.com.au/" target="_blank">Digital Movement</a> | <a href="https://elopingweddings.com.au/user-sitemap/" target="_blank">User Sitemap</a></span>


    <span><a href="/privacy-policy">Privacy</a> · <a href="/terms">Terms</a></span>


  </div>


</footer>





<!-- Scroll to Top Button -->


<button id="scrollTopBtn" class="scroll-top-btn" aria-label="Scroll to top">


  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 15l-6-6-6 6"/></svg>


</button>





<!-- Mobile Navigation Drawer -->


<div class="mobile-drawer" id="mobileDrawer" role="dialog" aria-modal="true" aria-label="Navigation menu">


  <div class="overlay" id="drawerOverlay"></div>


  <div class="panel">


    


    <div class="drawer-head">


      <span class="wordmark">eloping weddings</span>


      <button class="drawer-close" id="drawerClose" aria-label="Close menu"></button>


    </div>


    


    <div class="drawer-body">


      <div class="drawer-section">


        


        <!-- Main Menu Items -->


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/')); ?>">Home</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/about')); ?>">About</a>


        


        <!-- Destinations Dropdown -->


        <div class="drawer-link-wrap">


          <a href="#" class="drawer-link-text" style="pointer-events: none;">Destinations</a>


          <button class="drawer-link-toggle" data-sub="sub-destinations"><i class="drawer-arrow"></i></button>


        </div>


        


        <div class="drawer-sub" id="sub-destinations">


          <a href="<?php echo esc_url(home_url('/noosa')); ?>">Noosa</a>


          <a href="<?php echo esc_url(home_url('/caloundra')); ?>">Caloundra</a>


          <a href="<?php echo esc_url(home_url('/mooloolaba')); ?>">Mooloolaba</a>


          <a href="<?php echo esc_url(home_url('/brisbane')); ?>">Brisbane</a>


          <a href="<?php echo esc_url(home_url('/gold-coast')); ?>">Gold Coast</a>


          <a href="<?php echo esc_url(home_url('/byron-bay')); ?>">Byron Bay</a>


          <a href="<?php echo esc_url(home_url('/magnetic-island')); ?>">Magnetic Island</a>


          <a href="<?php echo esc_url(home_url('/airlie-beach')); ?>">Airlie Beach</a>


          <a href="<?php echo esc_url(home_url('/whitsunday-islands')); ?>">Whitsunday Islands</a>


          <a href="<?php echo esc_url(home_url('/port-douglas')); ?>">Port Douglas</a>


        </div>


        


        <!-- Remaining Main Menu Items -->


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/heli-elopements')); ?>">Heli Elopements</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/same-sex')); ?>">Same Sex</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/proposals')); ?>">Proposals</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/gallery')); ?>">Gallery</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/pricing')); ?>">Pricing</a>


        <a class="drawer-link-text" style="display:block; padding:13px 14px;" href="<?php echo esc_url(home_url('/contact-us')); ?>">Contact Us</a>


        


      </div>


    </div>


    


    <a class="drawer-cta" href="<?php echo esc_url(home_url('/contact-us')); ?>">Begin your story</a>


    <div style="height:24px"></div>


  </div>


</div>





<script>


  /* 1. IntersectionObserver fades (Scroll Animations) */


  (function(){


    const io = new IntersectionObserver((entries)=>{


      entries.forEach(e=>{ if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)} });


    },{threshold:.12});


    document.querySelectorAll('.fade-in').forEach(el=>io.observe(el));


  })();





/* 2. BULLETPROOF MOBILE DROPDOWN */


  document.addEventListener('click', function(e) {


      // Sirf 'Arrow Button' par click hone par event chalega


      let toggle = e.target.closest('.drawer-link-toggle');


      if (!toggle) return;





      e.preventDefault();


      


      const subId = toggle.getAttribute('data-sub');


      const sub = document.getElementById(subId);


      if (!sub) return;





      const wrap = toggle.closest('.drawer-link-wrap');


      const isOpen = sub.classList.contains('open');





      document.querySelectorAll('.drawer-sub').forEach(s => s.classList.remove('open'));


      document.querySelectorAll('.drawer-link-wrap').forEach(b => b.classList.remove('active'));





      if (!isOpen) {


          sub.classList.add('open');


          if(wrap) wrap.classList.add('active');


      }


  });





  /* 3. Footer Accordion (For Mobile) */


  (function(){


    function init(){


      if(window.innerWidth>480)return;


      document.querySelectorAll('.footer-acc-trigger').forEach(function(trigger){


        if(trigger.dataset.bound)return;trigger.dataset.bound='1';


        trigger.addEventListener('click',function(){


          var body=this.nextElementSibling;while(body&&!body.classList.contains('footer-acc-body')){body=body.nextElementSibling}


          if(!body)return;var isOpen=body.classList.contains('open');


          document.querySelectorAll('.footer-acc-body.open').forEach(function(b){b.classList.remove('open')});


          document.querySelectorAll('.footer-acc-trigger.open').forEach(function(t){t.classList.remove('open');t.setAttribute('aria-expanded','false')});


          if(!isOpen){body.classList.add('open');this.classList.add('open');this.setAttribute('aria-expanded','true')}


        });


      });


    }


    init();window.addEventListener('resize',init);


  })();





  /* 4. Pricing FAQ Accordion */


  (function(){


    document.querySelectorAll('.faq-q').forEach(q=>{


      q.addEventListener('click',function(){


        const item = this.parentElement;


        const isOpen = item.classList.contains('open');


        // Close all other FAQs


        document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));


        // Open the clicked one if it wasn't open


        if(!isOpen) item.classList.add('open');


      });


    });


  })();





  /* 5. Gallery Specific JS */


  if(document.querySelector('.gal-inner')){


    /* Stats Counter */


    const counters=document.querySelectorAll('.gal-stats .n[data-target]');


    if(counters.length){


      const easeOut=t=>1-Math.pow(1-t,3);


      function animate(el){const target=parseFloat(el.dataset.target);const suffix=el.dataset.suffix||'';const decimal=parseInt(el.dataset.decimal||0);const duration=1800;const start=performance.now();function tick(now){const elapsed=now-start;const progress=Math.min(elapsed/duration,1);const eased=easeOut(progress);const current=eased*target;el.textContent=current.toFixed(decimal)+suffix;if(progress<1)requestAnimationFrame(tick);else el.textContent=target.toFixed(decimal)+suffix}requestAnimationFrame(tick)}


      const ioStats=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){animate(e.target);ioStats.unobserve(e.target)}})},{threshold:.4});


      counters.forEach(el=>ioStats.observe(el));


    }


    /* Filter Pills */


    const buttons=document.querySelectorAll('.filter-bar button[data-filter]');const items=document.querySelectorAll('.gal-item');


    buttons.forEach(btn=>{btn.addEventListener('click',function(){buttons.forEach(b=>b.classList.remove('active'));this.classList.add('active');const filter=this.dataset.filter;items.forEach(item=>{const cats=(item.dataset.cat||'').split(' ');if(filter==='all'||cats.includes(filter)){item.classList.remove('is-hidden')}else{item.classList.add('is-hidden')}})})});


    /* Lightbox */


    const lb=document.getElementById('lightbox');const lbImg=document.getElementById('lbImg');const lbClose=document.getElementById('lbClose');const lbPrev=document.getElementById('lbPrev');const lbNext=document.getElementById('lbNext');


    let litems=[];let currentIdx=0;


    function visible(){return Array.from(document.querySelectorAll('.gal-item')).filter(el=>!el.classList.contains('is-hidden'))}


    function show(idx){litems=visible();if(!litems.length)return;currentIdx=(idx+litems.length)%litems.length;lbImg.src=litems[currentIdx].dataset.src;lb.classList.add('open');document.body.style.overflow='hidden'}


    function closeLB(){lb.classList.remove('open');document.body.style.overflow=''}


    document.querySelectorAll('.gal-item').forEach((item,i)=>{item.addEventListener('click',()=>{litems=visible();const idx=litems.indexOf(item);show(idx)})});


    lbClose&&lbClose.addEventListener('click',closeLB);lb&&lb.addEventListener('click',e=>{if(e.target===lb)closeLB()});


    lbPrev&&lbPrev.addEventListener('click',e=>{e.stopPropagation();show(currentIdx-1)});lbNext&&lbNext.addEventListener('click',e=>{e.stopPropagation();show(currentIdx+1)});


    document.addEventListener('keydown',e=>{if(!lb||!lb.classList.contains('open'))return;if(e.key==='Escape')closeLB();if(e.key==='ArrowLeft')show(currentIdx-1);if(e.key==='ArrowRight')show(currentIdx+1)});


    /* Testimonial Carousel */


    const slides=document.querySelectorAll('.gal-test .slide');const dots=document.querySelectorAll('.dots button');let active=0;let timer;


    function go(i){slides.forEach(s=>s.classList.remove('is-active'));dots.forEach(d=>d.classList.remove('active'));slides[i].classList.add('is-active');dots[i].classList.add('active');active=i}


    function next(){go((active+1)%slides.length)}


    if(slides.length){dots.forEach(d=>d.addEventListener('click',function(){clearInterval(timer);go(parseInt(this.dataset.i));timer=setInterval(next,6000)}));timer=setInterval(next,6000);}


  }


    /* 6. Scroll To Top Button */


  (function(){


    const scrollBtn = document.getElementById('scrollTopBtn');


    if(scrollBtn) {


      window.addEventListener('scroll', () => {


        // 400px scroll hone ke baad button show hoga


        if (window.scrollY > 400) {


          scrollBtn.classList.add('visible');


        } else {


          scrollBtn.classList.remove('visible');


        }


      });





      scrollBtn.addEventListener('click', () => {


        window.scrollTo({


          top: 0,


          behavior: 'smooth'


        });


      });


    }


  })();





  /* 7. Contact Form 7 - Redirect to Thank You Page */


  document.addEventListener( 'wpcf7mailsent', function( event ) {


      window.location.href = '/thank-you/';


  }, false );





</script>





<?php wp_footer(); ?>


</body>


</html>