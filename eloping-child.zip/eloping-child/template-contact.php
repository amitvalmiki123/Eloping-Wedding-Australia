<?php
/**
 * Template Name: Contact Us
 */
get_header();

$contact_sections = array(
    'hero',
    'form'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'contact', $contact_sections ); ?>
</main>
<?php
get_footer();