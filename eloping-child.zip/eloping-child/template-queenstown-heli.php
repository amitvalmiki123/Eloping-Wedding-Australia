<?php
/**
 * Template Name: Heli Elopement in Queenstown
 */
get_header();

$heli_sections = array(
    'hero',
    'intro',
    'experiences',
    'highlights',
    'band',
    'plan',
    'testimonial',
    'mini',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php 
    eloping_render_sections( 'queenstown', $heli_sections ); 
    ?>
</main>
<?php
get_footer();
?>