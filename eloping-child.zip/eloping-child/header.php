<?php


/**


 * The header for our theme


 */


?>


<!doctype html>


<html <?php language_attributes(); ?>>


<head>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T8WDKGR3');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZN6ECBD3ZK"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZN6ECBD3ZK');
</script>

    <meta charset="<?php bloginfo( 'charset' ); ?>" />


    <meta name="viewport" content="width=device-width,initial-scale=1" />


    <?php wp_head(); ?>


</head>


<body <?php body_class(); ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T8WDKGR3"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<?php wp_body_open(); ?>





<div class="bar">


  <?php 


  // Fetch Marquee Text from Customizer


  $default_marquee = 'Boutique elopements across Aotearoa <em>·</em> Queenstown <em>·</em> Wanaka <em>·</em> Lake Tekapo <em>·</em> Bay of Islands <em>·</em> Featured in NZ Wedding Mag <em>·</em> 5 Star <em>·</em> 200+ Couples <em>·</em> Est. 2014';


  $marquee_text = get_theme_mod( 'eloping_marquee_text', $default_marquee ); 


  ?>


  <div class="marquee-bar">


    <div class="marquee-bar-track">


      <!-- Dono span dynamically admin ka text load karenge -->


      <span><?php echo wp_kses_post( $marquee_text ); ?></span>


      <span><?php echo wp_kses_post( $marquee_text ); ?></span>


    </div>


  </div>


  <div class="right">


    <?php 


    // Phone Setup


    $phone_display = get_theme_mod( 'eloping_phone_number', '+64 21 000 000' );


    $phone_link = preg_replace( '/[^0-9]/', '', $phone_display );


    


    // Email Setup


    $email_display = get_theme_mod( 'eloping_email_address', 'hello@elopingweddings.co.nz' );


    // Note: antispambot() is used to protect email from scraping bots


    ?>


    <a href="tel:<?php echo esc_attr( $phone_link ); ?>"><?php echo esc_html( $phone_display ); ?></a>


    <a href="mailto:<?php echo esc_attr( antispambot( $email_display ) ); ?>"><?php echo esc_html( antispambot( $email_display ) ); ?></a>


  </div>


</div>





<header class="header">


  <nav class="nav" aria-label="primary">


    


    <div class="nav-left">


        <?php


        wp_nav_menu( array(


            'theme_location' => 'primary_left',


            'container'      => false,


            'items_wrap'     => '%3$s', // Removes standard ul wrapper


            'walker'         => new Eloping_Header_Walker(),


            'fallback_cb'    => false,


        ) );


        ?>


    </div>





    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand" aria-label="<?php bloginfo('name'); ?> home">


      <img src="<?php echo esc_url( THEME_URI . '/assets/images/eloping-weddings-Logo.png' ); ?>" alt="<?php bloginfo('name'); ?>"/>


    </a>





    <div class="nav-right">


        <?php


        wp_nav_menu( array(


            'theme_location' => 'primary_right',


            'container'      => false,


            'items_wrap'     => '%3$s', // Removes standard ul wrapper


            'walker'         => new Eloping_Header_Walker(),


            'fallback_cb'    => false,


        ) );


        ?>


    </div>





    <!-- Mobile Header Call Icon (Dynamic Link) -->


    <a href="tel:<?php echo esc_attr( $phone_link ); ?>" class="mobile-header-call" aria-label="Call Us">


        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">


            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>


        </svg>


    </a>





    <button class="menu-btn" aria-label="Open menu">


      <span class="lines"><span></span><span></span><span></span></span>


      Menu


    </button>


  </nav>


</header>