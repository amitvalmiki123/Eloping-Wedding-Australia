<?php
/**
 * The template for displaying 404 pages (not found)
 */
get_header();
?>

<main id="main" class="site-main">
    <section class="page-hero minimal" style="min-height: 75vh; display: flex; align-items: center; justify-content: center; text-align: center; background: linear-gradient(180deg, var(--paper) 0%, var(--cream) 100%);">
        <div class="inner" style="padding-bottom: 0;">
            <div class="eyebrow" style="justify-content: center;">
                <span class="dot"></span> 404 Error
            </div>
            
            <h1 style="color: var(--forest); max-width: 15ch; margin: 0 auto 24px;">
                We lost the <em>trail.</em>
            </h1>
            
            <p class="lede" style="color: var(--ink); margin: 0 auto 40px; max-width: 48ch;">
                The page you are looking for might have been moved, renamed, or just disappeared into the wild. Let's get you back to familiar landscapes.
            </p>
            
            <div class="actions" style="display: flex; justify-content: center;">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-dark">
                    Back to Home <i class="arrow"></i>
                </a>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();