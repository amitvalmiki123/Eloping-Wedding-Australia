<?php
/**
 * The template for displaying all single posts
 */
get_header();
?>

<main id="main" class="site-main">
    <?php
    // WordPress Loop to fetch post data
    while ( have_posts() ) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            
            <section class="page-hero minimal" style="min-height: 40vh; background: linear-gradient(180deg, var(--paper) 0%, var(--cream) 100%);">
                <div class="inner" style="padding-top: 120px; padding-bottom: 60px;">
                    <div class="eyebrow" style="justify-content: center;">
                        <span class="dot"></span> 
                        <?php 
                        // Fetch the first category of the post
                        $categories = get_the_category();
                        if ( ! empty( $categories ) ) {
                            echo esc_html( $categories[0]->name );
                        } else {
                            echo 'Journal';
                        }
                        ?>
                    </div>
                    
                    <h1 style="max-width: 800px; margin: 0 auto; color: var(--forest);"><?php the_title(); ?></h1>
                    
                    <p class="lede" style="margin-top: 20px; font-size: 15px; letter-spacing: 0.05em;">
                        <?php echo get_the_date(); ?> &nbsp;&middot;&nbsp; By <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" style="color: var(--rose); font-weight: 500; text-decoration: none;"><?php the_author(); ?></a>
                    </p>
                </div>
            </section>

            <section class="post-content-wrap">
                
                <?php 
                // Display Featured Image if it exists
                if ( has_post_thumbnail() ) : ?>
                    <div class="post-featured-image">
                        <?php the_post_thumbnail( 'full', array( 'alt' => get_the_title() ) ); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content">
                    <?php 
                    // This outputs the actual blog post content
                    the_content(); 
                    ?>
                </div>
                
                <div style="text-align: center; margin-top: 60px;">
                    <a class="btn btn-dark" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <i class="arrow" style="transform: rotate(-135deg); margin-right: 8px; margin-left: 0; margin-top: -2px;"></i> Back to Home
                    </a>
                </div>

            </section>

        </article>
    <?php endwhile; ?>
</main>

<?php
get_footer();