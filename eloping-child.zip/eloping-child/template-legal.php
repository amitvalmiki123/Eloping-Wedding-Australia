<?php
/**
 * Template Name: Legal Policy (Privacy/Terms)
 */
get_header();
?>

<main id="main" class="site-main legal-page">
    <header class="legal-header">
        <div class="wrap">
            <h1><?php the_title(); ?></h1>
            <p class="updated-date">Last updated: <?php the_modified_date('F j, Y'); ?></p>
        </div>
    </header>
    
    <section class="legal-content">
        <div class="wrap">
            <?php 
            while ( have_posts() ) : the_post();
                the_content();
            endwhile; 
            ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>