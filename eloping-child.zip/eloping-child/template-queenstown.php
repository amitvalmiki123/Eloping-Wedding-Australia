<?php
/**
 * Template Name: Queenstown Destination
 */
get_header();

$queenstown_sections = array(
    'hero',
    'intro',
    'experiences',
    'highlights',
    'band',
    'plan',
    'testimonial',
    'mini',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'queenstown', $queenstown_sections ); ?>
</main>
<?php
get_footer();