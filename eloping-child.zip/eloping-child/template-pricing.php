<?php
/**
 * Template Name: Pricing
 */
get_header();

$pricing_sections = array(
    'hero',
    'packages',
    'included',
    'addons',
    'compare',
    'faq',
    'testimonial',
    'cta'
);
?>
<main id="main" class="site-main">
    <?php eloping_render_sections( 'pricing', $pricing_sections ); ?>
</main>
<?php
get_footer();