<?php
/**
 * Template Name: Main Journal/Blog Page
 * The template for displaying the main blog index page.
 */

get_header();

// NOTE: Yahan 'pricing-bg.jpg' ko apni actual pink gradient/blur image ke naam se replace kar lena jo aap theme mein use kar rahe ho.
$bg_img = get_template_directory_uri() . '/assets/images/pricing-bg.jpg'; 
?>

<main id="main" class="site-main" style="background:var(--paper);">
    
    <!-- Minimal Hero matching Pricing Page Pattern -->
    <section class="page-hero minimal" style="min-height:50vh; background:var(--paper-2); align-items:center;">
        <?php if ( $bg_img ) : ?>
        <div class="bg-pink">
            <img src="<?php echo esc_url( $bg_img ); ?>" alt="Journal Hero Background" loading="eager" fetchpriority="high" />
        </div>
        <?php endif; ?>
        
        <div class="inner" style="text-align:center;">
            <div class="eyebrow" style="display:inline-flex; justify-content:center;">
                <span class="dot"></span> THE JOURNAL
            </div>
            
            <h1 style="color:var(--forest); max-width:22ch; margin-left:auto; margin-right:auto;">
                Notes from the <em>field.</em>
            </h1>
            
            <p class="lede" style="color:var(--ink);">
                Real stories, quiet moments, and guides to planning your intimate New Zealand elopement.
            </p>
        </div>
    </section>

    <!-- Main Journal Section (Grid) -->
    <section class="journal" style="margin-top: 0; padding-top: 60px;">
        
        <?php if ( have_posts() ) : ?>
        <div class="grid">
            <?php while ( have_posts() ) : the_post(); 
                
                // Get primary category
                $categories = get_the_category();
                $cat_name   = ! empty( $categories ) ? $categories[0]->name : 'Journal';
                
                // --- PRO SMART READ TIME LOGIC (Hours + Minutes) ---
                $manual_time = get_field('custom_read_time', get_the_ID());
                $total_mins  = 0;

                if ( $manual_time ) {
                    $total_mins = (int) $manual_time;
                } else {
                    $word_count = str_word_count( strip_tags( get_post_field( 'post_content', get_the_ID() ) ) );
                    $total_mins = max( 1, ceil( $word_count / 200 ) );
                }

                if ( $total_mins >= 60 ) {
                    $hours = floor( $total_mins / 60 );
                    $mins  = $total_mins % 60;
                    $read_time = $hours . ' hr' . ( $hours > 1 ? 's' : '' ); 
                    if ( $mins > 0 ) {
                        $read_time .= ' ' . $mins . ' min';
                    }
                    $read_time .= ' read';
                } else {
                    $read_time = $total_mins . ' min read';
                }
            ?>
            <a class="post fade-in" href="<?php the_permalink(); ?>">
                <div class="img">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <img src="<?php the_post_thumbnail_url( 'large' ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy"/>
                    <?php else : ?>
                        <!-- Fallback image -->
                        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/exp1.jpg' ); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy"/>
                    <?php endif; ?>
                </div>
                <small><?php echo esc_html( $cat_name . ' · ' . $read_time ); ?></small>
                <h3><?php the_title(); ?></h3>
                <p><?php echo wp_trim_words( get_the_excerpt(), 18, '...' ); ?></p>
            </a>
            <?php endwhile; ?>
        </div>

        <!-- Custom Pagination -->
        <div class="pagination fade-in" style="margin-top: 60px; display: flex; justify-content: center; gap: 20px;">
            <?php 
            the_posts_pagination( array(
                'mid_size'  => 2,
                'prev_text' => '<span class="btn btn-dark" style="padding: 10px 24px;">Prev</span>',
                'next_text' => '<span class="btn btn-dark" style="padding: 10px 24px;">Next</span>',
            ) ); 
            ?>
        </div>

        <?php else : ?>
            <p style="text-align: center; color: var(--ink);">No journal entries found yet. Check back soon!</p>
        <?php endif; ?>
        
    </section>
</main>

<?php get_footer(); ?>