<?php


/**


 * Child Theme Core Functions


 */





define( 'THEME_DIR', get_stylesheet_directory() );


define( 'THEME_URI', get_stylesheet_directory_uri() );


define( 'THEME_VERSION', wp_get_theme()->get( 'Version' ) );





// Theme Setup


function eloping_child_setup() {


    // Register standard WP Menus


    register_nav_menus( array(


        'primary_left'  => __( 'Primary Left Menu', 'eloping' ),


        'primary_right' => __( 'Primary Right Menu', 'eloping' ),


        'footer_dest'   => __( 'Footer Destinations', 'eloping' ),


        'footer_exp'    => __( 'Footer Experience', 'eloping' ),


    ) );


}


add_action( 'after_setup_theme', 'eloping_child_setup' );





// Enqueue Scripts & Styles (Rule 11)


function eloping_child_scripts() {


    // Main CSS


    wp_enqueue_style( 'eloping-main', THEME_URI . '/assets/css/main.css', array(), THEME_VERSION );


    // Responsive CSS loaded after main


    wp_enqueue_style( 'eloping-responsive', THEME_URI . '/assets/css/responsive.css', array('eloping-main'), THEME_VERSION );


    


    // Main JS


    wp_enqueue_script( 'eloping-main-js', THEME_URI . '/assets/js/main.js', array(), THEME_VERSION, true );


}


add_action( 'wp_enqueue_scripts', 'eloping_child_scripts' );





// Security Hardening (Rule 17)


remove_action( 'wp_head', 'wp_generator' );


add_filter( 'xmlrpc_enabled', '__return_false' );


add_action( 'send_headers', function() {


    header( 'X-Content-Type-Options: nosniff' );


} );





// Include Helpers & Defaults


require_once THEME_DIR . '/defaults.php';


require_once THEME_DIR . '/inc/helpers/field-helpers.php';


require_once THEME_DIR . '/inc/helpers/image-helpers.php';


require_once THEME_DIR . '/inc/helpers/section-helpers.php';


require_once THEME_DIR . '/inc/customizer.php';





// Include ACF Fields 


// handled by queenstown-fields.php)


require_once THEME_DIR . '/inc/acf/front-page-fields.php';


require_once THEME_DIR . '/inc/acf/queenstown-fields.php'; // The master file


require_once THEME_DIR . '/inc/acf/about-fields.php';


require_once THEME_DIR . '/inc/acf/pricing-fields.php';


require_once THEME_DIR . '/inc/acf/contact-fields.php';


require_once THEME_DIR . '/inc/acf/gallery-fields.php';





// Custom Walker for Eloping Header Menus


class Eloping_Header_Walker extends Walker_Nav_Menu {


    // Dropdown container start


    function start_lvl( &$output, $depth = 0, $args = null ) {


        if ( $depth == 0 ) {


            $output .= '<div class="dropdown">';


        }


    }


    // Dropdown container end


    function end_lvl( &$output, $depth = 0, $args = null ) {


        if ( $depth == 0 ) {


            $output .= '</div>';


        }


    }


    // Individual menu items


    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {


        $has_children = in_array( 'menu-item-has-children', $item->classes );


        $title = apply_filters( 'the_title', $item->title, $item->ID );


        $url = !empty($item->url) ? $item->url : '#'; // Fetch the URL


        


        // Menu item description (for <small> tags)


        $desc = !empty($item->description) ? '<small>'.esc_html($item->description).'</small>' : '';





        if ( $depth == 0 ) {


            if ( $has_children ) {


                $output .= '<div class="menu-group">';


                // YAHAN CHANGE KIYA HAI: <button> ko <a> banaya aur href add kiya


                $output .= '<a href="' . esc_url($url) . '" class="item" aria-haspopup="true">' . $title . ' <i class="caret"></i></a>';


            } else {


                $output .= '<a class="item" href="' . esc_url($url) . '">' . $title . '</a>';


            }


        } else {


            // Inside dropdown


            $output .= '<a href="' . esc_url($url) . '"><span>' . $title . '</span>' . $desc . '</a>';


        }


    }


    // End element


    function end_el( &$output, $item, $depth = 0, $args = null ) {


        if ( $depth == 0 && in_array( 'menu-item-has-children', $item->classes ) ) {


            $output .= '</div>'; // close menu-group


        }


    }


}





/**


 * Enqueue Google Fonts and add Preconnects (Rule 18)


 */


function eloping_enqueue_fonts() {


    // Load Quicksand, Cormorant Garamond, and DM Sans


    $font_url = 'https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&family=DM+Sans:wght@300;400;500;700&display=swap';


    wp_enqueue_style( 'eloping-google-fonts', $font_url, array(), null );


}


add_action( 'wp_enqueue_scripts', 'eloping_enqueue_fonts' );





// Add resource hints for faster font loading


function eloping_font_preconnect() {


    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";


    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";


}


add_action( 'wp_head', 'eloping_font_preconnect', 5 );



/* SEO Landing template: shared defaults, ACF fields, one-time seeder. */
require_once get_stylesheet_directory() . '/inc/seo-landing-defaults.php';
require_once get_stylesheet_directory() . '/inc/seo-landing-acf.php';
require_once get_stylesheet_directory() . '/inc/seo-landing-seed.php';